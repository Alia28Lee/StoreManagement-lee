<?php

$db = new PDO('sqlite:database/database.sqlite');

// Check user
$result = $db->query("SELECT * FROM users WHERE email = 'admin@storeadmin.com'");
$user = $result->fetch(PDO::FETCH_ASSOC);

echo "=== DATABASE CHECK ===\n\n";

if($user) {
    echo "✅ Admin User Found:\n";
    echo "   ID: " . $user['id'] . "\n";
    echo "   Email: " . $user['email'] . "\n";
    echo "   Name: " . $user['name'] . "\n";
    echo "   Password Hash: " . substr($user['password'], 0, 20) . "...\n";
} else {
    echo "❌ Admin User NOT Found\n";
}

echo "\n";

// Check profile
$profile = $db->query("SELECT * FROM user_profiles WHERE user_id = 2")->fetch(PDO::FETCH_ASSOC);
if($profile) {
    echo "✅ User Profile Found:\n";
    echo "   Shop: " . $profile['shop_name'] . "\n";
    echo "   Role: " . $profile['role'] . "\n";
    echo "   Active: " . ($profile['is_active'] ? 'Yes' : 'No') . "\n";
} else {
    echo "❌ User Profile NOT Found\n";
}

echo "\n";

// Check tables
$tables = $db->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
echo "✅ Tables in Database:\n";
foreach($tables as $table) {
    $count = $db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    echo "   - $table ($count rows)\n";
}

echo "\n=== DATABASE PATH ===\n";
echo "📍 SQLite Database: " . realpath('database/database.sqlite') . "\n";
