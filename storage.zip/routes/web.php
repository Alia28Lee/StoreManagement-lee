<?php

use App\Http\Controllers\AdminAuthController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\StockController;
use App\Http\Controllers\PurchaseReportController;
use App\Http\Controllers\UserManagementController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

// Redirect generic login to admin login
Route::get('/login', function () {
    return redirect()->route('admin.login');
})->name('login');

// Admin Authentication Routes
Route::prefix('admin')->name('admin.')->group(function () {
    Route::middleware('guest:admin')->group(function () {
        Route::get('/login', [AdminAuthController::class, 'showLoginForm'])->name('login');
        Route::post('/login', [AdminAuthController::class, 'login'])->name('login.store');
    });

    Route::middleware('auth:admin')->group(function () {
        Route::get('/dashboard', [AdminAuthController::class, 'dashboard'])->name('dashboard');
        Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');

        // User Management Routes
        Route::resource('users', UserManagementController::class);
        Route::get('/users/{user}/change-password', [UserManagementController::class, 'changePasswordForm'])->name('users.change-password-form');
        Route::put('/users/{user}/update-password', [UserManagementController::class, 'updatePassword'])->name('users.update-password');

        // Customer Routes
        Route::resource('customers', CustomerController::class);

        // Bill Routes (Multi-product sales)
        Route::resource('bills', BillController::class);
        Route::get('/bills/{bill}/invoice', [BillController::class, 'generateInvoice'])->name('bills.invoice');

        // Report Routes
        Route::prefix('reports')->name('reports.')->group(function () {
            Route::get('/', [ReportController::class, 'index'])->name('index');
            Route::get('/daily-sales', [ReportController::class, 'dailySales'])->name('daily-sales');
            Route::get('/daily-sales/export', [ReportController::class, 'exportDailySales'])->name('daily-sales.export');
            Route::get('/customer-sales', [ReportController::class, 'customerSales'])->name('customer-sales');
            Route::get('/customer-sales/export', [ReportController::class, 'exportCustomerSales'])->name('customer-sales.export');
            Route::get('/weekly-sales', [ReportController::class, 'weeklySales'])->name('weekly-sales');
            Route::get('/monthly-sales', [ReportController::class, 'monthlySales'])->name('monthly-sales');
            Route::get('/yearly-sales', [ReportController::class, 'yearlySales'])->name('yearly-sales');
        });

        // Inventory Routes
        Route::prefix('inventory')->name('inventory.')->group(function () {
            Route::get('/', [StockController::class, 'index'])->name('index');
            
            Route::resource('categories', CategoryController::class);
            Route::resource('products', ProductController::class);
            Route::resource('suppliers', SupplierController::class);
            Route::resource('purchases', PurchaseController::class);
            
            Route::get('/stock', [StockController::class, 'index'])->name('stock.index');
            Route::get('/stock/{product}', [StockController::class, 'show'])->name('stock.show');
        });

        // Purchase Reports Routes
        Route::prefix('purchase-reports')->name('purchase-reports.')->group(function () {
            Route::get('/', [PurchaseReportController::class, 'index'])->name('index');
            Route::get('/daily', [PurchaseReportController::class, 'daily'])->name('daily');
            Route::get('/weekly', [PurchaseReportController::class, 'weekly'])->name('weekly');
            Route::get('/monthly', [PurchaseReportController::class, 'monthly'])->name('monthly');
            Route::get('/yearly', [PurchaseReportController::class, 'yearly'])->name('yearly');
        });
    });
});
