<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Customer;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\Bill;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AdminAuthController extends Controller
{
    // Show admin login form
    public function showLoginForm(Request $request)
    {
        return view('admin.login');
    }

    // Handle login
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Attempt to authenticate the user
        if (Auth::guard('admin')->attempt($credentials)) {
            // Check if user has admin or superadmin role
            $user = Auth::guard('admin')->user();
            $userProfile = $user->profile;

            if ($userProfile && ($userProfile->role === 'admin' || $userProfile->role === 'superadmin')) {
                // User is an admin, allow login
                $request->session()->regenerate();
                return redirect()->intended(route('admin.dashboard'));
            } else {
                // User is not an admin, logout and show error
                Auth::guard('admin')->logout();
                return back()->withErrors([
                    'email' => 'You do not have admin access. Please contact your administrator.',
                ])->onlyInput('email');
            }
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');
    }

    // Show admin dashboard
    public function dashboard()
    {
        $totalCustomers = Customer::count();
        $totalBills = Bill::count();
        $totalRevenue = Bill::sum('net_amount');
        $totalProducts = Product::count();
        $totalPurchases = Purchase::count();
        $lowStockItems = Product::where('current_stock', '<=', 'reorder_level')->count();
        $totalDebt = Purchase::where('payment_status', '!=', 'paid')->sum('net_amount');

        return view('admin.dashboard', compact(
            'totalCustomers',
            'totalBills',
            'totalRevenue',
            'totalProducts',
            'totalPurchases',
            'lowStockItems',
            'totalDebt'
        ));
    }

    // Handle logout
    public function logout(Request $request)
    {
        Auth::guard('admin')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        
        return redirect(route('admin.login'))
                    ->with('message', '👋 You have been logged out successfully. See you next time!');
    }
}
