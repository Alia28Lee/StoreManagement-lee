<?php

namespace App\Http\Controllers;

use App\Models\Purchase;
use App\Models\Product;
use App\Models\Supplier;
use App\Models\PurchaseItem;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PurchaseController extends Controller
{
    public function index(Request $request)
    {
        $query = Purchase::with('supplier');

        // Apply filters
        if ($request->filled('search')) {
            $query->where('reference_number', 'like', "%{$request->input('search')}%");
        }

        if ($request->filled('supplier_id')) {
            $query->where('supplier_id', $request->input('supplier_id'));
        }

        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->input('payment_status'));
        }

        if ($request->filled('date_from')) {
            $query->whereDate('purchase_date', '>=', $request->input('date_from'));
        }

        if ($request->filled('date_to')) {
            $query->whereDate('purchase_date', '<=', $request->input('date_to'));
        }

        $purchases = $query->orderBy('purchase_date', 'desc')->paginate(20)->appends($request->query());
        $suppliers = Supplier::orderBy('name')->get();
        $totalDebt = Purchase::where('payment_status', '!=', 'paid')->sum('debt_amount');

        return view('admin.purchases.index', compact('purchases', 'totalDebt', 'suppliers'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $referenceNumber = 'PUR-' . date('YmdHis') . '-' . Str::random(4);
        return view('admin.purchases.create', compact('products', 'suppliers', 'referenceNumber'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'reference_number' => 'required|unique:purchases',
            'supplier_id' => 'nullable|exists:suppliers,id',
            'purchase_date' => 'required|date',
            'total_amount' => 'required|numeric|min:0.01',
            'paid_amount' => 'required|numeric|min:0',
            'debt_amount' => 'required|numeric|min:0',
            'payment_status' => 'required|in:paid,partial,pending',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.unit_price' => 'required|numeric|min:0.01',
        ]);

        // Debt is already calculated from form
        $purchase = Purchase::create($validated);

        // Store purchase items and update stock
        foreach ($request->input('items') as $item) {
            if (empty($item['product_id'])) continue;

            $totalPrice = $item['quantity'] * $item['unit_price'];

            PurchaseItem::create([
                'purchase_id' => $purchase->id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['unit_price'],
                'total_price' => $totalPrice,
            ]);

            // Update product stock
            $product = Product::find($item['product_id']);
            $product->increment('current_stock', $item['quantity']);
        }

        return redirect()->route('admin.inventory.purchases.show', $purchase)
                        ->with('success', 'Purchase recorded successfully. Stock updated.');
    }

    public function show(Purchase $purchase)
    {
        $purchase->load('purchaseItems.product', 'supplier');
        return view('admin.purchases.show', compact('purchase'));
    }

    public function edit(Purchase $purchase)
    {
        $products = Product::orderBy('name')->get();
        $suppliers = Supplier::orderBy('name')->get();
        $purchase->load('purchaseItems');
        return view('admin.purchases.edit', compact('purchase', 'products', 'suppliers'));
    }

    public function update(Request $request, Purchase $purchase)
    {
        $validated = $request->validate([
            'reference_number' => 'required|unique:purchases,reference_number,' . $purchase->id,
            'supplier_id' => 'nullable|exists:suppliers,id',
            'purchase_date' => 'required|date',
            'total_amount' => 'required|numeric|min:0.01',
            'paid_amount' => 'required|numeric|min:0',
            'debt_amount' => 'required|numeric|min:0',
            'payment_status' => 'required|in:paid,partial,pending',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        $purchase->update($validated);

        return redirect()->route('admin.inventory.purchases.show', $purchase)
                        ->with('success', 'Purchase updated successfully.');
    }

    public function destroy(Purchase $purchase)
    {
        // Revert stock changes
        foreach ($purchase->purchaseItems as $item) {
            if ($item->product) {
                $item->product->decrement('current_stock', $item->quantity);
            }
        }

        $purchase->purchaseItems()->delete();
        $purchase->delete();

        return redirect()->route('admin.inventory.purchases.index')
                        ->with('success', 'Purchase deleted and stock reverted.');
    }
}
