<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\BillItem;
use App\Models\Product;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class BillController extends Controller
{
    public function index(Request $request)
    {
        $query = Bill::with('customer');

        // Apply filters
        if ($request->filled('search')) {
            $query->where('invoice_number', 'like', "%{$request->input('search')}%");
        }

        if ($request->filled('customer_id')) {
            $query->where('customer_id', $request->input('customer_id'));
        }

        if ($request->filled('payment_status')) {
            $query->where('payment_status', $request->input('payment_status'));
        }

        if ($request->filled('date_from')) {
            $query->whereDate('bill_date', '>=', $request->input('date_from'));
        }

        if ($request->filled('date_to')) {
            $query->whereDate('bill_date', '<=', $request->input('date_to'));
        }

        $bills = $query->orderBy('bill_date', 'desc')->paginate(20)->appends($request->query());
        $customers = Customer::orderBy('name')->get();
        
        $totalRevenue = Bill::sum('net_amount');
        $totalPaid = Bill::sum('amount_paid');
        $totalDebt = Bill::sum('debt_amount');

        return view('admin.bills.index', compact('bills', 'totalRevenue', 'totalPaid', 'totalDebt', 'customers'));
    }

    public function create()
    {
        $products = Product::orderBy('name')->get();
        $customers = Customer::orderBy('name')->get();
        $invoiceNumber = 'INV-' . date('YmdHis') . '-' . Str::random(4);
        return view('admin.bills.create', compact('products', 'customers', 'invoiceNumber'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'invoice_number' => 'required|unique:bills',
            'customer_id' => 'nullable|exists:customers,id',
            'bill_date' => 'required|date',
            'discount_amount' => 'required|numeric|min:0',
            'amount_paid' => 'nullable|numeric|min:0',
            'payment_status' => 'required|in:paid,pending,partial',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|numeric|min:0.01',
            'items.*.unit_price' => 'required|numeric|min:0.01',
        ]);

        $bill = Bill::create($validated);

        $totalAmount = 0;
        // Store bill items and reduce stock
        foreach ($request->input('items') as $item) {
            if (empty($item['product_id'])) continue;

            $itemTotal = $item['quantity'] * $item['unit_price'];
            $totalAmount += $itemTotal;

            BillItem::create([
                'bill_id' => $bill->id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'unit_price' => $item['unit_price'],
                'item_total' => $itemTotal,
            ]);

            // Reduce stock from products table (allow negative stock down to -20)
            $product = Product::find($item['product_id']);
            $newStock = $product->current_stock - $item['quantity'];
            if ($newStock >= -20) {
                $product->decrement('current_stock', $item['quantity']);
            } else {
                return redirect()->back()->with('error', "Insufficient stock for {$product->name}. Maximum allowed negative stock is -20 units.");
            }
        }

        // Calculate and update bill totals
        $bill->total_amount = $totalAmount;
        $bill->net_amount = $totalAmount - $bill->discount_amount;
        $amountPaid = $request->input('amount_paid', 0);
        $bill->amount_paid = $amountPaid;
        
        // Calculate debt amount = net_amount - amount_paid
        $bill->debt_amount = max(0, $bill->net_amount - $amountPaid);
        $bill->save();

        // Update customer's debt balance if applicable
        if ($bill->customer_id && $bill->debt_amount > 0) {
            $customer = Customer::find($bill->customer_id);
            if ($customer) {
                $customer->debit_balance = ($customer->debit_balance ?? 0) + $bill->debt_amount;
                $customer->save();
            }
        }

        return redirect()->route('admin.bills.show', $bill)
                        ->with('success', 'Bill created successfully. Invoice generated.');
    }

    public function show(Bill $bill)
    {
        $bill->load('customer', 'billItems.product');
        return view('admin.bills.show', compact('bill'));
    }

    public function edit(Bill $bill)
    {
        $bill->load('billItems');
        $products = Product::orderBy('name')->get();
        $customers = Customer::orderBy('name')->get();
        return view('admin.bills.edit', compact('bill', 'products', 'customers'));
    }

    public function update(Request $request, Bill $bill)
    {
        $validated = $request->validate([
            'invoice_number' => 'required|unique:bills,invoice_number,' . $bill->id,
            'customer_id' => 'nullable|exists:customers,id',
            'bill_date' => 'required|date',
            'discount_amount' => 'required|numeric|min:0',
            'amount_paid' => 'nullable|numeric|min:0',
            'payment_status' => 'required|in:paid,pending,partial',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        // Recalculate debt based on net_amount and amount_paid
        $netAmount = $bill->total_amount - $validated['discount_amount'];
        $amountPaid = $validated['amount_paid'] ?? 0;
        $newDebtAmount = max(0, $netAmount - $amountPaid);
        
        // Handle debt balance updates
        $oldDebtAmount = $bill->debt_amount ?? 0;
        
        if ($bill->customer_id && $oldDebtAmount !== $newDebtAmount) {
            $customer = Customer::find($bill->customer_id);
            if ($customer) {
                // Adjust debt balance by the difference
                $customer->debit_balance = max(0, ($customer->debit_balance ?? 0) - $oldDebtAmount + $newDebtAmount);
                $customer->save();
            }
        }

        $validated['debt_amount'] = $newDebtAmount;
        $bill->update($validated);

        return redirect()->route('admin.bills.show', $bill)
                        ->with('success', 'Bill updated successfully.');
    }

    public function destroy(Bill $bill)
    {
        // Revert stock changes
        foreach ($bill->billItems as $item) {
            if ($item->product) {
                $item->product->increment('current_stock', $item->quantity);
            }
        }

        // Revert customer's debt balance
        if ($bill->customer_id && $bill->debt_amount > 0) {
            $customer = Customer::find($bill->customer_id);
            if ($customer) {
                $customer->debit_balance = max(0, ($customer->debit_balance ?? 0) - $bill->debt_amount);
                $customer->save();
            }
        }

        $bill->billItems()->delete();
        $bill->delete();

        return redirect()->route('admin.bills.index')
                        ->with('success', 'Bill deleted and stock reverted.');
    }

    public function generateInvoice(Bill $bill)
    {
        $bill->load('customer', 'billItems.product');
        return view('admin.bills.invoice', compact('bill'));
    }
}
