<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\UserProfile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserManagementController extends Controller
{
    /**
     * Display a listing of users.
     */
    public function index(Request $request)
    {
        $query = User::with('profile');

        // Apply filters
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function($q) use ($search) {
                $q->where('email', 'like', "%{$search}%")
                  ->orWhereHas('profile', function($subQ) use ($search) {
                      $subQ->where('shop_name', 'like', "%{$search}%")
                           ->orWhere('full_name', 'like', "%{$search}%");
                  });
            });
        }

        if ($request->filled('status')) {
            $status = $request->input('status');
            if ($status === 'active') {
                $query->whereHas('profile', fn($q) => $q->where('is_active', true));
            } elseif ($status === 'inactive') {
                $query->whereHas('profile', fn($q) => $q->where('is_active', false));
            }
        }

        $users = $query->paginate(15)->appends($request->query());

        return view('admin.users.index', compact('users'));
    }

    /**
     * Show the form for creating a new user.
     */
    public function create()
    {
        return view('admin.users.create');
    }

    /**
     * Store a newly created user in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6|confirmed',
            'shop_name' => 'required|string|max:255',
            'full_name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'address' => 'nullable|string',
            'role' => 'required|in:superadmin,admin,user',
        ]);

        $user = User::create([
            'email' => $validated['email'],
            'password' => Hash::make($validated['password']),
            'name' => $validated['full_name'],
        ]);

        UserProfile::create([
            'user_id' => $user->id,
            'shop_name' => $validated['shop_name'],
            'full_name' => $validated['full_name'],
            'phone' => $validated['phone'],
            'city' => $validated['city'],
            'state' => $validated['state'],
            'address' => $validated['address'],
            'role' => $validated['role'],
            'is_active' => true,
        ]);

        return redirect()->route('admin.users.index')
                        ->with('success', 'User created successfully.');
    }

    /**
     * Show the specified user.
     */
    public function show(User $user)
    {
        $user->load('profile');
        return view('admin.users.show', compact('user'));
    }

    /**
     * Show the form for editing the specified user.
     */
    public function edit(User $user)
    {
        $user->load('profile');
        return view('admin.users.edit', compact('user'));
    }

    /**
     * Update the specified user in storage.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'email' => 'required|email|unique:users,email,' . $user->id,
            'shop_name' => 'required|string|max:255',
            'full_name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'address' => 'nullable|string',
            'role' => 'required|in:superadmin,admin,user',
            'is_active' => 'nullable|boolean',
        ]);

        // Update user email and name
        $user->update([
            'email' => $validated['email'],
            'name' => $validated['full_name'],
        ]);

        // Load profile and update or create if not exists
        $user->load('profile');
        
        if ($user->profile) {
            $user->profile->update([
                'shop_name' => $validated['shop_name'],
                'full_name' => $validated['full_name'],
                'phone' => $validated['phone'],
                'city' => $validated['city'],
                'state' => $validated['state'],
                'address' => $validated['address'],
                'role' => $validated['role'],
                'is_active' => $request->has('is_active') ? 1 : 0,
            ]);
        } else {
            // Create profile if it doesn't exist
            UserProfile::create([
                'user_id' => $user->id,
                'shop_name' => $validated['shop_name'],
                'full_name' => $validated['full_name'],
                'phone' => $validated['phone'],
                'city' => $validated['city'],
                'state' => $validated['state'],
                'address' => $validated['address'],
                'role' => $validated['role'],
                'is_active' => $request->has('is_active') ? 1 : 0,
            ]);
        }

        return redirect()->route('admin.users.show', $user)
                        ->with('success', 'User profile updated successfully.');
    }

    /**
     * Show change password form.
     */
    public function changePasswordForm(User $user)
    {
        $user->load('profile');
        return view('admin.users.change-password', compact('user'));
    }

    /**
     * Update the user password.
     */
    public function updatePassword(Request $request, User $user)
    {
        $validated = $request->validate([
            'password' => 'required|min:6|confirmed',
        ]);

        $user->update([
            'password' => Hash::make($validated['password']),
        ]);

        return redirect()->route('admin.users.show', $user)
                        ->with('success', 'Password changed successfully.');
    }

    /**
     * Delete the specified user.
     */
    public function destroy(User $user)
    {
        $user->delete();

        return redirect()->route('admin.users.index')
                        ->with('success', 'User deleted successfully.');
    }
}
