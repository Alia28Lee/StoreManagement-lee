<?php

namespace App\Http\Controllers;

use App\Models\Bill;
use App\Models\Customer;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    /**
     * Show reports dashboard
     */
    public function index()
    {
        return view('admin.reports.index');
    }

    /**
     * Daily bills report
     */
    public function dailySales(Request $request)
    {
        $date = $request->query('date', date('Y-m-d'));
        
        $bills = Bill::whereDate('bill_date', $date)
                    ->with('customer')
                    ->orderBy('created_at', 'desc')
                    ->get();

        $totalRevenue = $bills->sum('net_amount');
        $earnedAmount = $bills->sum('amount_paid');  // Total amount actually received
        $debtAmount = $bills->sum('debt_amount');    // Total debt/bakaya
        $totalBills = $bills->count();
        $averageBill = $totalBills > 0 ? $totalRevenue / $totalBills : 0;

        $paymentBreakdown = $bills->groupBy('payment_status')
                                  ->map(fn($group) => [
                                      'count' => $group->count(),
                                      'amount' => $group->sum('net_amount'),
                                      'earned' => $group->sum('amount_paid'),
                                      'debt' => $group->sum('debt_amount')
                                  ]);

        return view('admin.reports.daily-sales', compact(
            'bills',
            'totalRevenue',
            'earnedAmount',
            'debtAmount',
            'totalBills',
            'averageBill',
            'paymentBreakdown',
            'date'
        ));
    }

    /**
     * Customer-wise bills report
     */
    public function customerSales(Request $request)
    {
        $startDate = $request->query('start_date', now()->subMonths(1)->format('Y-m-d'));
        $endDate = $request->query('end_date', date('Y-m-d'));

        // Customer-wise totals
        $customerBills = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->with('customer')
                            ->get()
                            ->groupBy('customer_id')
                            ->map(function($bills, $customerId) {
                                $customer = $customerId ? Customer::find($customerId) : null;
                                return [
                                    'customer' => $customer,
                                    'total_amount' => $bills->sum('net_amount'),
                                    'earned' => $bills->sum('amount_paid'),
                                    'debt' => $bills->sum('debt_amount'),
                                    'total_transactions' => $bills->count(),
                                    'average_sale' => $bills->avg('net_amount'),
                                ];
                            })
                            ->sortByDesc('total_amount')
                            ->values();

        // Walk-in (anonymous) bills
        $walkInBills = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->whereNull('customer_id')
                            ->get();

        $walkInTotal = $walkInBills->sum('net_amount');
        $walkInEarned = $walkInBills->sum('amount_paid');
        $walkInDebt = $walkInBills->sum('debt_amount');

        // Overall totals
        $overallTotal = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('net_amount');
        $overallEarned = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('amount_paid');
        $overallDebt = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('debt_amount');

        return view('admin.reports.customer-sales', compact(
            'customerBills',
            'walkInTotal',
            'walkInEarned',
            'walkInDebt',
            'walkInBills',
            'overallTotal',
            'overallEarned',
            'overallDebt',
            'startDate',
            'endDate'
        ));
    }

    /**
     * Export customer-wise sales report to CSV
     */
    public function exportCustomerSales(Request $request)
    {
        $startDate = $request->query('start_date', now()->subMonths(1)->format('Y-m-d'));
        $endDate = $request->query('end_date', date('Y-m-d'));

        // Customer-wise totals
        $customerBills = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->with('customer')
                            ->get()
                            ->groupBy('customer_id')
                            ->map(function($bills, $customerId) {
                                $customer = $customerId ? Customer::find($customerId) : null;
                                return [
                                    'customer' => $customer,
                                    'total_amount' => $bills->sum('net_amount'),
                                    'earned' => $bills->sum('amount_paid'),
                                    'debt' => $bills->sum('debt_amount'),
                                    'total_transactions' => $bills->count(),
                                    'average_sale' => $bills->avg('net_amount'),
                                ];
                            })
                            ->sortByDesc('total_amount')
                            ->values();

        // Walk-in (anonymous) bills
        $walkInBills = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->whereNull('customer_id')
                            ->get();

        $walkInTotal = $walkInBills->sum('net_amount');
        $walkInEarned = $walkInBills->sum('amount_paid');
        $walkInDebt = $walkInBills->sum('debt_amount');

        // Overall totals
        $overallTotal = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('net_amount');
        $overallEarned = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('amount_paid');
        $overallDebt = Bill::whereDate('bill_date', '>=', $startDate)
                            ->whereDate('bill_date', '<=', $endDate)
                            ->sum('debt_amount');

        // Create CSV content
        $csv = "Customer-Wise Sales Report - " . date('d M Y', strtotime($startDate)) . " to " . date('d M Y', strtotime($endDate)) . "\n";
        $csv .= "Generated on: " . now()->format('d M Y H:i A') . "\n\n";

        // Overall Summary
        $csv .= "OVERALL SUMMARY\n";
        $csv .= "Total Revenue,Total Earned,Total Debt,Total Customers\n";
        $csv .= number_format($overallTotal, 2) . "," . number_format($overallEarned, 2) . "," . number_format($overallDebt, 2) . "," . ($customerBills->count() + ($walkInBills->count() > 0 ? 1 : 0)) . "\n\n";

        // Customer-wise details
        $csv .= "CUSTOMER-WISE DETAILS\n";
        $csv .= "Customer Name,Total Amount,Amount Earned,Debt Amount,Transactions,Average Sale\n";

        foreach ($customerBills as $data) {
            if ($data['customer']) {
                $csv .= "\"" . $data['customer']->name . "\"," . 
                        number_format($data['total_amount'], 2) . "," . 
                        number_format($data['earned'], 2) . "," . 
                        number_format($data['debt'], 2) . "," . 
                        $data['total_transactions'] . "," . 
                        number_format($data['average_sale'], 2) . "\n";
            }
        }

        // Walk-in customers
        if ($walkInBills->count() > 0) {
            $csv .= "\"Walk-in Customers\"," . 
                    number_format($walkInTotal, 2) . "," . 
                    number_format($walkInEarned, 2) . "," . 
                    number_format($walkInDebt, 2) . "," . 
                    $walkInBills->count() . "," . 
                    number_format($walkInBills->avg('net_amount'), 2) . "\n";
        }

        // Prepare response
        $filename = 'customer-sales-' . $startDate . '-to-' . $endDate . '.csv';
        $headers = [
            "Content-Type" => "text/csv; charset=utf-8",
            "Content-Disposition" => "attachment; filename=\"$filename\"",
        ];

        return response()->make($csv, 200, $headers);
    }

    /**
     * Weekly bills report
     */
    public function weeklySales(Request $request)
    {
        $year = $request->query('year', date('Y'));
        $week = $request->query('week', now()->weekOfYear);

        $startDate = Carbon::now()->setISODate($year, $week)->startOfWeek();
        $endDate = $startDate->copy()->endOfWeek();

        $weeklyBills = Bill::whereBetween('bill_date', [$startDate, $endDate])
                          ->with('customer')
                          ->orderBy('bill_date')
                          ->get();

        // Group by day
        $billsByDay = $weeklyBills->groupBy(function($bill) {
            return $bill->bill_date->format('Y-m-d');
        })->map(function($bills) {
            return [
                'count' => $bills->count(),
                'amount' => $bills->sum('net_amount'),
                'earned' => $bills->sum('amount_paid'),
                'debt' => $bills->sum('debt_amount'),
                'average' => $bills->avg('net_amount'),
            ];
        });

        $totalRevenue = $weeklyBills->sum('net_amount');
        $totalEarned = $weeklyBills->sum('amount_paid');
        $totalDebt = $weeklyBills->sum('debt_amount');
        $totalBills = $weeklyBills->count();

        return view('admin.reports.weekly-sales', compact(
            'weeklyBills',
            'billsByDay',
            'totalRevenue',
            'totalEarned',
            'totalDebt',
            'totalBills',
            'startDate',
            'endDate',
            'year',
            'week'
        ));
    }

    /**
     * Monthly bills report
     */
    public function monthlySales(Request $request)
    {
        $year = $request->query('year', date('Y'));
        $month = $request->query('month', date('m'));

        $startDate = Carbon::createFromDate($year, $month, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();

        $monthlyBills = Bill::whereBetween('bill_date', [$startDate, $endDate])
                           ->with('customer')
                           ->orderBy('bill_date')
                           ->get();

        // Group by day
        $billsByDay = $monthlyBills->groupBy(function($bill) {
            return $bill->bill_date->format('Y-m-d');
        })->map(function($bills) {
            return [
                'count' => $bills->count(),
                'amount' => $bills->sum('net_amount'),
                'earned' => $bills->sum('amount_paid'),
                'debt' => $bills->sum('debt_amount'),
                'average' => $bills->avg('net_amount'),
            ];
        });

        // Top customers
        $topCustomers = $monthlyBills->filter(fn($b) => $b->customer_id !== null)
                                    ->groupBy('customer_id')
                                    ->map(function($bills) {
                                        $customer = $bills->first()->customer;
                                        return [
                                            'customer' => $customer,
                                            'amount' => $bills->sum('net_amount'),
                                            'earned' => $bills->sum('amount_paid'),
                                            'debt' => $bills->sum('debt_amount'),
                                            'count' => $bills->count(),
                                        ];
                                    })
                                    ->sortByDesc('amount')
                                    ->take(10);

        $totalRevenue = $monthlyBills->sum('net_amount');
        $totalEarned = $monthlyBills->sum('amount_paid');
        $totalDebt = $monthlyBills->sum('debt_amount');
        $totalBills = $monthlyBills->count();
        $averageBill = $totalBills > 0 ? $totalRevenue / $totalBills : 0;

        return view('admin.reports.monthly-sales', compact(
            'monthlyBills',
            'billsByDay',
            'topCustomers',
            'totalRevenue',
            'totalEarned',
            'totalDebt',
            'totalBills',
            'averageBill',
            'startDate',
            'endDate',
            'year',
            'month'
        ));
    }

    /**
     * Yearly bills report
     */
    public function yearlySales(Request $request)
    {
        $year = $request->query('year', date('Y'));

        $startDate = Carbon::createFromDate($year, 1, 1)->startOfYear();
        $endDate = $startDate->copy()->endOfYear();

        $yearlyBills = Bill::whereBetween('bill_date', [$startDate, $endDate])
                          ->with('customer')
                          ->get();

        // Group by month
        $billsByMonth = $yearlyBills->groupBy(function($bill) {
            return $bill->bill_date->format('Y-m');
        })->map(function($bills) {
            return [
                'count' => $bills->count(),
                'amount' => $bills->sum('net_amount'),
                'earned' => $bills->sum('amount_paid'),
                'debt' => $bills->sum('debt_amount'),
                'average' => $bills->avg('net_amount'),
            ];
        });

        $totalRevenue = $yearlyBills->sum('net_amount');
        $totalEarned = $yearlyBills->sum('amount_paid');
        $totalDebt = $yearlyBills->sum('debt_amount');
        $totalBills = $yearlyBills->count();
        $averageBill = $totalBills > 0 ? $totalRevenue / $totalBills : 0;

        return view('admin.reports.yearly-sales', compact(
            'yearlyBills',
            'billsByMonth',
            'totalRevenue',
            'totalEarned',
            'totalDebt',
            'totalBills',
            'averageBill',
            'year'
        ));
    }

    /**
     * Export daily sales report to CSV/Excel
     */
    public function exportDailySales(Request $request)
    {
        $date = $request->query('date', date('Y-m-d'));
        
        $bills = Bill::whereDate('bill_date', $date)
                    ->with('customer')
                    ->orderBy('created_at', 'desc')
                    ->get();

        $totalRevenue = $bills->sum('net_amount');
        $earnedAmount = $bills->sum('amount_paid');
        $debtAmount = $bills->sum('debt_amount');
        $totalBills = $bills->count();
        $averageBill = $totalBills > 0 ? $totalRevenue / $totalBills : 0;

        // Create CSV content
        $csv = "Daily Sales Report - " . date('d M Y', strtotime($date)) . "\n";
        $csv .= "Generated on: " . now()->format('d M Y H:i A') . "\n\n";

        // Summary section
        $csv .= "SUMMARY\n";
        $csv .= "Total Revenue,Total Paid,Total Debt,Total Bills,Average Bill\n";
        $csv .= number_format($totalRevenue, 2) . "," . number_format($earnedAmount, 2) . "," . number_format($debtAmount, 2) . "," . $totalBills . "," . number_format($averageBill, 2) . "\n\n";

        // Bills details
        $csv .= "BILL DETAILS\n";
        $csv .= "Invoice #,Customer,Net Amount,Amount Paid,Debt Amount,Payment Status,Payment Method\n";

        foreach ($bills as $bill) {
            $customer = $bill->customer?->name ?? 'Walk-in Customer';
            $csv .= "\"" . $bill->invoice_number . "\",\"" . $customer . "\"," . 
                    number_format($bill->net_amount, 2) . "," . 
                    number_format($bill->amount_paid ?? 0, 2) . "," . 
                    number_format($bill->debt_amount ?? 0, 2) . ",\"" . 
                    ucfirst($bill->payment_status) . "\",\"" . ($bill->payment_method ?? 'N/A') . "\"\n";
        }

        // Prepare response
        $filename = 'daily-sales-' . $date . '.csv';
        $headers = [
            "Content-Type" => "text/csv; charset=utf-8",
            "Content-Disposition" => "attachment; filename=\"$filename\"",
        ];

        return response()->make($csv, 200, $headers);
    }
}

