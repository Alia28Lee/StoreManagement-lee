<?php

namespace App\Http\Controllers;

use App\Models\Purchase;
use App\Models\PurchaseItem;
use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PurchaseReportController extends Controller
{
    public function index()
    {
        return view('admin.purchase-reports.index');
    }

    public function daily(Request $request)
    {
        $date = $request->input('date', Carbon::today()->format('Y-m-d'));
        
        $purchases = Purchase::whereDate('purchase_date', $date)
                            ->with('purchaseItems.product.category')
                            ->get();

        $reportData = $this->groupByCategory($purchases);
        
        $totals = [
            'total_quantity' => $purchases->sum(fn($p) => $p->purchaseItems->sum('quantity')),
            'total_amount' => $purchases->sum('total_amount'),
            'total_paid' => $purchases->sum('paid_amount'),
            'total_debt' => $purchases->sum('debt_amount'),
            'purchases_count' => $purchases->count(),
        ];

        return view('admin.purchase-reports.daily', compact('reportData', 'totals', 'date'));
    }

    public function weekly(Request $request)
    {
        $endDate = $request->input('date', Carbon::today()->format('Y-m-d'));
        $date = Carbon::parse($endDate);
        $startDate = $date->copy()->startOfWeek()->format('Y-m-d');
        $endDate = $date->copy()->endOfWeek()->format('Y-m-d');
        
        $purchases = Purchase::whereBetween('purchase_date', [$startDate, $endDate])
                            ->with('purchaseItems.product.category')
                            ->get();

        $reportData = $this->groupByCategory($purchases);
        
        $totals = [
            'total_quantity' => $purchases->sum(fn($p) => $p->purchaseItems->sum('quantity')),
            'total_amount' => $purchases->sum('total_amount'),
            'total_paid' => $purchases->sum('paid_amount'),
            'total_debt' => $purchases->sum('debt_amount'),
            'purchases_count' => $purchases->count(),
        ];

        $weekRange = "$startDate to $endDate";

        return view('admin.purchase-reports.weekly', compact('reportData', 'totals', 'weekRange'));
    }

    public function monthly(Request $request)
    {
        $month = $request->input('month', Carbon::now()->format('Y-m'));
        
        $startDate = Carbon::parse($month . '-01')->startOfMonth()->format('Y-m-d');
        $endDate = Carbon::parse($month . '-01')->endOfMonth()->format('Y-m-d');
        
        $purchases = Purchase::whereBetween('purchase_date', [$startDate, $endDate])
                            ->with('purchaseItems.product.category')
                            ->get();

        $reportData = $this->groupByCategory($purchases);
        
        $totals = [
            'total_quantity' => $purchases->sum(fn($p) => $p->purchaseItems->sum('quantity')),
            'total_amount' => $purchases->sum('total_amount'),
            'total_paid' => $purchases->sum('paid_amount'),
            'total_debt' => $purchases->sum('debt_amount'),
            'purchases_count' => $purchases->count(),
        ];

        return view('admin.purchase-reports.monthly', compact('reportData', 'totals', 'month'));
    }

    public function yearly(Request $request)
    {
        $year = $request->input('year', Carbon::now()->format('Y'));
        
        $startDate = "$year-01-01";
        $endDate = "$year-12-31";
        
        $purchases = Purchase::whereBetween('purchase_date', [$startDate, $endDate])
                            ->with('purchaseItems.product.category')
                            ->get();

        $reportData = $this->groupByCategory($purchases);
        
        $totals = [
            'total_quantity' => $purchases->sum(fn($p) => $p->purchaseItems->sum('quantity')),
            'total_amount' => $purchases->sum('total_amount'),
            'total_paid' => $purchases->sum('paid_amount'),
            'total_debt' => $purchases->sum('debt_amount'),
            'purchases_count' => $purchases->count(),
        ];

        return view('admin.purchase-reports.yearly', compact('reportData', 'totals', 'year'));
    }

    private function groupByCategory($purchases)
    {
        $grouped = [];

        foreach ($purchases as $purchase) {
            foreach ($purchase->purchaseItems as $item) {
                $category = $item->product->category;
                $categoryName = $category ? $category->name : 'Uncategorized';

                if (!isset($grouped[$categoryName])) {
                    $grouped[$categoryName] = [];
                }

                $productName = $item->product->name;
                if (!isset($grouped[$categoryName][$productName])) {
                    $grouped[$categoryName][$productName] = [
                        'quantity' => 0,
                        'unit' => $item->product->unit,
                        'total_amount' => 0,
                        'items_count' => 0,
                    ];
                }

                $grouped[$categoryName][$productName]['quantity'] += $item->quantity;
                $grouped[$categoryName][$productName]['total_amount'] += $item->total_price;
                $grouped[$categoryName][$productName]['items_count'] += 1;
            }
        }

        return $grouped;
    }
}
