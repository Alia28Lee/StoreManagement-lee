<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;

class StockController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with('category');

        // Apply filters
        if ($request->filled('search')) {
            $query->where('name', 'like', "%{$request->input('search')}%");
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->input('category_id'));
        }

        if ($request->filled('status')) {
            $status = $request->input('status');
            if ($status === 'low') {
                $query->whereColumn('current_stock', '<=', 'reorder_level');
            } elseif ($status === 'caution') {
                $query->whereRaw('current_stock > reorder_level AND current_stock <= (reorder_level * 1.5)');
            } elseif ($status === 'in_stock') {
                $query->whereRaw('current_stock > (reorder_level * 1.5)');
            }
        }

        $products = $query->orderBy('name')->get();
        
        $stats = [
            'total_items' => $products->count(),
            'low_stock_items' => $products->where('current_stock', '<=', function($q) {
                return $q->reorder_level;
            })->count() ?? 0,
            'total_stock_value' => $products->sum(function($p) {
                return $p->current_stock * 100; // Assume average price for display
            }),
        ];

        $lowStockItems = $products->filter(function($product) {
            return $product->current_stock <= $product->reorder_level;
        });

        $categories = Category::orderBy('name')->get();

        return view('admin.stock.index', compact('products', 'stats', 'lowStockItems', 'categories'));
    }

    public function show(Product $product)
    {
        $product->load('purchaseItems');
        $recentPurchases = $product->purchaseItems()
                                    ->with('purchase')
                                    ->orderBy('created_at', 'desc')
                                    ->take(10)
                                    ->get();
        return view('admin.stock.show', compact('product', 'recentPurchases'));
    }
}
