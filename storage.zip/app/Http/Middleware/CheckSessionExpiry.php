<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckSessionExpiry
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Check if user is authenticated
        if (Auth::guard('admin')->check()) {
            // Get the last activity time from session
            $lastActivity = session('last_activity');
            $timeout = config('session.lifetime') * 60; // Convert minutes to seconds

            // If last activity exists and timeout has passed
            if ($lastActivity && (time() - $lastActivity) > $timeout) {
                // Logout the user
                Auth::guard('admin')->logout();
                session()->flush();
                
                return redirect()->route('admin.login')
                                ->withErrors([
                                    'session' => '⏱️ Your session has expired due to inactivity. Please log in again.'
                                ]);
            }

            // Update last activity time
            session(['last_activity' => time()]);
        }

        return $next($request);
    }
}
