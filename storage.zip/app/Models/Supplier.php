<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable = [
        'name',
        'email',
        'phone',
        'address',
        'city',
        'state',
        'postal_code',
        'notes',
    ];

    public function purchases()
    {
        return $this->hasMany(Purchase::class);
    }
}
