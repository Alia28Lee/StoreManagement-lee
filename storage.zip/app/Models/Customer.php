<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    protected $fillable = [
        'name',
        'email',
        'phone',
        'address',
        'city',
        'state',
        'postal_code',
        'debit_balance',
        'notes',
    ];

    protected $casts = [
        'debit_balance' => 'decimal:2',
    ];

    public function bills()
    {
        return $this->hasMany(Bill::class);
    }
}
