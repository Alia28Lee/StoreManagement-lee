<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    protected $fillable = [
        'invoice_number',
        'customer_id',
        'bill_date',
        'total_amount',
        'discount_amount',
        'net_amount',
        'amount_paid',
        'debt_amount',
        'payment_status',
        'payment_method',
        'notes',
    ];

    protected $casts = [
        'bill_date' => 'date',
        'total_amount' => 'decimal:2',
        'discount_amount' => 'decimal:2',
        'net_amount' => 'decimal:2',
        'amount_paid' => 'decimal:2',
        'debt_amount' => 'decimal:2',
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function billItems()
    {
        return $this->hasMany(BillItem::class);
    }

    public function calculateTotal()
    {
        $this->total_amount = $this->billItems->sum('item_total');
        $this->net_amount = $this->total_amount - $this->discount_amount;
        return $this;
    }
}
