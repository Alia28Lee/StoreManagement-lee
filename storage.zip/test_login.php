<?php

require 'vendor/autoload.php';

$app = require __DIR__ . '/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Auth;

$email = 'admin@storeadmin.com';
$password = 'admin@123';

echo "=== LOGIN SIMULATION ===\n\n";
echo "Email: $email\n";
echo "Password: $password\n\n";

// Try the attempt
$credentials = ['email' => $email, 'password' => $password];
$success = Auth::guard('admin')->attempt($credentials);

echo "Attempt Result: " . ($success ? "✅ SUCCESS - User authenticated" : "❌ FAILED") . "\n\n";

if($success) {
    $user = Auth::guard('admin')->user();
    echo "Authenticated User:\n";
    echo "  ID: " . $user->id . "\n";
    echo "  Email: " . $user->email . "\n";
    echo "  Name: " . $user->name . "\n";
    
    if($user->profile) {
        echo "  Profile Role: " . $user->profile->role . "\n";
        echo "  Profile Active: " . ($user->profile->is_active ? "Yes" : "No") . "\n";
        
        if($user->profile->role === 'admin' || $user->profile->role === 'superadmin') {
            echo "\n✅ User has admin/superadmin role - LOGIN SUCCESS\n";
        } else {
            echo "\n❌ User does not have admin role\n";
        }
    } else {
        echo "  ❌ NO PROFILE FOUND\n";
    }
} else {
    echo "Failed to authenticate. Checking why...\n";
    
    $user = User::where('email', $email)->first();
    if($user) {
        echo "  ✅ User exists in database\n";
        
        $passwordValid = \Illuminate\Support\Facades\Hash::check($password, $user->password);
        echo "  Password valid: " . ($passwordValid ? "✅ Yes" : "❌ No") . "\n";
        
        if($user->profile) {
            echo "  Profile exists: ✅ Yes\n";
            echo "  Role: " . $user->profile->role . "\n";
        } else {
            echo "  ❌ Profile does not exist\n";
        }
    } else {
        echo "  ❌ User not found in database\n";
    }
}

// Reset auth
Auth::guard('admin')->logout();
