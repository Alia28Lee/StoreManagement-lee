@extends('admin.layout')

@section('title', $product->name . ' - Stock Details')

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>{{ $product->name }}</h1>
            <p>Stock History & Details</p>
        </div>
        <a href="{{ route('admin.inventory.stock.index') }}" class="btn btn-secondary">Back to Stock</a>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div class="card">
            <div class="card-header">
                <h3>Product Information</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Name:</span>
                    <span class="value">{{ $product->name }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Category:</span>
                    <span class="value">{{ $product->category?->name ?? 'N/A' }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">SKU:</span>
                    <span class="value">{{ $product->sku ?? '-' }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Unit:</span>
                    <span class="value">{{ $product->unit }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Description:</span>
                    <span class="value">{{ $product->description ?? 'N/A' }}</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Stock Status</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Current Stock:</span>
                    <span class="value" style="font-size: 18px; font-weight: bold;">{{ number_format($product->current_stock, 2) }} {{ $product->unit }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Reorder Level:</span>
                    <span class="value">{{ number_format($product->reorder_level, 2) }} {{ $product->unit }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Status:</span>
                    <span class="value">
                        @if($product->current_stock > $product->reorder_level * 1.5)
                            <span class="badge badge-success">✓ In Stock</span>
                        @elseif($product->current_stock > $product->reorder_level)
                            <span class="badge badge-warning">⚠ Caution - Approaching Low Stock</span>
                        @else
                            <span class="badge badge-danger">🔴 Low Stock - Reorder Required</span>
                        @endif
                    </span>
                </div>
                <div class="detail-row">
                    <span class="label">Days to Reorder:</span>
                    <span class="value">
                        @if($product->current_stock <= $product->reorder_level)
                            <strong style="color: red;">URGENT</strong>
                        @else
                            Normal
                        @endif
                    </span>
                </div>
            </div>
        </div>
    </div>

    @if($recentPurchases->count() > 0)
        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3>Recent Purchases</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>Supplier</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Price</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recentPurchases as $purchaseItem)
                                <tr>
                                    <td>
                                        <a href="{{ route('admin.inventory.purchases.show', $purchaseItem->purchase) }}">
                                            {{ $purchaseItem->purchase->reference_number }}
                                        </a>
                                    </td>
                                    <td>{{ $purchaseItem->purchase->supplier_name }}</td>
                                    <td>{{ number_format($purchaseItem->quantity, 2) }} {{ $product->unit }}</td>
                                    <td>₹{{ number_format($purchaseItem->unit_price, 2) }}</td>
                                    <td>₹{{ number_format($purchaseItem->total_price, 2) }}</td>
                                    <td>{{ $purchaseItem->created_at->format('d M Y') }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @else
        <div class="alert alert-info" style="margin-top: 20px;">
            No purchase history available for this product.
        </div>
    @endif
</div>

<style>
.badge { padding: 6px 10px; border-radius: 4px; font-size: 12px; font-weight: bold; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
@endsection
