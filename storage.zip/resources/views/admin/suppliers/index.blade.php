@extends('admin.layout')

@section('title', 'Suppliers')

@section('content')
<div class="page-header">
    <div>
        <h1>Suppliers</h1>
        <p>Manage your suppliers and vendors</p>
    </div>
    <a href="{{ route('admin.inventory.suppliers.create') }}" class="btn btn-primary">+ Add New Supplier</a>
</div>

@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<!-- Filter Form -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
        <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
    </div>
    <div class="card-body" style="padding: 15px;">
        <form method="GET" action="{{ route('admin.inventory.suppliers.index') }}" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: end;">
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Search (Name, Email, Phone)</label>
                <input type="text" name="search" placeholder="Search suppliers..." value="{{ request('search') }}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">City</label>
                <select name="city" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- All Cities --</option>
                    @foreach($cities as $city)
                        <option value="{{ $city }}" {{ request('city') === $city ? 'selected' : '' }}>{{ $city }}</option>
                    @endforeach
                </select>
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                <a href="{{ route('admin.inventory.suppliers.index') }}" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
            </div>
        </form>
    </div>
</div>

@if ($suppliers->count() > 0)
    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($suppliers as $supplier)
                        <tr>
                            <td>#{{ $supplier->id }}</td>
                            <td>{{ $supplier->name ?? 'Anonymous' }}</td>
                            <td>{{ $supplier->email ?? 'N/A' }}</td>
                            <td>{{ $supplier->phone ?? 'N/A' }}</td>
                            <td>{{ $supplier->city ?? 'N/A' }}</td>
                            <td class="action-links">
                                <a href="{{ route('admin.inventory.suppliers.show', $supplier) }}" class="btn-sm btn-info">View</a>
                                <a href="{{ route('admin.inventory.suppliers.edit', $supplier) }}" class="btn-sm btn-warning">Edit</a>
                                <form action="{{ route('admin.inventory.suppliers.destroy', $supplier) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this supplier?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div style="text-align: center; padding: 20px;">
            {{ $suppliers->links() }}
        </div>
    </div>
@else
    <div class="empty-state">
        <h3>No suppliers found</h3>
        <p>Get started by <a href="{{ route('admin.inventory.suppliers.create') }}">adding a new supplier</a></p>
    </div>
@endif
@endsection
