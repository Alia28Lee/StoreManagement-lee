@extends('admin.layout')

@section('title', 'Add Supplier')

@section('content')
<h1>Add New Supplier</h1>

<form action="{{ route('admin.inventory.suppliers.store') }}" method="POST" class="form">
    @csrf

    <div class="form-group">
        <label for="name">Supplier Name / <span class="devanagari">संधधकता का नाम</span> (leave blank for anonymous)</label>
        <input
            type="text"
            id="name"
            name="name"
            class="form-control @error('name') is-invalid @enderror"
            value="{{ old('name') }}"
            placeholder="Enter supplier name"
        >
        @error('name') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="email">Email Address / <span class="devanagari">ईमेल पता</span></label>
        <input
            type="email"
            id="email"
            name="email"
            class="form-control @error('email') is-invalid @enderror"
            value="{{ old('email') }}"
            placeholder="supplier@example.com"
        >
        @error('email') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="phone">Phone Number / <span class="devanagari">फोन नंबर</span></label>
        <input
            type="tel"
            id="phone"
            name="phone"
            class="form-control @error('phone') is-invalid @enderror"
            value="{{ old('phone') }}"
            placeholder="+1 (555) 123-4567"
        >
        @error('phone') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="address">Street Address / <span class="devanagari">सड़क का पता</span></label>
        <input
            type="text"
            id="address"
            name="address"
            class="form-control @error('address') is-invalid @enderror"
            value="{{ old('address') }}"
            placeholder="123 Main Street"
        >
        @error('address') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="city">City / <span class="devanagari">शहर</span></label>
            <input
                type="text"
                id="city"
                name="city"
                class="form-control @error('city') is-invalid @enderror"
                value="{{ old('city') }}"
                placeholder="New York"
            >
            @error('city') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="state">State/Province / <span class="devanagari">रऺज्म</span></label>
            <input
                type="text"
                id="state"
                name="state"
                class="form-control @error('state') is-invalid @enderror"
                value="{{ old('state') }}"
                placeholder="NY"
            >
            @error('state') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="postal_code">Postal Code / <span class="devanagari">पिन कोड</span></label>
            <input
                type="text"
                id="postal_code"
                name="postal_code"
                class="form-control @error('postal_code') is-invalid @enderror"
                value="{{ old('postal_code') }}"
                placeholder="10001"
            >
            @error('postal_code') <span class="error">{{ $message }}</span> @enderror
        </div>
    </div>

    <div class="form-group">
        <label for="notes">Notes / <span class="devanagari">सूसपाठें</span></label>
        <textarea
            id="notes"
            name="notes"
            class="form-control @error('notes') is-invalid @enderror"
            rows="4"
            placeholder="Add any additional notes about this supplier..."
        >{{ old('notes') }}</textarea>
        @error('notes') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Save Supplier</button>
        <a href="{{ route('admin.inventory.suppliers.index') }}" class="btn btn-secondary">Cancel</a>
    </div>
</form>
@endsection
