@extends('admin.layout')

@section('title', 'Edit Supplier')

@section('content')
<h1>Edit Supplier</h1>

<form action="{{ route('admin.inventory.suppliers.update', $supplier) }}" method="POST" class="form">
    @csrf
    @method('PUT')

    <div class="form-group">
        <label for="name">Supplier Name (leave blank for anonymous)</label>
        <input
            type="text"
            id="name"
            name="name"
            class="form-control @error('name') is-invalid @enderror"
            value="{{ old('name', $supplier->name) }}"
            placeholder="Enter supplier name"
        >
        @error('name') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="email">Email Address</label>
        <input
            type="email"
            id="email"
            name="email"
            class="form-control @error('email') is-invalid @enderror"
            value="{{ old('email', $supplier->email) }}"
            placeholder="supplier@example.com"
        >
        @error('email') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="phone">Phone Number</label>
        <input
            type="tel"
            id="phone"
            name="phone"
            class="form-control @error('phone') is-invalid @enderror"
            value="{{ old('phone', $supplier->phone) }}"
            placeholder="+1 (555) 123-4567"
        >
        @error('phone') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-group">
        <label for="address">Street Address</label>
        <input
            type="text"
            id="address"
            name="address"
            class="form-control @error('address') is-invalid @enderror"
            value="{{ old('address', $supplier->address) }}"
            placeholder="123 Main Street"
        >
        @error('address') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-row">
        <div class="form-group">
            <label for="city">City</label>
            <input
                type="text"
                id="city"
                name="city"
                class="form-control @error('city') is-invalid @enderror"
                value="{{ old('city', $supplier->city) }}"
                placeholder="New York"
            >
            @error('city') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="state">State/Province</label>
            <input
                type="text"
                id="state"
                name="state"
                class="form-control @error('state') is-invalid @enderror"
                value="{{ old('state', $supplier->state) }}"
                placeholder="NY"
            >
            @error('state') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="postal_code">Postal Code</label>
            <input
                type="text"
                id="postal_code"
                name="postal_code"
                class="form-control @error('postal_code') is-invalid @enderror"
                value="{{ old('postal_code', $supplier->postal_code) }}"
                placeholder="10001"
            >
            @error('postal_code') <span class="error">{{ $message }}</span> @enderror
        </div>
    </div>

    <div class="form-group">
        <label for="notes">Notes</label>
        <textarea
            id="notes"
            name="notes"
            class="form-control @error('notes') is-invalid @enderror"
            rows="4"
            placeholder="Add any additional notes about this supplier..."
        >{{ old('notes', $supplier->notes) }}</textarea>
        @error('notes') <span class="error">{{ $message }}</span> @enderror
    </div>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Update Supplier</button>
        <a href="{{ route('admin.inventory.suppliers.index') }}" class="btn btn-secondary">Cancel</a>
    </div>
</form>
@endsection
