@extends('admin.layout')
@section('title', 'Supplier Details')

@section('content')
    <div class="container">
        <a href="{{ route('admin.inventory.suppliers.index') }}" class="back-link">← Back to Suppliers</a>

        <div class="header">
            <h2>{{ $supplier->name ?? 'Anonymous' }}</h2>
            <div class="header-actions">
                <a href="{{ route('admin.inventory.suppliers.edit', $supplier) }}" class="btn-sm btn-warning">Edit</a>
                <form action="{{ route('admin.inventory.suppliers.destroy', $supplier) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this supplier?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn-sm btn-danger">Delete</button>
                </form>
            </div>
        </div>

        <div class="info-card">
            <div class="info-section">
                <h3>Contact Information</h3>
                <div class="info-row">
                    <span class="info-label">Email</span>
                    <span class="info-value">{{ $supplier->email ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Phone</span>
                    <span class="info-value">{{ $supplier->phone ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>Address</h3>
                <div class="info-row">
                    <span class="info-label">Street</span>
                    <span class="info-value">{{ $supplier->address ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">City</span>
                    <span class="info-value">{{ $supplier->city ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">State</span>
                    <span class="info-value">{{ $supplier->state ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Postal Code</span>
                    <span class="info-value">{{ $supplier->postal_code ?? '<span class="empty">Not provided</span>' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>Additional Notes</h3>
                <div class="info-row">
                    <span class="info-value">{{ $supplier->notes ?? '<span class="empty">No notes added</span>' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>Related Purchases</h3>
                @if($supplier->purchases->count() > 0)
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Reference #</th>
                                    <th>Date</th>
                                    <th>Total Amount</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($supplier->purchases as $purchase)
                                    <tr>
                                        <td>{{ $purchase->reference_number }}</td>
                                        <td>{{ $purchase->purchase_date->format('M d, Y') }}</td>
                                        <td>₹{{ number_format($purchase->total_amount, 2) }}</td>
                                        <td>
                                            <span class="badge @if($purchase->payment_status === 'Paid') badge-success @elseif($purchase->payment_status === 'Partial') badge-warning @else badge-danger @endif">
                                                {{ $purchase->payment_status }}
                                            </span>
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.inventory.purchases.show', $purchase) }}" class="btn-sm btn-info">View</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <p><em>No purchases found for this supplier</em></p>
                @endif
            </div>

            <div class="info-section">
                <h3>System Information</h3>
                <div class="info-row">
                    <span class="info-label">Created</span>
                    <span class="info-value">{{ $supplier->created_at->format('M d, Y \a\t h:i A') }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Updated</span>
                    <span class="info-value">{{ $supplier->updated_at->format('M d, Y \a\t h:i A') }}</span>
                </div>
            </div>
        </div>
    </div>
@endsection
