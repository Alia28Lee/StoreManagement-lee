<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Admin Dashboard</title>
    <!-- Google Font for Hindi Devanagari Support -->
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Devanagari:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            font-size: 16px;
        }

        .devanagari {
            font-family: 'Noto Sans Devanagari', sans-serif;
            font-weight: 500;
        }

        /* Navbar Responsive */
        .navbar {
            background: white;
            padding: 15px 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 3px solid #667eea;
            flex-wrap: wrap;
            gap: 10px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .navbar h1 {
            color: #333;
            font-size: clamp(16px, 4vw, 24px);
        }

        .navbar .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .navbar .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s;
            font-size: 12px;
        }

        .navbar .logout-btn:hover {
            background: #c0392b;
        }

        /* Sidebar - Hidden on mobile, visible on desktop */
        .sidebar {
            position: fixed;
            left: 0;
            top: 60px;
            width: 250px;
            height: calc(100vh - 60px);
            background: white;
            border-right: 1px solid #ddd;
            padding: 20px 0;
            overflow-y: auto;
            transition: left 0.3s ease;
            z-index: 50;
        }

        .sidebar.active {
            left: 0;
        }

        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: #666;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
            font-size: 14px;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #f5f5f5;
            color: #667eea;
            border-left-color: #667eea;
        }

        .sidebar .menu-section {
            color: #999;
            font-size: 11px;
            font-weight: 600;
            padding: 15px 20px 5px;
            text-transform: uppercase;
            margin-top: 10px;
        }

        /* Toggle button for sidebar on mobile */
        .mobile-menu-toggle {
            display: none;
            background: #667eea;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .main-content {
            margin-left: 250px;
            padding-top: 0;
            transition: margin-left 0.3s ease;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 15px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header > div:first-child h1 {
            color: #333;
            font-size: clamp(20px, 6vw, 28px);
            margin-bottom: 5px;
        }

        .page-header > div:first-child p {
            color: #999;
            font-size: 13px;
        }

        .btn, .btn-primary, .btn-secondary, .btn-danger, .btn-info, .btn-warning {
            padding: 10px 16px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-block;
            font-size: 13px;
            white-space: nowrap;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .btn-danger {
            background: #e74c3c;
            color: white;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        .btn-warning {
            background: #ffc107;
            color: #333;
        }

        .btn-warning:hover {
            background: #e0a800;
        }

        .alert {
            padding: 12px 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            border-left: 4px solid;
            font-size: 13px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left-color: #28a745;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border-left-color: #dc3545;
        }

        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border-left-color: #ffc107;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border-left-color: #17a2b8;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin-bottom: 20px;
        }

        .card-header {
            background: #f8f9fa;
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        .card-header h3 {
            margin: 0;
            color: #333;
            font-size: clamp(14px, 3vw, 16px);
        }

        .card-body {
            padding: 15px;
        }

        /* Responsive Table */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            font-size: 13px;
        }

        .table thead {
            background: #f8f9fa;
        }

        .table th {
            padding: 10px;
            text-align: left;
            color: #555;
            font-weight: 600;
            border-bottom: 2px solid #ddd;
            font-size: 12px;
        }

        .table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            color: #666;
        }

        .table tr:hover {
            background: #f9f9f9;
        }

        .action-links {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }

        .action-links a, .action-links button {
            padding: 5px 10px;
            font-size: 11px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            background: #667eea;
            color: white;
            transition: all 0.3s;
        }

        .action-links a:hover, .action-links button:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }

        /* Forms */
        .form {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            color: #333;
            font-weight: 500;
            font-size: 13px;
        }

        .form-control {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 13px;
            transition: border-color 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-control.is-invalid {
            border-color: #dc3545;
            background-color: #fff5f5;
        }

        .error {
            color: #dc3545;
            font-size: 12px;
            margin-top: 3px;
            display: block;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .pagination {
            display: flex;
            justify-content: center;
            gap: 3px;
            margin-top: 20px;
            flex-wrap: wrap;
        }

        .pagination a, .pagination span {
            padding: 6px 10px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 3px;
            text-decoration: none;
            color: #667eea;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 12px;
        }

        .pagination a:hover {
            background: #667eea;
            color: white;
        }

        .pagination .active span {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }

        .empty-state h3 {
            margin-bottom: 10px;
            color: #666;
            font-size: 18px;
        }

        .empty-state a {
            color: #667eea;
            text-decoration: none;
        }

        .empty-state a:hover {
            text-decoration: underline;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
            flex-wrap: wrap;
            gap: 10px;
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-row .label {
            font-weight: 600;
            color: #555;
            font-size: 13px;
        }

        .detail-row .value {
            color: #666;
            font-size: 13px;
        }

        /* Responsive Filters */
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 10px;
            margin-bottom: 20px;
        }

        .filter-row input, .filter-row select {
            width: 100%;
        }

        /* Mobile Menu Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 40;
        }

        .sidebar-overlay.active {
            display: block;
        }

        /* Tablet - 768px and below */
        @media (max-width: 768px) {
            .sidebar {
                left: -250px;
            }

            .main-content {
                margin-left: 0;
            }

            .navbar {
                padding: 12px 15px;
            }

            .navbar h1 {
                font-size: clamp(14px, 3vw, 18px);
            }

            .mobile-menu-toggle {
                display: block;
            }

            .page-header {
                flex-direction: column;
                align-items: stretch;
            }

            .page-header > div:last-child {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .table {
                font-size: 12px;
            }

            .table th, .table td {
                padding: 8px;
            }

            .action-links {
                flex-direction: column;
            }

            .action-links a, .action-links button {
                width: 100%;
                text-align: center;
            }

            .filter-row {
                grid-template-columns: 1fr;
            }

            .detail-row {
                flex-direction: column;
                align-items: flex-start;
            }

            .form-actions {
                flex-direction: column;
            }

            .form-actions button, .form-actions a {
                width: 100%;
            }
        }

        /* Mobile - 600px and below */
        @media (max-width: 600px) {
            body {
                font-size: 14px;
            }

            .container {
                padding: 0 10px;
                margin: 10px auto;
            }

            .navbar {
                padding: 10px;
                flex-direction: column;
                gap: 8px;
            }

            .navbar h1 {
                font-size: 14px;
                order: 2;
            }

            .navbar .user-info {
                order: 1;
                justify-content: space-between;
                width: 100%;
                gap: 5px;
            }

            .navbar .user-info p {
                font-size: 12px;
            }

            .navbar .logout-btn {
                padding: 6px 10px;
                font-size: 11px;
            }

            .page-header > div:first-child h1 {
                font-size: 18px;
            }

            .page-header > div:first-child p {
                font-size: 12px;
            }

            .page-header > div:last-child {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
                justify-content: stretch;
            }

            .page-header > div:last-child a,
            .page-header > div:last-child button {
                flex: 1;
                min-width: 80px;
            }

            .card {
                margin-bottom: 15px;
                border-radius: 6px;
            }

            .card-header {
                padding: 10px;
            }

            .card-body {
                padding: 10px;
            }

            .form {
                padding: 12px;
                border-radius: 6px;
            }

            .form-group {
                margin-bottom: 12px;
            }

            .form-control {
                padding: 8px;
                font-size: 16px; /* Prevents zoom on iOS */
            }

            .table-responsive {
                margin: 0 -10px;
                padding: 0 5px;
            }

            .table {
                font-size: 11px;
            }

            .table th, .table td {
                padding: 6px 4px;
            }

            .action-links a, .action-links button {
                padding: 4px 8px;
                font-size: 10px;
            }

            .btn, .btn-primary, .btn-secondary, .btn-danger {
                padding: 8px 12px;
                font-size: 12px;
                flex: 1;
            }

            .alert {
                padding: 10px 12px;
                font-size: 12px;
            }

            .empty-state {
                padding: 30px 15px;
            }

            .empty-state h3 {
                font-size: 16px;
            }

            .detail-row .label,
            .detail-row .value {
                font-size: 12px;
            }

            .pagination a, .pagination span {
                padding: 5px 8px;
                font-size: 10px;
            }

            .filter-row {
                gap: 8px;
            }

            fieldset {
                margin: 0;
                padding: 10px;
            }

            legend {
                font-size: 14px;
                padding: 0;
            }
        }

        /* Extra small - under 400px */
        @media (max-width: 400px) {
            .navbar h1 {
                font-size: 12px;
            }

            .page-header > div:first-child h1 {
                font-size: 14px;
            }

            .page-header > div:last-child a,
            .page-header > div:last-child button {
                min-width: 70px;
                padding: 6px 8px;
                font-size: 11px;
            }

            .table th, .table td {
                padding: 4px 2px;
                font-size: 10px;
            }

            .action-links a, .action-links button {
                padding: 3px 6px;
                font-size: 9px;
            }

            .form-group label {
                font-size: 12px;
            }

            .alert {
                padding: 8px;
                font-size: 11px;
            }

            .btn {
                padding: 6px 10px;
                font-size: 11px;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <button class="mobile-menu-toggle" id="menuToggle">☰ Menu</button>
        <h1>Admin Dashboard</h1>
        <div class="user-info">
            <p>Welcome, <strong>{{ Auth::guard('admin')->user()->name }}</strong></p>
            <form action="{{ route('admin.logout') }}" method="POST" style="display: inline;">
                @csrf
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>

    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <div class="sidebar">
        <div class="menu-section">Main</div>
        <a href="{{ route('admin.dashboard') }}" class="@if(Route::currentRouteName() == 'admin.dashboard') active @endif">📊 Dashboard</a>

        <div class="menu-section">System Administration</div>
        <a href="{{ route('admin.users.index') }}" class="@if(str_contains(Route::currentRouteName(), 'users')) active @endif">👤 User Management</a>

        <div class="menu-section">Store Management</div>
        <a href="{{ route('admin.customers.index') }}" class="@if(str_contains(Route::currentRouteName(), 'customers')) active @endif">👥 Customers</a>
        <a href="{{ route('admin.bills.index') }}" class="@if(str_contains(Route::currentRouteName(), 'bills')) active @endif">📄 Bills</a>
        <a href="{{ route('admin.reports.index') }}" class="@if(str_contains(Route::currentRouteName(), 'reports')) active @endif">📈 Reports</a>

        <div class="menu-section">Inventory</div>
        <a href="{{ route('admin.inventory.index') }}" class="@if(str_contains(Route::currentRouteName(), 'inventory') && !str_contains(Route::currentRouteName(), 'stock') && !str_contains(Route::currentRouteName(), 'categories') && !str_contains(Route::currentRouteName(), 'products') && !str_contains(Route::currentRouteName(), 'purchases') && !str_contains(Route::currentRouteName(), 'suppliers')) active @endif">📦 Stock Overview</a>
        <a href="{{ route('admin.inventory.categories.index') }}" class="@if(str_contains(Route::currentRouteName(), 'categories')) active @endif">🏷️ Categories</a>
        <a href="{{ route('admin.inventory.products.index') }}" class="@if(str_contains(Route::currentRouteName(), 'products')) active @endif">📋 Products</a>
        <a href="{{ route('admin.inventory.suppliers.index') }}" class="@if(str_contains(Route::currentRouteName(), 'suppliers')) active @endif">🏢 Suppliers</a>
        <a href="{{ route('admin.inventory.purchases.index') }}" class="@if(str_contains(Route::currentRouteName(), 'purchases')) active @endif">📥 Purchases</a>
        <a href="{{ route('admin.purchase-reports.index') }}" class="@if(str_contains(Route::currentRouteName(), 'purchase-reports')) active @endif">📊 Purchase Reports</a>
    </div>

    <div class="main-content">
        <div class="container">
            @yield('content')
        </div>
    </div>

    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.querySelector('.sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        menuToggle.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            sidebarOverlay.classList.toggle('active');
        });

        // Close sidebar when overlay is clicked
        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('active');
            sidebarOverlay.classList.remove('active');
        });

        // Close sidebar when a link is clicked
        const sidebarLinks = document.querySelectorAll('.sidebar a');
        sidebarLinks.forEach(link => {
            link.addEventListener('click', () => {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            });
        });

        // Close sidebar on window resize if mobile view is exited
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('active');
                sidebarOverlay.classList.remove('active');
            }
        });
    </script>
</body>
</html>
