@extends('admin.layout')
@section('title', 'Monthly Bills Report')

@section('content')
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <div class="header" style="margin-bottom: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2 style="font-size: 28px; color: #333; margin: 0;">Monthly Bills Report</h2>
                <a href="{{ route('admin.reports.index') }}" class="back-link" style="color: #667eea; text-decoration: none;">← Back to Reports</a>
            </div>
        </div>

        <div class="filter-box" style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #e0e0e0;">
            <form action="{{ route('admin.reports.monthly-sales') }}" method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; align-items: flex-end;">
                <div>
                    <label for="year" style="font-weight: 500; color: #333; display: block; margin-bottom: 6px;">Year:</label>
                    <select name="year" id="year" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
                        @for ($y = date('Y'); $y >= 2020; $y--)
                            <option value="{{ $y }}" {{ $year == $y ? 'selected' : '' }}>{{ $y }}</option>
                        @endfor
                    </select>
                </div>
                <div>
                    <label for="month" style="font-weight: 500; color: #333; display: block; margin-bottom: 6px;">Month:</label>
                    <select name="month" id="month" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
                        <option value="1" {{ $month == '1' ? 'selected' : '' }}>January</option>
                        <option value="2" {{ $month == '2' ? 'selected' : '' }}>February</option>
                        <option value="3" {{ $month == '3' ? 'selected' : '' }}>March</option>
                        <option value="4" {{ $month == '4' ? 'selected' : '' }}>April</option>
                        <option value="5" {{ $month == '5' ? 'selected' : '' }}>May</option>
                        <option value="6" {{ $month == '6' ? 'selected' : '' }}>June</option>
                        <option value="7" {{ $month == '7' ? 'selected' : '' }}>July</option>
                        <option value="8" {{ $month == '8' ? 'selected' : '' }}>August</option>
                        <option value="9" {{ $month == '9' ? 'selected' : '' }}>September</option>
                        <option value="10" {{ $month == '10' ? 'selected' : '' }}>October</option>
                        <option value="11" {{ $month == '11' ? 'selected' : '' }}>November</option>
                        <option value="12" {{ $month == '12' ? 'selected' : '' }}>December</option>
                    </select>
                </div>
                <button type="submit" style="padding: 8px 24px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 500;">View Report</button>
            </form>
        </div>

        @if ($monthlyBills->count() > 0)
            <div class="stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Total Revenue</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹{{ number_format($totalRevenue, 2) }}</div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #28a745; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Earned Amount</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹{{ number_format($totalEarned, 2) }}</div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Debt / Bakaya</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹{{ number_format($totalDebt, 2) }}</div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #17a2b8; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Bills</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">{{ $totalBills }}</div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Average Bill</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹{{ number_format($averageBill, 2) }}</div>
                </div>
            </div>

            <h3 style="font-size: 20px; color: #333; margin-bottom: 20px; margin-top: 30px;">Daily Bills Breakdown</h3>
            <div class="table-container" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f8f9fa; border-bottom: 2px solid #e0e0e0;">
                            <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Date</th>
                            <th style="padding: 16px; text-align: center; font-weight: 600; color: #333; font-size: 14px;">Bills</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Total Amount</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Earned Amount</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Debt / Bakaya</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Average Bill</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($billsByDay as $date => $data)
                            <tr style="border-bottom: 1px solid #e0e0e0;">
                                <td style="padding: 14px 16px; font-weight: 500; color: #333;">{{ date('l, M d, Y', strtotime($date)) }}</td>
                                <td style="padding: 14px 16px; text-align: center;">{{ $data['count'] }}</td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹{{ number_format($data['amount'], 2) }}</td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #28a745;">₹{{ number_format($data['earned'], 2) }}</td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #ffc107;">₹{{ number_format($data['debt'], 2) }}</td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹{{ number_format($data['average'], 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            @if ($topCustomers->count() > 0)
                <h3 style="font-size: 20px; color: #333; margin-bottom: 20px; margin-top: 30px;">Top 10 Customers This Month</h3>
                <div class="table-container" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8f9fa; border-bottom: 2px solid #e0e0e0;">
                                <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Customer Name</th>
                                <th style="padding: 16px; text-align: center; font-weight: 600; color: #333; font-size: 14px;">Bills</th>
                                <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Total Amount</th>
                                <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Earned Amount</th>
                                <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Debt / Bakaya</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($topCustomers as $item)
                                <tr style="border-bottom: 1px solid #e0e0e0;">
                                    <td style="padding: 14px 16px; font-weight: 500; color: #333;">
                                        <a href="{{ route('admin.customers.show', $item['customer']) }}" style="color: #667eea; text-decoration: none; font-weight: 600;">
                                            {{ $item['customer']->name }}
                                        </a>
                                    </td>
                                    <td style="padding: 14px 16px; text-align: center;">{{ $item['count'] }}</td>
                                    <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹{{ number_format($item['amount'], 2) }}</td>
                                    <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #28a745;">₹{{ number_format($item['earned'], 2) }}</td>
                                    <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #ffc107;">₹{{ number_format($item['debt'], 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        @else
            <div style="background: white; border-radius: 8px; padding: 60px 20px; text-align: center;">
                <h3 style="color: #999; margin-bottom: 10px;">No bills for this month</h3>
                <p style="color: #999;"><a href="{{ route('admin.bills.create') }}" style="color: #667eea; text-decoration: none;">Create a new bill</a></p>
            </div>
        @endif
    </div>
@endsection

