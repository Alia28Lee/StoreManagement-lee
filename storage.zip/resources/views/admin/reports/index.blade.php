@extends('admin.layout')
@section('title', 'Bill Reports')

@section('content')
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <a href="{{ route('admin.bills.index') }}" class="back-link" style="color: #667eea; text-decoration: none; margin-bottom: 20px; display: inline-block;">← Back to Bills</a>

        <div class="header" style="margin-bottom: 40px;">
            <h2 style="font-size: 32px; color: #333; margin: 0 0 10px 0;">Bill Reports</h2>
            <p style="color: #666; font-size: 16px; margin: 0;">Analyze your bills data across different time periods and customer segments</p>
        </div>

        <div class="reports-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
            <!-- Daily Bill Report -->
            <a href="{{ route('admin.reports.daily-sales') }}" class="report-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onmouseover="this.style.boxShadow='0 8px 16px rgba(0,0,0,0.1)'; this.style.borderColor='#667eea';" onmouseout="this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)'; this.style.borderColor='#e0e0e0';">
                <div class="report-icon" style="font-size: 40px; margin-bottom: 16px;">📅</div>
                <div class="report-title" style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 8px;">Daily Bills Report</div>
                <div class="report-description" style="font-size: 14px; color: #666; margin-bottom: 12px; line-height: 1.5;">View today's bills summary, payment methods breakdown, and transaction details.</div>
                <div class="report-arrow" style="color: #667eea; font-weight: 500;">View Report →</div>
            </a>

            <!-- Customer Wise Bill Report -->
            <a href="{{ route('admin.reports.customer-sales') }}" class="report-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onmouseover="this.style.boxShadow='0 8px 16px rgba(0,0,0,0.1)'; this.style.borderColor='#667eea';" onmouseout="this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)'; this.style.borderColor='#e0e0e0';">
                <div class="report-icon" style="font-size: 40px; margin-bottom: 16px;">👥</div>
                <div class="report-title" style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 8px;">Customer-Wise Bills Report</div>
                <div class="report-description" style="font-size: 14px; color: #666; margin-bottom: 12px; line-height: 1.5;">Analyze bills by customer, identify top customers, and track walk-in transactions.</div>
                <div class="report-arrow" style="color: #667eea; font-weight: 500;">View Report →</div>
            </a>

            <!-- Weekly Bill Report -->
            <a href="{{ route('admin.reports.weekly-sales') }}" class="report-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onmouseover="this.style.boxShadow='0 8px 16px rgba(0,0,0,0.1)'; this.style.borderColor='#667eea';" onmouseout="this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)'; this.style.borderColor='#e0e0e0';">
                <div class="report-icon" style="font-size: 40px; margin-bottom: 16px;">📊</div>
                <div class="report-title" style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 8px;">Weekly Bills Report</div>
                <div class="report-description" style="font-size: 14px; color: #666; margin-bottom: 12px; line-height: 1.5;">Get a comprehensive view of bills trends throughout the current week.</div>
                <div class="report-arrow" style="color: #667eea; font-weight: 500;">View Report →</div>
            </a>

            <!-- Monthly Bill Report -->
            <a href="{{ route('admin.reports.monthly-sales') }}" class="report-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onmouseover="this.style.boxShadow='0 8px 16px rgba(0,0,0,0.1)'; this.style.borderColor='#667eea';" onmouseout="this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)'; this.style.borderColor='#e0e0e0';">
                <div class="report-icon" style="font-size: 40px; margin-bottom: 16px;">📈</div>
                <div class="report-title" style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 8px;">Monthly Bills Report</div>
                <div class="report-description" style="font-size: 14px; color: #666; margin-bottom: 12px; line-height: 1.5;">Detailed monthly analysis with daily breakdown, top customers, and key metrics.</div>
                <div class="report-arrow" style="color: #667eea; font-weight: 500;">View Report →</div>
            </a>

            <!-- Yearly Bill Report -->
            <a href="{{ route('admin.reports.yearly-sales') }}" class="report-card" style="background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 24px; text-decoration: none; transition: all 0.3s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.05);" onmouseover="this.style.boxShadow='0 8px 16px rgba(0,0,0,0.1)'; this.style.borderColor='#667eea';" onmouseout="this.style.boxShadow='0 2px 4px rgba(0,0,0,0.05)'; this.style.borderColor='#e0e0e0';">
                <div class="report-icon" style="font-size: 40px; margin-bottom: 16px;">📉</div>
                <div class="report-title" style="font-size: 18px; font-weight: 600; color: #333; margin-bottom: 8px;">Yearly Bills Report</div>
                <div class="report-description" style="font-size: 14px; color: #666; margin-bottom: 12px; line-height: 1.5;">Annual overview with month-by-month comparison and performance insights.</div>
                <div class="report-arrow" style="color: #667eea; font-weight: 500;">View Report →</div>
            </a>
        </div>
    </div>
@endsection
