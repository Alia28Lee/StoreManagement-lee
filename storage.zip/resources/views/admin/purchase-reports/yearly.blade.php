@extends('admin.layout')

@section('title', 'Yearly Purchase Report')

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>Yearly Purchase Report</h1>
            <p>Year {{ $year }}</p>
        </div>
        <a href="{{ route('admin.purchase-reports.index') }}" class="btn btn-secondary">Back to Reports</a>
    </div>

    <form method="GET" action="{{ route('admin.purchase-reports.yearly') }}" style="margin-bottom: 20px;">
        <div style="display: flex; gap: 10px;">
            <input type="number" name="year" min="2000" max="2099" value="{{ $year }}" class="form-control" style="flex: 1; max-width: 200px;">
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </form>

    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Purchases</h4>
                <p style="font-size: 24px; margin: 10px 0;">{{ $totals['purchases_count'] }}</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Quantity</h4>
                <p style="font-size: 24px; margin: 10px 0;">{{ number_format($totals['total_quantity'], 2) }}</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Amount</h4>
                <p style="font-size: 24px; margin: 10px 0;">₹{{ number_format($totals['total_amount'], 2) }}</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Debt</h4>
                <p style="font-size: 24px; margin: 10px 0; color: red;">₹{{ number_format($totals['total_debt'], 2) }}</p>
            </div>
        </div>
    </div>

    @if(count($reportData) > 0)
        @foreach($reportData as $category => $products)
            <div class="card" style="margin-bottom: 20px;">
                <div class="card-header">
                    <h3>{{ $category }}</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Unit</th>
                                    <th>Quantity Purchased</th>
                                    <th>Items Count</th>
                                    <th>Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($products as $productName => $data)
                                    <tr>
                                        <td><strong>{{ $productName }}</strong></td>
                                        <td>{{ $data['unit'] }}</td>
                                        <td>{{ number_format($data['quantity'], 2) }}</td>
                                        <td>{{ $data['items_count'] }}</td>
                                        <td>₹{{ number_format($data['total_amount'], 2) }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        @endforeach
    @else
        <div class="alert alert-info">
            No purchases recorded for this year.
        </div>
    @endif

    <a href="{{ route('admin.purchase-reports.index') }}" class="btn btn-secondary">Back to Reports</a>
</div>

<style>
.card { border: 1px solid #ddd; border-radius: 4px; }
.card-header { background: #f5f5f5; padding: 15px; border-bottom: 1px solid #ddd; }
.card-header h3 { margin: 0; }
.card-body { padding: 15px; }
.table { width: 100%; border-collapse: collapse; }
.table th { background: #f9f9f9; padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
.table td { padding: 10px; border-bottom: 1px solid #eee; }
.btn-secondary { padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; }
.btn-secondary:hover { background: #5a6268; }
</style>
@endsection
