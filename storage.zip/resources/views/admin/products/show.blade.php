@extends('admin.layout')

@section('title', $product->name)

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>{{ $product->name }}</h1>
            <p>{{ $product->category?->name ?? 'Uncategorized' }}</p>
        </div>
        <div>
            <a href="{{ route('admin.inventory.products.edit', $product) }}" class="btn btn-secondary">Edit</a>
            <form method="POST" action="{{ route('admin.inventory.products.destroy', $product) }}" style="display:inline;">
                @csrf @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this product?')">Delete</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Product Details</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Name:</span>
                <span class="value">{{ $product->name }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Category:</span>
                <span class="value">{{ $product->category?->name ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">SKU:</span>
                <span class="value">{{ $product->sku ?? '-' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Unit:</span>
                <span class="value">{{ $product->unit }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Current Stock:</span>
                <span class="value">
                    {{ number_format($product->current_stock, 2) }} {{ $product->unit }}
                    @if($product->current_stock <= $product->reorder_level)
                        <span class="badge badge-danger">Low Stock</span>
                    @endif
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Reorder Level:</span>
                <span class="value">{{ number_format($product->reorder_level, 2) }} {{ $product->unit }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Description:</span>
                <span class="value">{{ $product->description ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Created:</span>
                <span class="value">{{ $product->created_at->format('d M Y H:i') }}</span>
            </div>
        </div>
    </div>

    <a href="{{ route('admin.inventory.products.index') }}" class="btn btn-secondary" style="margin-top: 20px;">Back to Products</a>
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-left: 10px; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
@endsection
