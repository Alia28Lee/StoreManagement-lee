@extends('admin.layout')

@section('title', 'Products')

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>Products</h1>
            <p>Manage grocery items and inventory</p>
        </div>
        <a href="{{ route('admin.inventory.products.create') }}" class="btn btn-primary">
            + Add Product
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <!-- Filter Form -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
            <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
        </div>
        <div class="card-body" style="padding: 15px;">
            <form method="GET" action="{{ route('admin.inventory.products.index') }}" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: end;">
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Product Name</label>
                    <input type="text" name="search" placeholder="Search products..." value="{{ request('search') }}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Category</label>
                    <select name="category_id" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- All Categories --</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}" {{ request('category_id') == $category->id ? 'selected' : '' }}>{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Stock Status</label>
                    <select name="status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- All Status --</option>
                        <option value="in_stock" {{ request('status') === 'in_stock' ? 'selected' : '' }}>In Stock</option>
                        <option value="low" {{ request('status') === 'low' ? 'selected' : '' }}>Low Stock</option>
                    </select>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                    <a href="{{ route('admin.inventory.products.index') }}" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
                </div>
            </form>
        </div>
    </div>

    @if($products->count() > 0)
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Category</th>
                        <th>Unit</th>
                        <th>Current Stock</th>
                        <th>Reorder Level</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $product)
                        <tr>
                            <td><strong>{{ $product->name }}</strong></td>
                            <td>{{ $product->category?->name ?? '-' }}</td>
                            <td>{{ $product->unit }}</td>
                            <td>{{ number_format($product->current_stock, 2) }}</td>
                            <td>{{ number_format($product->reorder_level, 2) }}</td>
                            <td>
                                @if($product->current_stock <= $product->reorder_level)
                                    <span class="badge badge-danger">Low Stock</span>
                                @else
                                    <span class="badge badge-success">In Stock</span>
                                @endif
                            </td>
                            <td class="action-links">
                                <a href="{{ route('admin.inventory.products.show', $product) }}" title="View">👁</a>
                                <a href="{{ route('admin.inventory.products.edit', $product) }}" title="Edit">✎</a>
                                <form method="POST" action="{{ route('admin.inventory.products.destroy', $product) }}" style="display:inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" title="Delete" onclick="return confirm('Delete this product?')">🗑</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="pagination">
            {{ $products->links() }}
        </div>
    @else
        <div class="empty-state">
            <p>No products found. <a href="{{ route('admin.inventory.products.create') }}">Create one now</a></p>
        </div>
    @endif
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
@endsection
