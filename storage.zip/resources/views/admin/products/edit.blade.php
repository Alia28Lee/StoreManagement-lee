@extends('admin.layout')

@section('title', 'Edit Product')

@section('content')
<div class="container">
    <h1>Edit Product</h1>
    
    @if($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('admin.inventory.products.update', $product) }}" class="form">
        @csrf @method('PUT')

        <div class="form-group">
            <label for="category_id">Category *</label>
            <select id="category_id" name="category_id" class="form-control @error('category_id') is-invalid @enderror" required>
                <option value="">-- Select Category --</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
            @error('category_id') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="name">Product Name *</label>
            <input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror" 
                   value="{{ old('name', $product->name) }}" required>
            @error('name') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="sku">SKU (Optional)</label>
            <input type="text" id="sku" name="sku" class="form-control @error('sku') is-invalid @enderror" 
                   value="{{ old('sku', $product->sku) }}">
            @error('sku') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-group">
            <label for="unit">Unit *</label>
            <select id="unit" name="unit" class="form-control @error('unit') is-invalid @enderror" required>
                <option value="">-- Select Unit --</option>
                <option value="kg" {{ old('unit', $product->unit) == 'kg' ? 'selected' : '' }}>Kilogram (kg)</option>
                <option value="g" {{ old('unit', $product->unit) == 'g' ? 'selected' : '' }}>Gram (g)</option>
                <option value="ltr" {{ old('unit', $product->unit) == 'ltr' ? 'selected' : '' }}>Liter (ltr)</option>
                <option value="ml" {{ old('unit', $product->unit) == 'ml' ? 'selected' : '' }}>Milliliter (ml)</option>
                <option value="box" {{ old('unit', $product->unit) == 'box' ? 'selected' : '' }}>Box</option>
                <option value="piece" {{ old('unit', $product->unit) == 'piece' ? 'selected' : '' }}>Piece</option>
                <option value="dozen" {{ old('unit', $product->unit) == 'dozen' ? 'selected' : '' }}>Dozen</option>
                <option value="bundle" {{ old('unit', $product->unit) == 'bundle' ? 'selected' : '' }}>Bundle</option>
            </select>
            @error('unit') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="cost_price">Cost Price *</label>
                <input type="number" id="cost_price" name="cost_price" class="form-control @error('cost_price') is-invalid @enderror" 
                       value="{{ old('cost_price', $product->cost_price) }}" step="0.01" min="0" required>
                @error('cost_price') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="selling_price">Planned Selling Price *</label>
                <input type="number" id="selling_price" name="selling_price" class="form-control @error('selling_price') is-invalid @enderror" 
                       value="{{ old('selling_price', $product->selling_price) }}" step="0.01" min="0" required>
                @error('selling_price') <span class="error">{{ $message }}</span> @enderror
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="current_stock">Current Stock *</label>
                <input type="number" id="current_stock" name="current_stock" class="form-control @error('current_stock') is-invalid @enderror" 
                       value="{{ old('current_stock', $product->current_stock) }}" step="0.01" required>
                @error('current_stock') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="reorder_level">Reorder Level *</label>
                <input type="number" id="reorder_level" name="reorder_level" class="form-control @error('reorder_level') is-invalid @enderror" 
                       value="{{ old('reorder_level', $product->reorder_level) }}" step="0.01" required>
                @error('reorder_level') <span class="error">{{ $message }}</span> @enderror
            </div>
        </div>

        <div class="form-group">
            <label for="description">Description</label>
            <textarea id="description" name="description" class="form-control" rows="4">{{ old('description', $product->description) }}</textarea>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Update Product</button>
            <a href="{{ route('admin.inventory.products.show', $product) }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<style>
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
</style>
@endsection
