@extends('admin.layout')

@section('title', $purchase->reference_number)

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>{{ $purchase->reference_number }}</h1>
            <p>{{ $purchase->supplier->name ?? 'Anonymous' }} • {{ $purchase->purchase_date->format('d M Y') }}</p>
        </div>
        <div>
            <a href="{{ route('admin.inventory.purchases.edit', $purchase) }}" class="btn btn-secondary">Edit</a>
            <form method="POST" action="{{ route('admin.inventory.purchases.destroy', $purchase) }}" style="display:inline;">
                @csrf @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this purchase?')">Delete</button>
            </form>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div class="card">
            <div class="card-header">
                <h3>Purchase Details</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Reference:</span>
                    <span class="value">{{ $purchase->reference_number }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Supplier:</span>
                    <span class="value">
                        @if($purchase->supplier)
                            <a href="{{ route('admin.inventory.suppliers.show', $purchase->supplier) }}">{{ $purchase->supplier->name }}</a>
                        @else
                            Anonymous
                        @endif
                    </span>
                </div>
                <div class="detail-row">
                    <span class="label">Date:</span>
                    <span class="value">{{ $purchase->purchase_date->format('d M Y') }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Last Updated:</span>
                    <span class="value">{{ $purchase->updated_at->format('d M Y, h:i A') }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Payment Method:</span>
                    <span class="value">{{ $purchase->payment_method ?? 'N/A' }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Notes:</span>
                    <span class="value">{{ $purchase->notes ?? 'N/A' }}</span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Payment Summary</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Total Amount:</span>
                    <span class="value" style="font-weight: bold;">₹{{ number_format($purchase->total_amount, 2) }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Amount Paid:</span>
                    <span class="value" style="color: green;">₹{{ number_format($purchase->paid_amount, 2) }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Outstanding Debt:</span>
                    <span class="value" style="color: red; font-weight: bold;">₹{{ number_format($purchase->debt_amount, 2) }}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Status:</span>
                    <span class="value">
                        @if($purchase->payment_status === 'paid')
                            <span class="badge badge-success">Paid</span>
                        @elseif($purchase->payment_status === 'partial')
                            <span class="badge badge-warning">Partial Payment</span>
                        @else
                            <span class="badge badge-danger">Pending</span>
                        @endif
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <div class="card-header">
            <h3>Items Purchased</h3>
        </div>
        <div class="card-body">
            @if($purchase->purchaseItems->count() > 0)
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($purchase->purchaseItems as $item)
                                <tr>
                                    <td><a href="{{ route('admin.inventory.products.show', $item->product) }}">{{ $item->product->name }}</a></td>
                                    <td>{{ $item->product->category?->name ?? '-' }}</td>
                                    <td>{{ number_format($item->quantity, 2) }} {{ $item->product->unit }}</td>
                                    <td>₹{{ number_format($item->unit_price, 2) }}</td>
                                    <td>₹{{ number_format($item->total_price, 2) }}</td>
                                </tr>
                            @endforeach
                            <tr style="background: #f5f5f5; font-weight: bold;">
                                <td colspan="4" style="text-align: right;">Total:</td>
                                <td>₹{{ number_format($purchase->purchaseItems->sum('total_price'), 2) }}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            @else
                <p>No items in this purchase.</p>
            @endif
        </div>
    </div>

    <a href="{{ route('admin.inventory.purchases.index') }}" class="btn btn-secondary" style="margin-top: 20px;">Back to Purchases</a>
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
@endsection
