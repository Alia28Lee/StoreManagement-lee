@extends('admin.layout')

@section('title', 'Edit Purchase')

@section('content')
<div class="container">
    <h1>Edit Purchase Payment Details</h1>
    
    @if($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('admin.inventory.purchases.update', $purchase) }}" class="form">
        @csrf @method('PUT')

        <fieldset>
            <legend>Purchase Header</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="reference_number">Reference Number (Read-only)</label>
                    <input type="text" id="reference_number" name="reference_number" class="form-control" 
                           value="{{ $purchase->reference_number }}" readonly>
                </div>
                <div class="form-group">
                    <label for="purchase_date">Purchase Date *</label>
                    <input type="date" id="purchase_date" name="purchase_date" class="form-control @error('purchase_date') is-invalid @enderror" 
                           value="{{ old('purchase_date', $purchase->purchase_date->format('Y-m-d')) }}" required>
                    @error('purchase_date') <span class="error">{{ $message }}</span> @enderror
                </div>
                <div class="form-group">
                    <label for="updated_at">Last Updated (Read-only)</label>
                    <input type="text" id="updated_at" class="form-control" 
                           value="{{ $purchase->updated_at->format('d M Y, h:i A') }}" readonly style="background: #f5f5f5;">
                </div>
            </div>

            <div class="form-group">
                <label for="supplier_id">Supplier</label>
                <select id="supplier_id" name="supplier_id" class="form-control @error('supplier_id') is-invalid @enderror">
                    <option value="">-- Select Supplier --</option>
                    @foreach($suppliers as $supplier)
                        <option value="{{ $supplier->id }}" @selected(old('supplier_id', $purchase->supplier_id) == $supplier->id)>
                            {{ $supplier->name ?? 'Anonymous' }} @if($supplier->phone)({{ $supplier->phone }})@endif
                        </option>
                    @endforeach
                </select>
                <small class="form-text text-muted">Leave empty for anonymous supplier</small>
                @error('supplier_id') <span class="error">{{ $message }}</span> @enderror
            </div>

            <div class="form-group">
                <label for="notes">Notes</label>
                <textarea id="notes" name="notes" class="form-control" rows="3">{{ old('notes', $purchase->notes) }}</textarea>
            </div>
        </fieldset>

        <fieldset>
            <legend>Items Purchased</legend>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($purchase->purchaseItems as $item)
                            <tr>
                                <td>{{ $item->product->name }}</td>
                                <td>{{ number_format($item->quantity, 2) }} {{ $item->product->unit }}</td>
                                <td>₹{{ number_format($item->unit_price, 2) }}</td>
                                <td>₹{{ number_format($item->total_price, 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <p class="info-text">Note: Items cannot be changed after purchase is recorded. Delete and recreate if needed.</p>
        </fieldset>

        <fieldset>
            <legend>Payment Details</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="total_amount">Total Amount *</label>
                    <input type="number" id="total_amount" name="total_amount" class="form-control @error('total_amount') is-invalid @enderror" 
                           value="{{ old('total_amount', $purchase->total_amount) }}" step="0.01" required readonly style="background: #f5f5f5;">
                    @error('total_amount') <span class="error">{{ $message }}</span> @enderror
                </div>
                <div class="form-group">
                    <label for="paid_amount">Amount Paid *</label>
                    <input type="number" id="paid_amount" name="paid_amount" class="form-control @error('paid_amount') is-invalid @enderror" 
                           value="{{ old('paid_amount', $purchase->paid_amount) }}" step="0.01" required onchange="calculateDebt()">
                    @error('paid_amount') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="payment_status">Payment Status *</label>
                    <select id="payment_status" name="payment_status" class="form-control @error('payment_status') is-invalid @enderror" required onchange="toggleDebtSection()">
                        <option value="">-- Select Status --</option>
                        <option value="paid" {{ old('payment_status', $purchase->payment_status) == 'paid' ? 'selected' : '' }}>Paid</option>
                        <option value="partial" {{ old('payment_status', $purchase->payment_status) == 'partial' ? 'selected' : '' }}>Partial Payment</option>
                        <option value="pending" {{ old('payment_status', $purchase->payment_status) == 'pending' ? 'selected' : '' }}>Pending</option>
                    </select>
                    @error('payment_status') <span class="error">{{ $message }}</span> @enderror
                </div>
                <div class="form-group">
                    <label for="payment_method">Payment Method</label>
                    <input type="text" id="payment_method" name="payment_method" class="form-control" 
                           value="{{ old('payment_method', $purchase->payment_method) }}" placeholder="Cash, Check, Bank Transfer, etc.">
                </div>
            </div>

            <div id="debt-section" class="form-row" @if($purchase->payment_status !== 'partial' && $purchase->payment_status !== 'pending') style="display: none;" @endif>
                <div class="form-group">
                    <label for="debt_amount">Outstanding Debt *</label>
                    <input type="number" id="debt_amount" name="debt_amount" class="form-control @error('debt_amount') is-invalid @enderror" 
                           value="{{ old('debt_amount', $purchase->debt_amount) }}" step="0.01" readonly style="background: #f5f5f5;">
                    <small style="color: #666;">Auto-calculated: Total Amount - Amount Paid</small>
                    @error('debt_amount') <span class="error">{{ $message }}</span> @enderror
                </div>
            </div>
        </fieldset>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Update Purchase</button>
            <a href="{{ route('admin.inventory.purchases.show', $purchase) }}" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
.info-text { color: #666; font-size: 13px; margin-top: 10px; }
</style>

<script>
function calculateDebt() {
    const total = parseFloat(document.getElementById('total_amount').value) || 0;
    const paid = parseFloat(document.getElementById('paid_amount').value) || 0;
    const debt = total - paid;
    document.getElementById('debt_amount').value = debt.toFixed(2);
}

function toggleDebtSection() {
    const status = document.getElementById('payment_status').value;
    const debtSection = document.getElementById('debt-section');
    
    if (status === 'partial' || status === 'pending') {
        debtSection.style.display = 'grid';
        calculateDebt();
    } else {
        debtSection.style.display = 'none';
        document.getElementById('debt_amount').value = '0';
    }
}

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    const paidAmount = parseFloat(document.getElementById('paid_amount').value);
    const totalAmount = parseFloat(document.getElementById('total_amount').value);
    
    if (status === 'paid' && paidAmount < totalAmount) {
        alert('For "Paid" status, Amount Paid must equal Total Amount');
        e.preventDefault();
    }
});
</script>
@endsection
