@extends('admin.layout')

@section('title', $category->name)

@section('content')
<div class="container">
    <div class="page-header">
        <div>
            <h1>{{ $category->name }}</h1>
            <p>Category Details</p>
        </div>
        <div>
            <a href="{{ route('admin.inventory.categories.edit', $category) }}" class="btn btn-secondary">Edit</a>
            <form method="POST" action="{{ route('admin.inventory.categories.destroy', $category) }}" style="display:inline;">
                @csrf @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this category?')">Delete</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Details</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Name:</span>
                <span class="value">{{ $category->name }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Description:</span>
                <span class="value">{{ $category->description ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Products:</span>
                <span class="value">{{ $category->products->count() }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Created:</span>
                <span class="value">{{ $category->created_at->format('d M Y H:i') }}</span>
            </div>
        </div>
    </div>

    @if($category->products->count() > 0)
        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3>Products in this Category</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>SKU</th>
                                <th>Unit</th>
                                <th>Current Stock</th>
                                <th>Reorder Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($category->products as $product)
                                <tr>
                                    <td><a href="{{ route('admin.inventory.products.show', $product) }}">{{ $product->name }}</a></td>
                                    <td>{{ $product->sku ?? '-' }}</td>
                                    <td>{{ $product->unit }}</td>
                                    <td>{{ number_format($product->current_stock, 2) }}</td>
                                    <td>{{ number_format($product->reorder_level, 2) }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    @endif

    <a href="{{ route('admin.inventory.categories.index') }}" class="btn btn-secondary" style="margin-top: 20px;">Back to Categories</a>
</div>
@endsection
