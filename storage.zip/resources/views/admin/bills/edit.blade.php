@extends('admin.layout')

@section('title', 'Edit Bill')

@section('content')
<div class="page-header">
    <h1>Edit Bill - {{ $bill->invoice_number }}</h1>
</div>

@if($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form method="POST" action="{{ route('admin.bills.update', $bill) }}" class="form">
    @csrf @method('PUT')

    <fieldset>
        <legend>Bill Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="invoice_number">Invoice Number (Read-only)</label>
                <input type="text" id="invoice_number" name="invoice_number" class="form-control" 
                       value="{{ $bill->invoice_number }}" readonly>
            </div>
            <div class="form-group">
                <label for="bill_date">Bill Date *</label>
                <input type="date" id="bill_date" name="bill_date" class="form-control @error('bill_date') is-invalid @enderror" 
                       value="{{ old('bill_date', $bill->bill_date->format('Y-m-d')) }}" required>
                @error('bill_date') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="updated_at">Last Updated (Read-only)</label>
                <input type="text" id="updated_at" class="form-control" 
                       value="{{ $bill->updated_at->format('d M Y, h:i A') }}" readonly style="background: #f5f5f5;">
            </div>
        </div>

        <div class="form-group">
            <label for="customer_id">Customer</label>
            <select id="customer_id" name="customer_id" class="form-control">
                <option value="">-- Walk-in Customer --</option>
                @foreach($customers as $customer)
                    <option value="{{ $customer->id }}" {{ old('customer_id', $bill->customer_id) == $customer->id ? 'selected' : '' }}>
                        {{ $customer->name }}
                    </option>
                @endforeach
            </select>
        </div>
    </fieldset>

    <fieldset>
        <legend>Items Purchased (Read-only)</legend>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Item Total</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($bill->billItems as $item)
                        <tr>
                            <td>{{ $item->product->name }}</td>
                            <td>{{ number_format($item->quantity, 2) }} {{ $item->product->unit }}</td>
                            <td>₹{{ number_format($item->unit_price, 2) }}</td>
                            <td>₹{{ number_format($item->item_total, 2) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <p style="color: #999; font-size: 13px; margin-top: 10px;">Note: Items cannot be changed. Delete and recreate the bill if you need to modify items.</p>
    </fieldset>

    <fieldset>
        <legend>Bill Summary</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="subtotal_label">Sub Total</label>
                <input type="text" id="subtotal_label" class="form-control" value="₹{{ number_format($bill->total_amount, 2) }}" readonly style="background: #f5f5f5;">
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Payment Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="discount_amount">Discount Amount</label>
                <input type="number" id="discount_amount" name="discount_amount" class="form-control @error('discount_amount') is-invalid @enderror" 
                       value="{{ old('discount_amount', $bill->discount_amount) }}" step="0.01">
                @error('discount_amount') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="payment_status">Payment Status *</label>
                <select id="payment_status" name="payment_status" class="form-control @error('payment_status') is-invalid @enderror" required onchange="toggleAmountPaidField()">
                    <option value="">-- Select Status --</option>
                    <option value="paid" {{ old('payment_status', $bill->payment_status) == 'paid' ? 'selected' : '' }}>Paid</option>
                    <option value="partial" {{ old('payment_status', $bill->payment_status) == 'partial' ? 'selected' : '' }}>Partial Payment</option>
                    <option value="pending" {{ old('payment_status', $bill->payment_status) == 'pending' ? 'selected' : '' }}>Pending</option>
                </select>
                @error('payment_status') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="payment_method">Payment Method</label>
                <input type="text" id="payment_method" name="payment_method" class="form-control" 
                       value="{{ old('payment_method', $bill->payment_method) }}" placeholder="Cash, Card, etc.">
            </div>
        </div>

        <div id="amount-paid-section" class="form-row" @if($bill->payment_status !== 'partial' && $bill->payment_status !== 'pending' && $bill->payment_status !== 'paid') style="display: none;" @endif>
            <div class="form-group">
                <label for="amount_paid">Amount Paid / <span class="devanagari">दी गई रकम</span></label>
                <input type="number" id="amount_paid" name="amount_paid" class="form-control @error('amount_paid') is-invalid @enderror" 
                       value="{{ old('amount_paid', $bill->amount_paid) }}" step="0.01" onchange="calculateDebt()" oninput="calculateDebt()">
                <small style="color: #666;">Actual amount paid by customer</small>
                @error('amount_paid') <span class="error">{{ $message }}</span> @enderror
            </div>
            <div class="form-group">
                <label for="debt_label">Debt Amount / <span class="devanagari">बकाया रकम</span></label>
                <input type="text" id="debt_label" class="form-control" value="₹{{ number_format($bill->debt_amount ?? 0, 2) }}" readonly style="background: #f5f5f5;">
            </div>
        </div>

        <div class="form-group">
            <label for="notes">Notes</label>
            <textarea id="notes" name="notes" class="form-control" rows="3">{{ old('notes', $bill->notes) }}</textarea>
        </div>
    </fieldset>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Update Bill</button>
        <a href="{{ route('admin.bills.show', $bill) }}" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
</style>

<script>
const subtotal = {{ $bill->total_amount }};

function calculateDebt() {
    const netAmount = subtotal - (parseFloat(document.getElementById('discount_amount').value) || 0);
    const amountPaid = parseFloat(document.getElementById('amount_paid').value) || 0;
    
    // Debt = Net Amount - Amount Paid
    const debtAmount = Math.max(0, netAmount - amountPaid);
    document.getElementById('debt_label').value = '₹' + debtAmount.toFixed(2);
}

function toggleAmountPaidField() {
    const status = document.getElementById('payment_status').value;
    const amountPaidSection = document.getElementById('amount-paid-section');
    
    if (status === 'partial' || status === 'pending' || status === 'paid') {
        amountPaidSection.style.display = 'grid';
        
        if (status === 'paid') {
            const netAmount = subtotal - (parseFloat(document.getElementById('discount_amount').value) || 0);
            document.getElementById('amount_paid').value = netAmount.toFixed(2);
        }
    } else {
        amountPaidSection.style.display = 'none';
        document.getElementById('amount_paid').value = '0';
    }
    
    calculateDebt();
}

document.getElementById('payment_status').addEventListener('change', toggleAmountPaidField);
document.getElementById('discount_amount').addEventListener('change', calculateDebt);
document.getElementById('discount_amount').addEventListener('input', calculateDebt);

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    
    if (!status) {
        e.preventDefault();
        alert('Please select a payment status');
        return false;
    }
});

// Initialize
toggleAmountPaidField();
calculateDebt();
</script>
@endsection
