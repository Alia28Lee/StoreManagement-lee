@extends('admin.layout')

@section('title', $bill->invoice_number)

@section('content')
<div class="page-header">
    <div>
        <h1>{{ $bill->invoice_number }}</h1>
        <p>{{ $bill->bill_date->format('d F Y') }}</p>
    </div>
    <div>
        <a href="{{ route('admin.bills.invoice', $bill) }}" class="btn btn-secondary">📄 Generate Invoice</a>
        <a href="{{ route('admin.bills.edit', $bill) }}" class="btn btn-secondary">Edit</a>
        <form method="POST" action="{{ route('admin.bills.destroy', $bill) }}" style="display:inline;">
            @csrf @method('DELETE')
            <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this bill?')">Delete</button>
        </form>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3>Bill Information</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Invoice Number:</span>
                <span class="value">{{ $bill->invoice_number }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Bill Date:</span>
                <span class="value">{{ $bill->bill_date->format('d M Y') }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Last Updated:</span>
                <span class="value">{{ $bill->updated_at->format('d M Y, h:i A') }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Customer:</span>
                <span class="value">{{ $bill->customer?->name ?? 'Walk-in Customer' }}</span>
            </div>
            @if($bill->customer)
                <div class="detail-row">
                    <span class="label">Phone:</span>
                    <span class="value">{{ $bill->customer->phone ?? 'N/A' }}</span>
                </div>
            @endif
            <div class="detail-row">
                <span class="label">Payment Method:</span>
                <span class="value">{{ $bill->payment_method ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Notes:</span>
                <span class="value">{{ $bill->notes ?? 'N/A' }}</span>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Bill Summary</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Items Count:</span>
                <span class="value">{{ $bill->billItems->count() }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Sub Total:</span>
                <span class="value" style="font-weight: bold;">₹{{ number_format($bill->total_amount, 2) }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Discount:</span>
                <span class="value">- ₹{{ number_format($bill->discount_amount, 2) }}</span>
            </div>
            <div class="detail-row" style="background: #f5f5f5; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Net Amount:</span>
                <span class="value" style="font-weight: bold;">₹{{ number_format($bill->net_amount, 2) }}</span>
            </div>
            <div class="detail-row" style="background: #e8f5e9; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Amount Paid / दी गई रकम:</span>
                <span class="value" style="font-weight: bold; color: #2e7d32;">₹{{ number_format($bill->amount_paid ?? 0, 2) }}</span>
            </div>
            <div class="detail-row" style="background: #fff3cd; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Debt Amount / बकाया रकम:</span>
                <span class="value" style="font-weight: bold; color: #856404;">₹{{ number_format($bill->debt_amount ?? 0, 2) }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Payment Status:</span>
                <span class="value">
                    @if($bill->payment_status === 'paid')
                        <span class="badge badge-success">Paid</span>
                    @elseif($bill->payment_status === 'partial')
                        <span class="badge badge-warning">Partial Payment</span>
                    @else
                        <span class="badge badge-danger">Pending (Udhaar)</span>
                    @endif
                </span>
            </div>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 20px;">
    <div class="card-header">
        <h3>Items Sold</h3>
    </div>
    <div class="card-body">
        @if($bill->billItems->count() > 0)
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Item Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($bill->billItems as $item)
                            <tr>
                                <td><strong>{{ $item->product->name }}</strong></td>
                                <td>{{ number_format($item->quantity, 2) }} {{ $item->product->unit }}</td>
                                <td>₹{{ number_format($item->unit_price, 2) }}</td>
                                <td>₹{{ number_format($item->item_total, 2) }}</td>
                            </tr>
                        @endforeach
                        <tr style="background: #f5f5f5; font-weight: bold;">
                            <td colspan="3" style="text-align: right;">Subtotal:</td>
                            <td>₹{{ number_format($bill->billItems->sum('item_total'), 2) }}</td>
                        </tr>
                        @if($bill->discount_amount > 0)
                            <tr style="background: #f5f5f5;">
                                <td colspan="3" style="text-align: right;">Discount:</td>
                                <td>- ₹{{ number_format($bill->discount_amount, 2) }}</td>
                            </tr>
                        @endif
                        <tr style="background: #e8f5e9;">
                            <td colspan="3" style="text-align: right; font-weight: bold;">Total:</td>
                            <td style="font-weight: bold;">₹{{ number_format($bill->net_amount, 2) }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        @else
            <p>No items in this bill.</p>
        @endif
    </div>
</div>

<a href="{{ route('admin.bills.index') }}" class="btn btn-secondary" style="margin-top: 20px;">Back to Bills</a>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
@endsection
