<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - {{ $bill->invoice_number }}</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Courier New', monospace;
            background: white;
            color: #333;
        }

        .invoice-container {
            max-width: 900px;
            margin: 20px auto;
            padding: 40px;
            border: 2px solid #333;
            background: white;
        }

        .invoice-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }

        .invoice-header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }

        .invoice-header p {
            font-size: 14px;
            color: #666;
        }

        .invoice-meta {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }

        .meta-section h3 {
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 10px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
        }

        .meta-section p {
            font-size: 14px;
            line-height: 1.8;
        }

        .meta-section .label {
            font-weight: bold;
        }

        table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }

        table thead {
            background: #f5f5f5;
            border-top: 2px solid #333;
            border-bottom: 2px solid #333;
        }

        table th {
            padding: 12px 10px;
            text-align: left;
            font-size: 13px;
            font-weight: bold;
        }

        table td {
            padding: 12px 10px;
            font-size: 14px;
            border-bottom: 1px solid #eee;
        }

        table tr:last-child td {
            border-bottom: none;
        }

        .amount-right {
            text-align: right;
        }

        .summary-section {
            margin-top: 30px;
            text-align: right;
            width: 50%;
            margin-left: auto;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .summary-row.total {
            border-top: 2px solid #333;
            border-bottom: 2px solid #333;
            padding: 10px 0;
            font-weight: bold;
            font-size: 16px;
        }

        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 12px;
            color: #666;
        }

        .payment-status {
            margin: 20px 0;
            padding: 10px;
            text-align: center;
            border: 2px solid #333;
            font-weight: bold;
        }

        .print-button {
            text-align: center;
            margin: 20px 0;
        }

        .print-button button {
            padding: 10px 30px;
            font-size: 14px;
            cursor: pointer;
            background: #333;
            color: white;
            border: none;
            border-radius: 4px;
        }

        @media print {
            .print-button {
                display: none;
            }

            body {
                margin: 0;
                padding: 0;
            }

            .invoice-container {
                margin: 0;
                padding: 20px;
                border: none;
                page-break-after: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="print-button">
        <button onclick="window.print()">🖨️ Print Invoice</button>
    </div>

    <div class="invoice-container">
        <div class="invoice-header">
            <h1>INVOICE</h1>
            <p>{{ config('app.name') }} - Store Sales System</p>
        </div>

        <div class="invoice-meta">
            <div class="meta-section">
                <h3>Bill Information</h3>
                <p>
                    <span class="label">Invoice #:</span> {{ $bill->invoice_number }}<br>
                    <span class="label">Date:</span> {{ $bill->bill_date->format('d M Y') }}<br>
                    <span class="label">Time:</span> {{ $bill->created_at->format('H:i A') }}
                </p>
            </div>
            <div class="meta-section">
                <h3>Customer Details</h3>
                <p>
                    @if($bill->customer)
                        <span class="label">Name:</span> {{ $bill->customer->name }}<br>
                        <span class="label">Phone:</span> {{ $bill->customer->phone ?? 'N/A' }}<br>
                        <span class="label">Address:</span> {{ $bill->customer->address ?? 'N/A' }}<br>
                        <span class="label">City:</span> {{ $bill->customer->city ?? 'N/A' }}
                    @else
                        <span class="label">Walk-in Customer</span>
                    @endif
                </p>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th class="amount-right">Qty</th>
                    <th class="amount-right">Unit Price</th>
                    <th class="amount-right">Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach($bill->billItems as $item)
                    <tr>
                        <td>{{ $item->product->name }}</td>
                        <td class="amount-right">{{ number_format($item->quantity, 2) }}</td>
                        <td class="amount-right">₹{{ number_format($item->unit_price, 2) }}</td>
                        <td class="amount-right">₹{{ number_format($item->item_total, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="summary-section">
            <div class="summary-row">
                <span>Subtotal:</span>
                <span>₹{{ number_format($bill->total_amount, 2) }}</span>
            </div>
            @if($bill->discount_amount > 0)
                <div class="summary-row">
                    <span>Discount:</span>
                    <span>-₹{{ number_format($bill->discount_amount, 2) }}</span>
                </div>
            @endif
            <div class="summary-row total">
                <span>Total Amount:</span>
                <span>₹{{ number_format($bill->net_amount, 2) }}</span>
            </div>
            <div class="summary-row" style="color: #2e7d32; font-weight: bold; border-top: 1px solid #ddd; padding-top: 8px; margin-top: 8px;">
                <span>Amount Paid / दी गई रकम:</span>
                <span>₹{{ number_format($bill->amount_paid ?? 0, 2) }}</span>
            </div>
            <div class="summary-row" style="color: #856404; font-weight: bold; border-bottom: 2px solid #333; padding-bottom: 8px;">
                <span>Debt Amount / बकाया रकम:</span>
                <span>₹{{ number_format($bill->debt_amount ?? 0, 2) }}</span>
            </div>
        </div>

        <div class="payment-status">
            Payment Status: 
            @if($bill->payment_status === 'paid')
                PAID
            @elseif($bill->payment_status === 'partial')
                PARTIAL PAYMENT
            @else
                PENDING
            @endif
        </div>

        @if($bill->payment_method)
            <p style="text-align: center; margin: 10px 0; font-size: 14px;">
                <span style="font-weight: bold;">Payment Method:</span> {{ $bill->payment_method }}
            </p>
        @endif

        @if($bill->notes)
            <p style="text-align: center; margin: 10px 0; font-size: 13px;">
                <span style="font-weight: bold;">Notes:</span> {{ $bill->notes }}
            </p>
        @endif

        <div class="footer">
            <p>Thank you for your business!</p>
            <p>Generated on {{ now()->format('d M Y H:i A') }}</p>
            <p>Invoice #: {{ $bill->invoice_number }}</p>
        </div>
    </div>
</body>
</html>
