@extends('admin.layout')
@section('title', 'Customer Details')

@section('content')
    <style>
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #667eea;
        }

        .header h2 {
            margin: 0;
            font-size: 32px;
            color: #333;
        }

        .header-actions {
            display: flex;
            gap: 10px;
        }

        .btn-sm {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
        }

        .btn-warning {
            background: #ffc107;
            color: #333;
        }

        .btn-warning:hover {
            background: #e0a800;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .info-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            overflow: hidden;
        }

        .info-section {
            padding: 25px;
            border-bottom: 1px solid #e0e0e0;
        }

        .info-section:last-child {
            border-bottom: none;
        }

        .info-section h3 {
            margin: 0 0 20px 0;
            font-size: 18px;
            font-weight: 600;
            color: #333;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
            padding: 12px 0;
        }

        .info-row:last-child {
            margin-bottom: 0;
        }

        .info-label {
            font-weight: 600;
            color: #666;
            min-width: 180px;
            flex-shrink: 0;
        }

        .info-value {
            color: #333;
            flex-grow: 1;
            text-align: right;
            word-break: break-word;
        }

        .info-row:has(.info-value:only-child) {
            display: block;
        }

        .info-row:has(.info-value:only-child) .info-value {
            text-align: left;
            margin-top: 8px;
            padding: 12px;
            background: #f9f9f9;
            border-radius: 4px;
            border-left: 3px solid #667eea;
        }
    </style>

    <div class="container">
        <a href="{{ route('admin.customers.index') }}" class="back-link">← Back to Customers</a>

        <div class="header">
            <h2>{{ $customer->name }}</h2>
            <div class="header-actions">
                <a href="{{ route('admin.customers.edit', $customer) }}" class="btn-sm btn-warning">✏️ Edit</a>
                <form action="{{ route('admin.customers.destroy', $customer) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this customer?');">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn-sm btn-danger">🗑️ Delete</button>
                </form>
            </div>
        </div>

        <div class="info-card">
            <div class="info-section">
                <h3>📧 Contact Information</h3>
                <div class="info-row">
                    <span class="info-label">Email</span>
                    <span class="info-value">{{ $customer->email ?? 'Not provided' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Phone</span>
                    <span class="info-value">{{ $customer->phone ?? 'Not provided' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>🏠 Address</h3>
                <div class="info-row">
                    <span class="info-label">Street</span>
                    <span class="info-value">{{ $customer->address ?? 'Not provided' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">City</span>
                    <span class="info-value">{{ $customer->city ?? 'Not provided' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">State</span>
                    <span class="info-value">{{ $customer->state ?? 'Not provided' }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Postal Code</span>
                    <span class="info-value">{{ $customer->postal_code ?? 'Not provided' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>💳 Credit/Debit Balance (Udhaar)</h3>
                <div class="info-row">
                    <span class="info-label">Outstanding Balance</span>
                    <span class="info-value" style="font-size: 20px; font-weight: bold; color: @if(($customer->debit_balance ?? 0) > 0) #dc3545 @else #28a745 @endif;">
                        ₹{{ number_format($customer->debit_balance ?? 0, 2) }}
                    </span>
                </div>
            </div>

            <div class="info-section">
                <h3>📝 Additional Notes</h3>
                <div class="info-row">
                    <span class="info-value">{{ $customer->notes ?? 'No notes added' }}</span>
                </div>
            </div>

            <div class="info-section">
                <h3>ℹ️ System Information</h3>
                <div class="info-row">
                    <span class="info-label">Created</span>
                    <span class="info-value">{{ $customer->created_at->format('M d, Y \a\t h:i A') }}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Updated</span>
                    <span class="info-value">{{ $customer->updated_at->format('M d, Y \a\t h:i A') }}</span>
                </div>
            </div>
        </div>
    </div>
@endsection
