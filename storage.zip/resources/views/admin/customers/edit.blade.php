@extends('admin.layout')
@section('title', 'Edit Customer')

@section('content')
    <div class="container">
        <div class="form-card">
            <h2>Edit Customer</h2>

            <form action="{{ route('admin.customers.update', $customer) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="name">Full Name / <span class="devanagari">समीक्षा का नाम</span> *</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="{{ old('name', $customer->name) }}"
                        required
                        placeholder="Enter customer name"
                    >
                    @error('name')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="email">Email Address / <span class="devanagari">ईमेल पता</span></label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="{{ old('email', $customer->email) }}"
                        placeholder="customer@example.com"
                    >
                    <span class="text-muted">Optional - Used for communications</span>
                    @error('email')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number / <span class="devanagari">फोन नंबर</span></label>
                    <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value="{{ old('phone', $customer->phone) }}"
                        placeholder="+1 (555) 123-4567"
                    >
                    @error('phone')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="address">Street Address / <span class="devanagari">सड़क का पता</span></label>
                    <input
                        type="text"
                        id="address"
                        name="address"
                        value="{{ old('address', $customer->address) }}"
                        placeholder="123 Main Street"
                    >
                    @error('address')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="city">City / <span class="devanagari">शहर</span></label>
                        <input
                            type="text"
                            id="city"
                            name="city"
                            value="{{ old('city', $customer->city) }}"
                            placeholder="New York"
                        >
                        @error('city')
                            <span class="error">{{ $message }}</span>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="state">State/Province / <span class="devanagari">राज्य</span></label>
                        <input
                            type="text"
                            id="state"
                            name="state"
                            value="{{ old('state', $customer->state) }}"
                            placeholder="NY"
                        >
                        @error('state')
                            <span class="error">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label for="postal_code">Postal Code / <span class="devanagari">पिन कोड</span></label>
                    <input
                        type="text"
                        id="postal_code"
                        name="postal_code"
                        value="{{ old('postal_code', $customer->postal_code) }}"
                        placeholder="10001"
                    >
                    @error('postal_code')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="notes">Notes / <span class="devanagari">सूसपाठें</span></label>
                    <textarea
                        id="notes"
                        name="notes"
                        placeholder="Any additional notes about this customer..."
                    >{{ old('notes', $customer->notes) }}</textarea>
                    @error('notes')
                        <span class="error">{{ $message }}</span>
                    @enderror
                </div>

                <div class="form-actions">
                    <a href="{{ route('admin.customers.index') }}" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Customer</button>
                </div>
            </form>
        </div>
    </div>
@endsection
