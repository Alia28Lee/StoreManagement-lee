@extends('admin.layout')

@section('title', 'User Profile')

@section('content')
<div class="page-header">
    <div>
        <h1>{{ $user->profile?->full_name ?? $user->name }}</h1>
        <p>{{ $user->email }}</p>
    </div>
    <div>
        <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-secondary">Edit Profile</a>
        <a href="{{ route('admin.users.change-password-form', $user) }}" class="btn btn-secondary">🔐 Change Password</a>
        <form method="POST" action="{{ route('admin.users.destroy', $user) }}" style="display:inline;">
            @csrf @method('DELETE')
            <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this user?')">Delete</button>
        </form>
    </div>
</div>

@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3>Account Information</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Email:</span>
                <span class="value">{{ $user->email }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Role:</span>
                <span class="value">
                    @php
                        $role = $user->profile?->role ?? 'user';
                        $roleColors = [
                            'superadmin' => ['bg' => '#ff6b6b', 'text' => 'white', 'icon' => '🔐'],
                            'admin' => ['bg' => '#4c6ef5', 'text' => 'white', 'icon' => '👤'],
                            'user' => ['bg' => '#e3f2fd', 'text' => '#1976d2', 'icon' => '👥'],
                        ];
                        $colors = $roleColors[$role] ?? $roleColors['user'];
                    @endphp
                    <span class="badge" style="background: {{ $colors['bg'] }}; color: {{ $colors['text'] }}; padding: 4px 8px; border-radius: 3px;">
                        {{ $colors['icon'] }} {{ ucfirst($role) }}
                    </span>
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value">
                    @if($user->profile?->is_active)
                        <span class="badge" style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 3px;">Active</span>
                    @else
                        <span class="badge" style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 3px;">Inactive</span>
                    @endif
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Created:</span>
                <span class="value">{{ $user->created_at->format('d M Y, h:i A') }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Last Updated:</span>
                <span class="value">{{ $user->updated_at->format('d M Y, h:i A') }}</span>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Shop & Profile Details</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Shop Name:</span>
                <span class="value">{{ $user->profile?->shop_name ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Full Name:</span>
                <span class="value">{{ $user->profile?->full_name ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Phone:</span>
                <span class="value">{{ $user->profile?->phone ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">City:</span>
                <span class="value">{{ $user->profile?->city ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">State:</span>
                <span class="value">{{ $user->profile?->state ?? 'N/A' }}</span>
            </div>
            <div class="detail-row">
                <span class="label">Address:</span>
                <span class="value">{{ $user->profile?->address ?? 'N/A' }}</span>
            </div>
        </div>
    </div>
</div>

<a href="{{ route('admin.users.index') }}" class="btn btn-secondary" style="margin-top: 20px;">Back to Users</a>
@endsection
