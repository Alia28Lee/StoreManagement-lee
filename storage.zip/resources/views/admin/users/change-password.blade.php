@extends('admin.layout')

@section('title', 'Change User Password')

@section('content')
<div class="page-header">
    <h1>Change Password - {{ $user->email }}</h1>
    <p>Update password for {{ $user->profile?->full_name ?? $user->name }}</p>
</div>

@if($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<div class="card" style="max-width: 500px;">
    <div class="card-body" style="padding: 30px;">
        <form method="POST" action="{{ route('admin.users.update-password', $user) }}">
            @csrf @method('PUT')

            <div class="form-group" style="margin-bottom: 25px;">
                <label for="password">New Password *</label>
                <input type="password" id="password" name="password" class="form-control @error('password') is-invalid @enderror" 
                       placeholder="Enter new password" required>
                <small style="color: #666; display: block; margin-top: 5px;">Minimum 6 characters</small>
                @error('password') <span class="error">{{ $message }}</span> @enderror
            </div>

            <div class="form-group" style="margin-bottom: 25px;">
                <label for="password_confirmation">Confirm Password *</label>
                <input type="password" id="password_confirmation" name="password_confirmation" class="form-control" 
                       placeholder="Confirm new password" required>
                @error('password_confirmation') <span class="error">{{ $message }}</span> @enderror
            </div>

            <div style="background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; padding: 12px; margin-bottom: 20px;">
                <p style="margin: 0; font-size: 14px; color: #856404;">
                    <strong>⚠️ Warning:</strong> Make sure you remember the new password. The user will need it to log in.
                </p>
            </div>

            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Change Password</button>
                <a href="{{ route('admin.users.show', $user) }}" class="btn btn-secondary" style="flex: 1; text-align: center;">Cancel</a>
            </div>
        </form>
    </div>
</div>
@endsection
