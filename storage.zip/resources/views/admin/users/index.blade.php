@extends('admin.layout')

@section('title', 'User Management')

@section('content')
<div class="page-header">
    <div>
        <h1>User Management</h1>
        <p>Manage system users and their profiles</p>
    </div>
    <a href="{{ route('admin.users.create') }}" class="btn btn-primary">+ Add New User</a>
</div>

@if (session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
@endif

<!-- Filter Form -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
        <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
    </div>
    <div class="card-body" style="padding: 15px;">
        <form method="GET" action="{{ route('admin.users.index') }}" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: end;">
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Search (Email, Shop Name, Full Name)</label>
                <input type="text" name="search" placeholder="Search users..." value="{{ request('search') }}" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Status</label>
                <select name="status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- All Status --</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Active</option>
                    <option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Inactive</option>
                </select>
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                <a href="{{ route('admin.users.index') }}" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
            </div>
        </form>
    </div>
</div>

@if ($users->count() > 0)
    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Shop Name</th>
                        <th>Full Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        <tr>
                            <td><strong>{{ $user->email }}</strong></td>
                            <td>{{ $user->profile?->shop_name ?? 'N/A' }}</td>
                            <td>{{ $user->profile?->full_name ?? $user->name }}</td>
                            <td>
                                @php
                                    $role = $user->profile?->role ?? 'user';
                                    $roleColors = [
                                        'superadmin' => ['bg' => '#ff6b6b', 'text' => 'white', 'icon' => '🔐'],
                                        'admin' => ['bg' => '#4c6ef5', 'text' => 'white', 'icon' => '👤'],
                                        'user' => ['bg' => '#e3f2fd', 'text' => '#1976d2', 'icon' => '👥'],
                                    ];
                                    $colors = $roleColors[$role] ?? $roleColors['user'];
                                @endphp
                                <span class="badge" style="background: {{ $colors['bg'] }}; color: {{ $colors['text'] }}; padding: 4px 8px; border-radius: 3px; font-size: 12px;">
                                    {{ $colors['icon'] }} {{ ucfirst($role) }}
                                </span>
                            </td>
                            <td>
                                @if($user->profile?->is_active)
                                    <span class="badge" style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 3px; font-size: 12px;">Active</span>
                                @else
                                    <span class="badge" style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 3px; font-size: 12px;">Inactive</span>
                                @endif
                            </td>
                            <td>{{ $user->created_at->format('d M Y') }}</td>
                            <td class="action-links">
                                <a href="{{ route('admin.users.show', $user) }}" class="btn-sm btn-info">View</a>
                                <a href="{{ route('admin.users.edit', $user) }}" class="btn-sm btn-warning">Edit</a>
                                <a href="{{ route('admin.users.change-password-form', $user) }}" class="btn-sm btn-secondary" title="Change Password">🔐</a>
                                <form action="{{ route('admin.users.destroy', $user) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div style="text-align: center; padding: 20px;">
            {{ $users->links() }}
        </div>
    </div>
@else
    <div class="empty-state">
        <h3>No users found</h3>
        <p>Get started by <a href="{{ route('admin.users.create') }}">adding a new user</a></p>
    </div>
@endif
@endsection
