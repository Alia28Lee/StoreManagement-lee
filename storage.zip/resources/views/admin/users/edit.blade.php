@extends('admin.layout')

@section('title', 'Edit User Profile')

@section('content')
<div class="page-header">
    <h1>Edit User Profile</h1>
    <p>Update {{ $user->email }}'s account and profile information</p>
</div>

@if($errors->any())
    <div class="alert alert-danger" style="margin-bottom: 20px;">
        <p style="margin: 0 0 10px 0; font-weight: 600;">Please fix the following errors:</p>
        <ul style="margin: 0; padding-left: 20px;">
            @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div style="max-width: 900px;">
    <form method="POST" action="{{ route('admin.users.update', $user) }}" class="form">
        @csrf @method('PUT')

        <fieldset>
            <legend>Account Credentials</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="email">Email Address <span style="color: #dc3545;">*</span></label>
                    <input type="email" id="email" name="email" class="form-control @error('email') is-invalid @enderror" 
                           value="{{ old('email', $user->email) }}" placeholder="user@example.com" required>
                    @error('email') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                    <small style="color: #666; display: block; margin-top: 5px;">Used for login</small>
                </div>
                <div class="form-group">
                    <label for="role">Role <span style="color: #dc3545;">*</span></label>
                    <select id="role" name="role" class="form-control @error('role') is-invalid @enderror" required>
                        <option value="">-- Select a Role --</option>
                        <option value="superadmin" {{ old('role', $user->profile?->role) === 'superadmin' ? 'selected' : '' }}>🔑 Super Admin (Full System Access)</option>
                        <option value="admin" {{ old('role', $user->profile?->role) === 'admin' ? 'selected' : '' }}>👑 Admin (Full Access)</option>
                        <option value="user" {{ old('role', $user->profile?->role) === 'user' ? 'selected' : '' }}>👤 User (Limited Access)</option>
                    </select>
                    @error('role') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                    <small style="color: #666; display: block; margin-top: 5px;">Super Admin can manage all users and system settings</small>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 8px;">
                        <input type="checkbox" id="is_active" name="is_active" value="1" 
                               {{ old('is_active', $user->profile?->is_active) ? 'checked' : '' }}
                               style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="cursor: pointer; font-weight: 500;">✅ User is Active (Can Login)</span>
                    </label>
                </div>
            </div>
        </fieldset>

        <fieldset style="margin-top: 30px;">
            <legend>Shop Information</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="shop_name">Shop Name <span style="color: #dc3545;">*</span></label>
                    <input type="text" id="shop_name" name="shop_name" class="form-control @error('shop_name') is-invalid @enderror" 
                           value="{{ old('shop_name', $user->profile?->shop_name) }}" placeholder="e.g., ABC Grocery Store" required>
                    @error('shop_name') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="full_name">Owner's Full Name <span style="color: #dc3545;">*</span></label>
                    <input type="text" id="full_name" name="full_name" class="form-control @error('full_name') is-invalid @enderror" 
                           value="{{ old('full_name', $user->profile?->full_name) }}" placeholder="e.g., John Doe" required>
                    @error('full_name') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                </div>
            </div>
        </fieldset>

        <fieldset style="margin-top: 30px;">
            <legend>Contact Details</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="text" id="phone" name="phone" class="form-control @error('phone') is-invalid @enderror" 
                           value="{{ old('phone', $user->profile?->phone) }}" placeholder="+91 9876543210">
                    @error('phone') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="city">City</label>
                    <input type="text" id="city" name="city" class="form-control @error('city') is-invalid @enderror" 
                           value="{{ old('city', $user->profile?->city) }}" placeholder="e.g., Mumbai">
                    @error('city') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="state">State</label>
                    <input type="text" id="state" name="state" class="form-control @error('state') is-invalid @enderror" 
                           value="{{ old('state', $user->profile?->state) }}" placeholder="e.g., Maharashtra">
                    @error('state') 
                        <small class="error" style="display: block; margin-top: 5px;">
                            ❌ {{ $message }}
                        </small>
                    @enderror
                </div>
            </div>

            <div class="form-group">
                <label for="address">Street Address</label>
                <textarea id="address" name="address" class="form-control @error('address') is-invalid @enderror" 
                          rows="2" placeholder="Enter complete address">{{ old('address', $user->profile?->address) }}</textarea>
                @error('address') 
                    <small class="error" style="display: block; margin-top: 5px;">
                        ❌ {{ $message }}
                    </small>
                @enderror
            </div>
        </fieldset>

        <div style="display: flex; gap: 10px; margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
            <button type="submit" class="btn btn-primary" style="flex: 0 0 auto; padding: 10px 30px;">
                ✅ Update Profile
            </button>
            <a href="{{ route('admin.users.show', $user) }}" class="btn btn-secondary" style="flex: 0 0 auto; padding: 10px 30px;">
                ❌ Cancel
            </a>
        </div>
    </form>
</div>

<style>
    .form-row {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }

    fieldset {
        border: 1px solid #ddd;
        border-radius: 6px;
        padding: 20px;
        background: #fafafa;
    }

    legend {
        color: #333;
        font-size: 16px;
        font-weight: 600;
        padding: 0 10px;
        margin-left: -10px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
    }

    .form-group label {
        font-weight: 500;
        color: #333;
        margin-bottom: 8px;
        font-size: 14px;
    }

    .form-control {
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
        transition: all 0.3s;
    }

    .form-control:focus {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }

    .form-control.is-invalid {
        border-color: #dc3545;
        background-color: #fff5f5;
    }

    .form-control.is-invalid:focus {
        box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1);
    }

    .error {
        color: #dc3545;
        font-size: 13px;
        font-weight: 500;
    }

    @media (max-width: 600px) {
        .form-row {
            grid-template-columns: 1fr;
        }

        div[style*="flex"] {
            flex-direction: column !important;
        }
    }
</style>
@endsection
