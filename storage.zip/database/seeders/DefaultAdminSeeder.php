<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\UserProfile;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DefaultAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create default admin user if not exists
        $user = User::firstOrCreate(
            ['email' => 'admin@storeadmin.com'],
            [
                'name' => 'System Administrator',
                'password' => Hash::make('admin@123'),
            ]
        );

        // Create or update user profile
        UserProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'shop_name' => 'Main Store',
                'full_name' => 'System Administrator',
                'phone' => '9876543210',
                'city' => 'Delhi',
                'state' => 'Delhi',
                'address' => 'Admin Office',
                'role' => 'superadmin',
                'is_active' => true,
            ]
        );

        $this->command->info('✅ Default admin user created successfully!');
        $this->command->info('📧 Email: admin@storeadmin.com');
        $this->command->info('🔐 Password: admin@123');
        $this->command->warn('⚠️  Please change the password after first login!');
    }
}
