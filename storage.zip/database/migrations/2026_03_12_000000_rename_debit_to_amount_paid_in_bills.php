<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bills', function (Blueprint $table) {
            // Rename debit_amount to amount_paid
            if (Schema::hasColumn('bills', 'debit_amount')) {
                $table->renameColumn('debit_amount', 'amount_paid');
            }
            
            // Add debt_amount column (calculates as net_amount - amount_paid)
            if (!Schema::hasColumn('bills', 'debt_amount')) {
                $table->decimal('debt_amount', 10, 2)->default(0)->after('amount_paid');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bills', function (Blueprint $table) {
            if (Schema::hasColumn('bills', 'amount_paid')) {
                $table->renameColumn('amount_paid', 'debit_amount');
            }
            
            if (Schema::hasColumn('bills', 'debt_amount')) {
                $table->dropColumn('debt_amount');
            }
        });
    }
};
