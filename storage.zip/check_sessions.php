<?php

$db = new PDO('sqlite:database/database.sqlite');

echo "=== SESSIONS TABLE STRUCTURE ===\n\n";

$columns = $db->query("PRAGMA table_info(sessions)")->fetchAll(PDO::FETCH_ASSOC);

foreach($columns as $col) {
    echo $col['name'] . " (" . $col['type'] . ")" . ($col['notnull'] ? " NOT NULL" : "") . "\n";
}

echo "\n=== SESSION DATA ===\n\n";

$sessions = $db->query("SELECT * FROM sessions")->fetchAll(PDO::FETCH_ASSOC);
echo "Total Sessions: " . count($sessions) . "\n\n";

foreach($sessions as $session) {
    echo "Session ID: " . substr($session['id'], 0, 20) . "...\n";
    echo "  User ID: " . $session['user_id'] . "\n";
    echo "  IP: " . $session['ip_address'] . "\n";
    echo "  User Agent: " . substr($session['user_agent'], 0, 40) . "...\n";
    echo "  Last Activity: " . $session['last_activity'] . "\n";
    echo "\n";
}
