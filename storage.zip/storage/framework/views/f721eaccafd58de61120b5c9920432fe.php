

<?php $__env->startSection('title', 'Record New Purchase'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Record New Purchase</h1>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.inventory.purchases.store')); ?>" class="form">
        <?php echo csrf_field(); ?>

        <fieldset>
            <legend>Purchase Details</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="reference_number">Reference Number / <span class="devanagari">संदर्भ संख्या</span> *</label>
                    <input type="text" id="reference_number" name="reference_number" class="form-control <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('reference_number', $referenceNumber)); ?>" required readonly>
                    <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="purchase_date">Purchase Date / <span class="devanagari">खरीद की तारीख</span> *</label>
                    <input type="date" id="purchase_date" name="purchase_date" class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('purchase_date', date('Y-m-d'))); ?>" required>
                    <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label for="supplier_id">Supplier / <span class="devanagari">संॆरतकताव</span></label>
                <select id="supplier_id" name="supplier_id" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">-- Select Supplier --</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplier_id') == $supplier->id): echo 'selected'; endif; ?>>
                            <?php echo e($supplier->name ?? 'Anonymous'); ?> <?php if($supplier->phone): ?>(<?php echo e($supplier->phone); ?>)<?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Leave empty for anonymous supplier</small>
                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="notes">Notes / <span class="devanagari">सूसपाठें</span></label>
                <textarea id="notes" name="notes" class="form-control" rows="3"><?php echo e(old('notes')); ?></textarea>
            </div>
        </fieldset>

        <fieldset>
            <legend>Purchase Items</legend>
            <div class="table-responsive">
                <table class="table" id="items-table">
                    <thead>
                        <tr>
                            <th>Product / <span class="devanagari">पण्य</span></th>
                            <th>Quantity / <span class="devanagari">मात्रा</span></th>
                            <th>Unit Price / <span class="devanagari">इकाई कीमत</span></th>
                            <th>Item Total / <span class="devanagari">कुल कीमत</span></th>
                            <th>Action / <span class="devanagari">कलीक</span></th>
                        </tr>
                    </thead>
                    <tbody id="items-container">
                        <tr class="item-row">
                            <td>
                                <select name="items[0][product_id]" class="form-control product-select" required>
                                    <option value="">-- Select Product --</option>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?> (<?php echo e($product->unit); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td>
                                <input type="number" name="items[0][quantity]" class="form-control qty-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
                            </td>
                            <td>
                                <input type="number" name="items[0][unit_price]" class="form-control price-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
                            </td>
                            <td>
                                <input type="number" name="items[0][total]" class="form-control total-input" step="0.01" readonly style="background: #f5f5f5;">
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(this)">Remove</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <button type="button" class="btn btn-secondary" onclick="addItem()">+ Add Item</button>
        </fieldset>

        <fieldset>
            <legend>Purchase Summary</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="total_amount">Total Amount / <span class="devanagari">कुल कीमत</span> *</label>
                    <input type="number" id="total_amount" name="total_amount" class="form-control <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('total_amount', 0)); ?>" step="0.01" required readonly style="background: #f5f5f5; font-weight: bold;">
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>Payment Details</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="paid_amount">Amount Paid / <span class="devanagari">अदा की थी रुख</span> *</label>
                    <input type="number" id="paid_amount" name="paid_amount" class="form-control <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('paid_amount', 0)); ?>" step="0.01" required onchange="calculateDebt()">
                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="payment_status">Payment Status / <span class="devanagari">अद़ॉ ल़ितम</span> *</label>
                    <select id="payment_status" name="payment_status" class="form-control <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="toggleDebtSection()">
                        <option value="">-- Select Status --</option>
                        <option value="paid" <?php echo e(old('payment_status') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                        <option value="partial" <?php echo e(old('payment_status') == 'partial' ? 'selected' : ''); ?>>Partial Payment</option>
                        <option value="pending" <?php echo e(old('payment_status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    </select>
                    <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="payment_method">Payment Method / <span class="devanagari">भुगतान विधि</span></label>
                    <input type="text" id="payment_method" name="payment_method" class="form-control" 
                           value="<?php echo e(old('payment_method')); ?>" placeholder="Cash, Check, Bank Transfer, etc.">
                </div>
            </div>

            <div id="debt-section" class="form-row" style="display: none;">
                <div class="form-group">
                    <label for="debt_amount">Outstanding Debt / <span class="devanagari">घद रथी कण</span> *</label>
                    <input type="number" id="debt_amount" name="debt_amount" class="form-control <?php $__errorArgs = ['debt_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('debt_amount', 0)); ?>" step="0.01" readonly style="background: #f5f5f5;">
                    <small style="color: #666;">Auto-calculated: Total Amount - Amount Paid</small>
                    <?php $__errorArgs = ['debt_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Record Purchase</button>
            <a href="<?php echo e(route('admin.inventory.purchases.index')); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.item-row td { padding: 12px; border-bottom: 1px solid #ddd; }
.item-row td input, .item-row td select { width: 100%; }
#items-table { width: 100%; border-collapse: collapse; }
#items-table thead { background: #f8f9fa; }
#items-table th { padding: 12px; text-align: left; border-bottom: 2px solid #ddd; }
</style>

<script>
let itemCount = 1;

function addItem() {
    const container = document.getElementById('items-container');
    const newRow = document.createElement('tr');
    newRow.className = 'item-row';
    newRow.innerHTML = `
        <td>
            <select name="items[${itemCount}][product_id]" class="form-control product-select" required>
                <option value="">-- Select Product --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?> (<?php echo e($product->unit); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </td>
        <td>
            <input type="number" name="items[${itemCount}][quantity]" class="form-control qty-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
        </td>
        <td>
            <input type="number" name="items[${itemCount}][unit_price]" class="form-control price-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
        </td>
        <td>
            <input type="number" name="items[${itemCount}][total]" class="form-control total-input" step="0.01" readonly style="background: #f5f5f5;">
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(this)">Remove</button>
        </td>
    `;
    container.appendChild(newRow);
    itemCount++;
}

function removeItem(btn) {
    btn.closest('.item-row').remove();
    updateTotalAmount();
}

function updateTotalAmount() {
    let total = 0;
    document.querySelectorAll('.total-input').forEach(input => {
        total += parseFloat(input.value) || 0;
    });
    document.getElementById('total_amount').value = total.toFixed(2);
}

function calculateTotal(input) {
    const row = input.closest('.item-row');
    const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
    const price = parseFloat(row.querySelector('.price-input').value) || 0;
    row.querySelector('.total-input').value = (qty * price).toFixed(2);
    updateTotalAmount();
    calculateDebt();
}

function calculateDebt() {
    const total = parseFloat(document.getElementById('total_amount').value) || 0;
    const paid = parseFloat(document.getElementById('paid_amount').value) || 0;
    const debt = total - paid;
    document.getElementById('debt_amount').value = debt.toFixed(2);
}

function toggleDebtSection() {
    const status = document.getElementById('payment_status').value;
    const debitSection = document.getElementById('debt-section');
    
    if (status === 'partial' || status === 'pending') {
        debitSection.style.display = 'grid';
        calculateDebt();
    } else {
        debitSection.style.display = 'none';
        document.getElementById('debt_amount').value = '0';
    }
}

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    const paidAmount = parseFloat(document.getElementById('paid_amount').value);
    const totalAmount = parseFloat(document.getElementById('total_amount').value);
    
    if (paidAmount > totalAmount) {
        alert('Amount Paid cannot exceed Total Amount');
        e.preventDefault();
        return false;
    }
    
    if (status === 'paid' && paidAmount < totalAmount) {
        alert('For "Paid" status, Amount Paid must equal Total Amount');
        e.preventDefault();
        return false;
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchases/create.blade.php ENDPATH**/ ?>