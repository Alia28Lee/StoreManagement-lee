
<?php $__env->startSection('title', 'Daily Bills Report'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <div class="header" style="margin-bottom: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2 style="font-size: 28px; color: #333; margin: 0;">Daily Bills Report</h2>
                <a href="<?php echo e(route('admin.reports.index')); ?>" class="back-link" style="color: #667eea; text-decoration: none;">← Back to Reports</a>
            </div>
        </div>

        <div class="filter-box" style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #e0e0e0;">
            <form action="<?php echo e(route('admin.reports.daily-sales')); ?>" method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                <label for="date" style="font-weight: 500; color: #333;">Select Date:</label>
                <input type="date" id="date" name="date" value="<?php echo e($date); ?>" required style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
                <button type="submit" style="padding: 8px 24px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 500;">View Report</button>
                <a href="<?php echo e(route('admin.reports.daily-sales.export', ['date' => $date])); ?>" style="padding: 8px 24px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 500; text-decoration: none; display: inline-block;">📊 Export to CSV</a>
            </form>
        </div>

        <?php if($bills->count() > 0): ?>
            <div class="stats" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Total Revenue</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($totalRevenue, 2)); ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #28a745; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Earned Amount</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($earnedAmount, 2)); ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Debt / Bakaya</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($debtAmount, 2)); ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #17a2b8; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Total Bills</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;"><?php echo e($totalBills); ?></div>
                </div>
                <div class="stat-card" style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h3 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Average Bill</h3>
                    <div class="value" style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($averageBill, 2)); ?></div>
                </div>
            </div>

            <div class="table-container" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f8f9fa; border-bottom: 2px solid #e0e0e0;">
                            <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Invoice #</th>
                            <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Customer</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Net Amount</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Amount Paid</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Debt / Bakaya</th>
                            <th style="padding: 16px; text-align: center; font-weight: 600; color: #333; font-size: 14px;">Payment Status</th>
                            <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-bottom: 1px solid #e0e0e0;">
                                <td style="padding: 14px 16px;"><strong style="color: #667eea;"><?php echo e($bill->invoice_number); ?></strong></td>
                                <td style="padding: 14px 16px;">
                                    <?php if($bill->customer): ?>
                                        <a href="<?php echo e(route('admin.customers.show', $bill->customer)); ?>" style="color: #667eea; text-decoration: none; font-weight: 500;"><?php echo e($bill->customer->name); ?></a>
                                    <?php else: ?>
                                        <span style="background: #f5f5f5; color: #999; padding: 4px 8px; border-radius: 4px; font-size: 12px;">Walk-in</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹<?php echo e(number_format($bill->net_amount, 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #28a745;">₹<?php echo e(number_format($bill->amount_paid ?? 0, 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #ffc107;">₹<?php echo e(number_format($bill->debt_amount ?? 0, 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: center;">
                                    <?php if($bill->payment_status === 'paid'): ?>
                                        <span style="background: #d4edda; color: #155724; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">Paid</span>
                                    <?php elseif($bill->payment_status === 'partial'): ?>
                                        <span style="background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">Partial</span>
                                    <?php else: ?>
                                        <span style="background: #f8d7da; color: #721c24; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500;">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 14px 16px; color: #666;"><?php echo e($bill->payment_method ?? 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($paymentBreakdown->count() > 0): ?>
                <div style="margin-top: 40px;">
                    <h3 style="color: #333; margin-bottom: 20px; font-size: 18px;">Payment Status Breakdown</h3>
                    <div class="payment-summary" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                        <?php $__currentLoopData = $paymentBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="payment-item" style="background: white; padding: 20px; border-radius: 8px; border: 1px solid #e0e0e0; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                                <h4 style="color: #333; margin: 0 0 16px 0; font-size: 16px; font-weight: 600; text-transform: capitalize;"><?php echo e($status); ?></h4>
                                <div style="margin-bottom: 8px;">
                                    <span style="color: #999; font-size: 12px;">Net:</span>
                                    <div style="font-size: 20px; font-weight: 700; color: #333;">₹<?php echo e(number_format($data['amount'], 2)); ?></div>
                                </div>
                                <div style="margin-bottom: 8px;">
                                    <span style="color: #999; font-size: 12px;">Earned:</span>
                                    <div style="font-size: 20px; font-weight: 700; color: #28a745;">₹<?php echo e(number_format($data['earned'], 2)); ?></div>
                                </div>
                                <div style="margin-bottom: 8px;">
                                    <span style="color: #999; font-size: 12px;">Debt:</span>
                                    <div style="font-size: 20px; font-weight: 700; color: #ffc107;">₹<?php echo e(number_format($data['debt'], 2)); ?></div>
                                </div>
                                <div style="color: #999; font-size: 12px; margin-top: 12px; padding-top: 12px; border-top: 1px solid #e0e0e0;"><?php echo e($data['count']); ?> bill(s)</div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div style="background: white; border-radius: 8px; padding: 60px 20px; text-align: center;">
                <h3 style="color: #999; margin-bottom: 10px;">No bills for <?php echo e(date('F d, Y', strtotime($date))); ?></h3>
                <p style="color: #999;">Try selecting a different date or <a href="<?php echo e(route('admin.bills.create')); ?>" style="color: #667eea; text-decoration: none;">create a new bill</a></p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/reports/daily-sales.blade.php ENDPATH**/ ?>