

<?php $__env->startSection('title', 'Suppliers'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Suppliers</h1>
        <p>Manage your suppliers and vendors</p>
    </div>
    <a href="<?php echo e(route('admin.inventory.suppliers.create')); ?>" class="btn btn-primary">+ Add New Supplier</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<!-- Filter Form -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
        <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
    </div>
    <div class="card-body" style="padding: 15px;">
        <form method="GET" action="<?php echo e(route('admin.inventory.suppliers.index')); ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: end;">
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Search (Name, Email, Phone)</label>
                <input type="text" name="search" placeholder="Search suppliers..." value="<?php echo e(request('search')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">City</label>
                <select name="city" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- All Cities --</option>
                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($city); ?>" <?php echo e(request('city') === $city ? 'selected' : ''); ?>><?php echo e($city); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                <a href="<?php echo e(route('admin.inventory.suppliers.index')); ?>" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
            </div>
        </form>
    </div>
</div>

<?php if($suppliers->count() > 0): ?>
    <div class="card">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($supplier->id); ?></td>
                            <td><?php echo e($supplier->name ?? 'Anonymous'); ?></td>
                            <td><?php echo e($supplier->email ?? 'N/A'); ?></td>
                            <td><?php echo e($supplier->phone ?? 'N/A'); ?></td>
                            <td><?php echo e($supplier->city ?? 'N/A'); ?></td>
                            <td class="action-links">
                                <a href="<?php echo e(route('admin.inventory.suppliers.show', $supplier)); ?>" class="btn-sm btn-info">View</a>
                                <a href="<?php echo e(route('admin.inventory.suppliers.edit', $supplier)); ?>" class="btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('admin.inventory.suppliers.destroy', $supplier)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this supplier?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn-sm btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center; padding: 20px;">
            <?php echo e($suppliers->links()); ?>

        </div>
    </div>
<?php else: ?>
    <div class="empty-state">
        <h3>No suppliers found</h3>
        <p>Get started by <a href="<?php echo e(route('admin.inventory.suppliers.create')); ?>">adding a new supplier</a></p>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/suppliers/index.blade.php ENDPATH**/ ?>