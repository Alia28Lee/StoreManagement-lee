

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Welcome, <?php echo e(Auth::guard('admin')->user()->name); ?>!</h1>
        <p>Your Store Management Dashboard</p>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">👥</div>
            <h3><?php echo e($totalCustomers ?? 0); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Total Customers</p>
            <a href="<?php echo e(route('admin.customers.index')); ?>" style="color: #667eea; text-decoration: none;">View Customers →</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">💰</div>
            <h3>₹ <?php echo e(number_format($totalRevenue ?? 0, 2)); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Total Revenue</p>
            <a href="<?php echo e(route('admin.bills.index')); ?>" style="color: #667eea; text-decoration: none;">View Bills →</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">📦</div>
            <h3><?php echo e($totalProducts ?? 0); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Products</p>
            <a href="<?php echo e(route('admin.inventory.products.index')); ?>" style="color: #667eea; text-decoration: none;">View Products →</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">📥</div>
            <h3><?php echo e($totalPurchases ?? 0); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Purchases</p>
            <a href="<?php echo e(route('admin.inventory.purchases.index')); ?>" style="color: #667eea; text-decoration: none;">View Purchases →</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">⚠️</div>
            <h3 style="color: #e74c3c;"><?php echo e($lowStockItems ?? 0); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Low Stock Items</p>
            <a href="<?php echo e(route('admin.inventory.index')); ?>" style="color: #667eea; text-decoration: none;">View Stock →</a>
        </div>
    </div>

    <div class="card">
        <div class="card-body" style="text-align: center;">
            <div style="font-size: 28px; margin-bottom: 10px;">💳</div>
            <h3 style="color: #e74c3c;">₹ <?php echo e(number_format($totalDebt ?? 0, 2)); ?></h3>
            <p style="color: #999; margin-bottom: 10px;">Outstanding Debt</p>
            <a href="<?php echo e(route('admin.inventory.purchases.index')); ?>" style="color: #667eea; text-decoration: none;">View Purchases →</a>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3>Quick Actions</h3>
        </div>
        <div class="card-body">
            <div style="display: grid; gap: 10px;">
                <a href="<?php echo e(route('admin.customers.create')); ?>" class="btn btn-primary" style="text-align: center;">+ Add New Customer</a>
                <a href="<?php echo e(route('admin.bills.create')); ?>" class="btn btn-primary" style="text-align: center;">+ Create Bill</a>
                <a href="<?php echo e(route('admin.inventory.purchases.create')); ?>" class="btn btn-primary" style="text-align: center;">+ Record Purchase</a>
                <a href="<?php echo e(route('admin.inventory.products.create')); ?>" class="btn btn-secondary" style="text-align: center;">+ Add Product</a>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Recent Reports</h3>
        </div>
        <div class="card-body">
            <div style="display: grid; gap: 10px;">
                <a href="<?php echo e(route('admin.reports.index')); ?>" class="btn btn-secondary" style="text-align: center;">📈 Sales Reports</a>
                <a href="<?php echo e(route('admin.purchase-reports.index')); ?>" class="btn btn-secondary" style="text-align: center;">📊 Purchase Reports</a>
                <a href="<?php echo e(route('admin.inventory.index')); ?>" class="btn btn-secondary" style="text-align: center;">📦 Stock Dashboard</a>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.card-body h3 {
    color: #333;
    margin-bottom: 5px;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>