
<?php $__env->startSection('title', 'Customer-Wise Bills Report'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" style="max-width: 1200px; margin: 0 auto; padding: 20px;">
        <div class="header" style="margin-bottom: 30px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <h2 style="font-size: 28px; color: #333; margin: 0;">Customer-Wise Bills Report</h2>
                <a href="<?php echo e(route('admin.reports.index')); ?>" class="back-link" style="color: #667eea; text-decoration: none;">← Back to Reports</a>
            </div>
        </div>

        <div class="filter-box" style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #e0e0e0;">
            <form action="<?php echo e(route('admin.reports.customer-sales')); ?>" method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: flex-end;">
                <div>
                    <label for="start_date" style="font-weight: 500; color: #333; display: block; margin-bottom: 6px;">From:</label>
                    <input type="date" id="start_date" name="start_date" value="<?php echo e($startDate); ?>" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
                </div>
                <div>
                    <label for="end_date" style="font-weight: 500; color: #333; display: block; margin-bottom: 6px;">To:</label>
                    <input type="date" id="end_date" name="end_date" value="<?php echo e($endDate); ?>" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
                </div>
                <button type="submit" style="padding: 8px 24px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 500;">View Report</button>
                <a href="<?php echo e(route('admin.reports.customer-sales.export', ['start_date' => $startDate, 'end_date' => $endDate])); ?>" style="padding: 8px 24px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: 500; text-decoration: none; display: inline-block; text-align: center;">📊 Export to CSV</a>
            </form>
        </div>

        <?php if($customerBills->count() > 0): ?>
            <h3 style="font-size: 20px; color: #333; margin-bottom: 20px; margin-top: 30px;">Customer Bills Summary (<?php echo e(count($customerBills)); ?> customers)</h3>
            <div class="table-container" style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 30px;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f8f9fa; border-bottom: 2px solid #e0e0e0;">
                            <th style="padding: 16px; text-align: left; font-weight: 600; color: #333; font-size: 14px;">Customer Name</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Total Revenue</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Earned Amount</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Debt / Bakaya</th>
                            <th style="padding: 16px; text-align: center; font-weight: 600; color: #333; font-size: 14px;">Bills</th>
                            <th style="padding: 16px; text-align: right; font-weight: 600; color: #333; font-size: 14px;">Average Amount</th>
                            <th style="padding: 16px; text-align: center; font-weight: 600; color: #333; font-size: 14px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $customerBills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="border-bottom: 1px solid #e0e0e0;">
                                <td style="padding: 14px 16px; font-weight: 500; color: #333;">
                                    <?php if($item['customer']): ?>
                                        <a href="<?php echo e(route('admin.customers.show', $item['customer'])); ?>" style="color: #667eea; text-decoration: none; font-weight: 600;"><?php echo e($item['customer']->name); ?></a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹<?php echo e(number_format($item['total_amount'], 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #28a745;">₹<?php echo e(number_format($item['earned'] ?? 0, 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500; color: #ffc107;">₹<?php echo e(number_format($item['debt'] ?? 0, 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: center;"><?php echo e($item['total_transactions']); ?></td>
                                <td style="padding: 14px 16px; text-align: right; font-weight: 500;">₹<?php echo e(number_format($item['average_sale'], 2)); ?></td>
                                <td style="padding: 14px 16px; text-align: center;">
                                    <?php if($item['customer']): ?>
                                        <a href="<?php echo e(route('admin.customers.show', $item['customer'])); ?>" style="color: #667eea; text-decoration: none; font-size: 13px; font-weight: 500;">View</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <?php if($walkInBills->count() > 0): ?>
            <h3 style="font-size: 20px; color: #333; margin-bottom: 20px; margin-top: 30px;">Walk-in Bills Summary</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
                <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h4 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Total Walk-in Revenue</h4>
                    <div style="font-size: 24px; font-weight: 700; color: #333;">₹<?php echo e(number_format($walkInTotal, 2)); ?></div>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #28a745; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h4 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Walk-in Earned</h4>
                    <div style="font-size: 24px; font-weight: 700; color: #333;">₹<?php echo e(number_format($walkInEarned, 2)); ?></div>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #ffc107; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h4 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Walk-in Debt</h4>
                    <div style="font-size: 24px; font-weight: 700; color: #333;">₹<?php echo e(number_format($walkInDebt, 2)); ?></div>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #17a2b8; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h4 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Walk-in Bills</h4>
                    <div style="font-size: 24px; font-weight: 700; color: #333;"><?php echo e($walkInBills->count()); ?></div>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <h4 style="font-size: 12px; color: #999; text-transform: uppercase; margin: 0 0 10px 0; font-weight: 500;">Avg Walk-in Bill</h4>
                    <div style="font-size: 24px; font-weight: 700; color: #333;">₹<?php echo e(number_format($walkInBills->avg('net_amount') ?? 0, 2)); ?></div>
                </div>
            </div>
        <?php endif; ?>

        <div style="margin-top: 40px; background: white; padding: 30px; border-radius: 8px; border: 1px solid #e0e0e0; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <h3 style="font-size: 20px; color: #333; margin-top: 0; margin-bottom: 20px;">Overall Summary (<?php echo e($startDate); ?> to <?php echo e($endDate); ?>)</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div style="border-left: 4px solid #667eea; padding-left: 20px;">
                    <p style="color: #999; font-size: 12px; text-transform: uppercase; margin: 0 0 8px 0; font-weight: 500;">Total Revenue</p>
                    <div style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($overallTotal, 2)); ?></div>
                </div>
                <div style="border-left: 4px solid #28a745; padding-left: 20px;">
                    <p style="color: #999; font-size: 12px; text-transform: uppercase; margin: 0 0 8px 0; font-weight: 500;">Total Earned</p>
                    <div style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($overallEarned, 2)); ?></div>
                </div>
                <div style="border-left: 4px solid #ffc107; padding-left: 20px;">
                    <p style="color: #999; font-size: 12px; text-transform: uppercase; margin: 0 0 8px 0; font-weight: 500;">Total Debt / Bakaya</p>
                    <div style="font-size: 28px; font-weight: 700; color: #333;">₹<?php echo e(number_format($overallDebt, 2)); ?></div>
                </div>
            </div>
        </div>

        <?php if($customerBills->count() === 0 && $walkInBills->count() === 0): ?>
            <div style="background: white; border-radius: 8px; padding: 60px 20px; text-align: center; margin-top: 30px;">
                <h3 style="color: #999; margin-bottom: 10px;">No bills found</h3>
                <p style="color: #999;">Try adjusting the date range or <a href="<?php echo e(route('admin.bills.create')); ?>" style="color: #667eea; text-decoration: none;">create a new bill</a></p>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/reports/customer-sales.blade.php ENDPATH**/ ?>