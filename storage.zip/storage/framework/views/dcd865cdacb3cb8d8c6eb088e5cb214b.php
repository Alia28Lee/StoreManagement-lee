

<?php $__env->startSection('title', 'Purchases'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <div>
            <h1>Purchases</h1>
            <p>Manage purchase orders and payments</p>
        </div>
        <a href="<?php echo e(route('admin.inventory.purchases.create')); ?>" class="btn btn-primary">
            + Add Purchase
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($totalDebt > 0): ?>
        <div class="alert alert-warning">
            <strong>Outstanding Debt: ₹<?php echo e(number_format($totalDebt, 2)); ?></strong>
        </div>
    <?php endif; ?>

    <!-- Filter Form -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
            <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
        </div>
        <div class="card-body" style="padding: 15px;">
            <form method="GET" action="<?php echo e(route('admin.inventory.purchases.index')); ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Reference Number</label>
                    <input type="text" name="search" placeholder="Search reference..." value="<?php echo e(request('search')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Supplier</label>
                    <select name="supplier_id" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- All Suppliers --</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php echo e(request('supplier_id') == $supplier->id ? 'selected' : ''); ?>><?php echo e($supplier->name ?? 'Anonymous'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Payment Status</label>
                    <select name="payment_status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        <option value="">-- All Status --</option>
                        <option value="paid" <?php echo e(request('payment_status') === 'paid' ? 'selected' : ''); ?>>Paid</option>
                        <option value="partial" <?php echo e(request('payment_status') === 'partial' ? 'selected' : ''); ?>>Partial</option>
                        <option value="pending" <?php echo e(request('payment_status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                    </select>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">From Date</label>
                    <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">To Date</label>
                    <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                    <a href="<?php echo e(route('admin.inventory.purchases.index')); ?>" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <?php if($purchases->count() > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Supplier</th>
                        <th>Date</th>
                        <th>Total Amount</th>
                        <th>Paid</th>
                        <th>Debt</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($purchase->reference_number); ?></strong></td>
                            <td>
                                <?php if($purchase->supplier_id): ?>
                                    <a href="<?php echo e(route('admin.inventory.suppliers.show', $purchase->supplier)); ?>"><?php echo e($purchase->supplier->name); ?></a>
                                <?php else: ?>
                                    Anonymous
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($purchase->purchase_date->format('d M Y')); ?></td>
                            <td>₹<?php echo e(number_format($purchase->total_amount, 2)); ?></td>
                            <td>₹<?php echo e(number_format($purchase->paid_amount, 2)); ?></td>
                            <td>₹<?php echo e(number_format($purchase->debt_amount, 2)); ?></td>
                            <td>
                                <?php if($purchase->payment_status === 'paid'): ?>
                                    <span class="badge badge-success">Paid</span>
                                <?php elseif($purchase->payment_status === 'partial'): ?>
                                    <span class="badge badge-warning">Partial</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td class="action-links">
                                <a href="<?php echo e(route('admin.inventory.purchases.show', $purchase)); ?>" title="View">👁</a>
                                <a href="<?php echo e(route('admin.inventory.purchases.edit', $purchase)); ?>" title="Edit">✎</a>
                                <form method="POST" action="<?php echo e(route('admin.inventory.purchases.destroy', $purchase)); ?>" style="display:inline;">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" title="Delete" onclick="return confirm('Delete this purchase?')">🗑</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="pagination">
            <?php echo e($purchases->links()); ?>

        </div>
    <?php else: ?>
        <div class="empty-state">
            <p>No purchases found. <a href="<?php echo e(route('admin.inventory.purchases.create')); ?>">Record one now</a></p>
        </div>
    <?php endif; ?>
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchases/index.blade.php ENDPATH**/ ?>