

<?php $__env->startSection('title', 'Edit Purchase'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Purchase Payment Details</h1>
    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.inventory.purchases.update', $purchase)); ?>" class="form">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <fieldset>
            <legend>Purchase Header</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="reference_number">Reference Number (Read-only)</label>
                    <input type="text" id="reference_number" name="reference_number" class="form-control" 
                           value="<?php echo e($purchase->reference_number); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="purchase_date">Purchase Date *</label>
                    <input type="date" id="purchase_date" name="purchase_date" class="form-control <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('purchase_date', $purchase->purchase_date->format('Y-m-d'))); ?>" required>
                    <?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group">
                <label for="supplier_id">Supplier</label>
                <select id="supplier_id" name="supplier_id" class="form-control <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">-- Select Supplier --</option>
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($supplier->id); ?>" <?php if(old('supplier_id', $purchase->supplier_id) == $supplier->id): echo 'selected'; endif; ?>>
                            <?php echo e($supplier->name ?? 'Anonymous'); ?> <?php if($supplier->phone): ?>(<?php echo e($supplier->phone); ?>)<?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="form-text text-muted">Leave empty for anonymous supplier</small>
                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="notes">Notes</label>
                <textarea id="notes" name="notes" class="form-control" rows="3"><?php echo e(old('notes', $purchase->notes)); ?></textarea>
            </div>
        </fieldset>

        <fieldset>
            <legend>Items Purchased</legend>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchase->purchaseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name); ?></td>
                                <td><?php echo e(number_format($item->quantity, 2)); ?> <?php echo e($item->product->unit); ?></td>
                                <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td>₹<?php echo e(number_format($item->total_price, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <p class="info-text">Note: Items cannot be changed after purchase is recorded. Delete and recreate if needed.</p>
        </fieldset>

        <fieldset>
            <legend>Payment Details</legend>

            <div class="form-row">
                <div class="form-group">
                    <label for="total_amount">Total Amount *</label>
                    <input type="number" id="total_amount" name="total_amount" class="form-control <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('total_amount', $purchase->total_amount)); ?>" step="0.01" required readonly style="background: #f5f5f5;">
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="paid_amount">Amount Paid *</label>
                    <input type="number" id="paid_amount" name="paid_amount" class="form-control <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('paid_amount', $purchase->paid_amount)); ?>" step="0.01" required onchange="calculateDebt()">
                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="payment_status">Payment Status *</label>
                    <select id="payment_status" name="payment_status" class="form-control <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="toggleDebtSection()">
                        <option value="">-- Select Status --</option>
                        <option value="paid" <?php echo e(old('payment_status', $purchase->payment_status) == 'paid' ? 'selected' : ''); ?>>Paid</option>
                        <option value="partial" <?php echo e(old('payment_status', $purchase->payment_status) == 'partial' ? 'selected' : ''); ?>>Partial Payment</option>
                        <option value="pending" <?php echo e(old('payment_status', $purchase->payment_status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    </select>
                    <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="payment_method">Payment Method</label>
                    <input type="text" id="payment_method" name="payment_method" class="form-control" 
                           value="<?php echo e(old('payment_method', $purchase->payment_method)); ?>" placeholder="Cash, Check, Bank Transfer, etc.">
                </div>
            </div>

            <div id="debt-section" class="form-row" <?php if($purchase->payment_status !== 'partial' && $purchase->payment_status !== 'pending'): ?> style="display: none;" <?php endif; ?>>
                <div class="form-group">
                    <label for="debt_amount">Outstanding Debt *</label>
                    <input type="number" id="debt_amount" name="debt_amount" class="form-control <?php $__errorArgs = ['debt_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('debt_amount', $purchase->debt_amount)); ?>" step="0.01" readonly style="background: #f5f5f5;">
                    <small style="color: #666;">Auto-calculated: Total Amount - Amount Paid</small>
                    <?php $__errorArgs = ['debt_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </fieldset>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Update Purchase</button>
            <a href="<?php echo e(route('admin.inventory.purchases.show', $purchase)); ?>" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
.info-text { color: #666; font-size: 13px; margin-top: 10px; }
</style>

<script>
function calculateDebt() {
    const total = parseFloat(document.getElementById('total_amount').value) || 0;
    const paid = parseFloat(document.getElementById('paid_amount').value) || 0;
    const debt = total - paid;
    document.getElementById('debt_amount').value = debt.toFixed(2);
}

function toggleDebtSection() {
    const status = document.getElementById('payment_status').value;
    const debtSection = document.getElementById('debt-section');
    
    if (status === 'partial' || status === 'pending') {
        debtSection.style.display = 'grid';
        calculateDebt();
    } else {
        debtSection.style.display = 'none';
        document.getElementById('debt_amount').value = '0';
    }
}

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    const paidAmount = parseFloat(document.getElementById('paid_amount').value);
    const totalAmount = parseFloat(document.getElementById('total_amount').value);
    
    if (status === 'paid' && paidAmount < totalAmount) {
        alert('For "Paid" status, Amount Paid must equal Total Amount');
        e.preventDefault();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchases/edit.blade.php ENDPATH**/ ?>