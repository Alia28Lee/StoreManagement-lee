

<?php $__env->startSection('title', 'Monthly Purchase Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <div>
            <h1>Monthly Purchase Report</h1>
            <p><?php echo e(\Carbon\Carbon::parse($month . '-01')->format('F Y')); ?></p>
        </div>
        <a href="<?php echo e(route('admin.purchase-reports.index')); ?>" class="btn btn-secondary">Back to Reports</a>
    </div>

    <form method="GET" action="<?php echo e(route('admin.purchase-reports.monthly')); ?>" style="margin-bottom: 20px;">
        <div style="display: flex; gap: 10px;">
            <input type="month" name="month" value="<?php echo e($month); ?>" class="form-control" style="flex: 1; max-width: 200px;">
            <button type="submit" class="btn btn-primary">Filter</button>
        </div>
    </form>

    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Purchases</h4>
                <p style="font-size: 24px; margin: 10px 0;"><?php echo e($totals['purchases_count']); ?></p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Quantity</h4>
                <p style="font-size: 24px; margin: 10px 0;"><?php echo e(number_format($totals['total_quantity'], 2)); ?></p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Amount</h4>
                <p style="font-size: 24px; margin: 10px 0;">₹<?php echo e(number_format($totals['total_amount'], 2)); ?></p>
            </div>
        </div>
        <div class="card">
            <div class="card-body" style="text-align: center;">
                <h4>Total Debt</h4>
                <p style="font-size: 24px; margin: 10px 0; color: red;">₹<?php echo e(number_format($totals['total_debt'], 2)); ?></p>
            </div>
        </div>
    </div>

    <?php if(count($reportData) > 0): ?>
        <?php $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card" style="margin-bottom: 20px;">
                <div class="card-header">
                    <h3><?php echo e($category); ?></h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Unit</th>
                                    <th>Quantity Purchased</th>
                                    <th>Items Count</th>
                                    <th>Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productName => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong><?php echo e($productName); ?></strong></td>
                                        <td><?php echo e($data['unit']); ?></td>
                                        <td><?php echo e(number_format($data['quantity'], 2)); ?></td>
                                        <td><?php echo e($data['items_count']); ?></td>
                                        <td>₹<?php echo e(number_format($data['total_amount'], 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="alert alert-info">
            No purchases recorded for this month.
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('admin.purchase-reports.index')); ?>" class="btn btn-secondary">Back to Reports</a>
</div>

<style>
.card { border: 1px solid #ddd; border-radius: 4px; }
.card-header { background: #f5f5f5; padding: 15px; border-bottom: 1px solid #ddd; }
.card-header h3 { margin: 0; }
.card-body { padding: 15px; }
.table { width: 100%; border-collapse: collapse; }
.table th { background: #f9f9f9; padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
.table td { padding: 10px; border-bottom: 1px solid #eee; }
.btn-secondary { padding: 8px 16px; background: #6c757d; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; }
.btn-secondary:hover { background: #5a6268; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchase-reports/monthly.blade.php ENDPATH**/ ?>