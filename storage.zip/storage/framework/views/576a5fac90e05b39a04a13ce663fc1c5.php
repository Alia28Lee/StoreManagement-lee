

<?php $__env->startSection('title', 'Product Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <div>
            <h1>Product Categories</h1>
            <p>Manage grocery categories</p>
        </div>
        <a href="<?php echo e(route('admin.inventory.categories.create')); ?>" class="btn btn-primary">
            + Add Category
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Filter Form -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
            <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
        </div>
        <div class="card-body" style="padding: 15px;">
            <form method="GET" action="<?php echo e(route('admin.inventory.categories.index')); ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; align-items: end;">
                <div>
                    <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Category Name</label>
                    <input type="text" name="search" placeholder="Search categories..." value="<?php echo e(request('search')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                    <a href="<?php echo e(route('admin.inventory.categories.index')); ?>" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <?php if($categories->count() > 0): ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Category Name</th>
                        <th>Products</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong><?php echo e($category->name); ?></strong></td>
                            <td><?php echo e($category->products_count ?? 0); ?></td>
                            <td><?php echo e(Str::limit($category->description, 50)); ?></td>
                            <td class="action-links">
                                <a href="<?php echo e(route('admin.inventory.categories.show', $category)); ?>" title="View">👁</a>
                                <a href="<?php echo e(route('admin.inventory.categories.edit', $category)); ?>" title="Edit">✎</a>
                                <form method="POST" action="<?php echo e(route('admin.inventory.categories.destroy', $category)); ?>" style="display:inline;">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" title="Delete" onclick="return confirm('Delete this category?')">🗑</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="pagination">
            <?php echo e($categories->links()); ?>

        </div>
    <?php else: ?>
        <div class="empty-state">
            <p>No categories found. <a href="<?php echo e(route('admin.inventory.categories.create')); ?>">Create one now</a></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>