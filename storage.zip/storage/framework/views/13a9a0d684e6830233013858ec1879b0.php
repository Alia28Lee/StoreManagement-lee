

<?php $__env->startSection('title', 'Edit Bill'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Edit Bill - <?php echo e($bill->invoice_number); ?></h1>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.bills.update', $bill)); ?>" class="form">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <fieldset>
        <legend>Bill Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="invoice_number">Invoice Number (Read-only)</label>
                <input type="text" id="invoice_number" name="invoice_number" class="form-control" 
                       value="<?php echo e($bill->invoice_number); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="bill_date">Bill Date *</label>
                <input type="date" id="bill_date" name="bill_date" class="form-control <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('bill_date', $bill->bill_date->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="updated_at">Last Updated (Read-only)</label>
                <input type="text" id="updated_at" class="form-control" 
                       value="<?php echo e($bill->updated_at->format('d M Y, h:i A')); ?>" readonly style="background: #f5f5f5;">
            </div>
        </div>

        <div class="form-group">
            <label for="customer_id">Customer</label>
            <select id="customer_id" name="customer_id" class="form-control">
                <option value="">-- Walk-in Customer --</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id', $bill->customer_id) == $customer->id ? 'selected' : ''); ?>>
                        <?php echo e($customer->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </fieldset>

    <fieldset>
        <legend>Items Purchased (Read-only)</legend>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Item Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bill->billItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td><?php echo e(number_format($item->quantity, 2)); ?> <?php echo e($item->product->unit); ?></td>
                            <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                            <td>₹<?php echo e(number_format($item->item_total, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <p style="color: #999; font-size: 13px; margin-top: 10px;">Note: Items cannot be changed. Delete and recreate the bill if you need to modify items.</p>
    </fieldset>

    <fieldset>
        <legend>Bill Summary</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="subtotal_label">Sub Total</label>
                <input type="text" id="subtotal_label" class="form-control" value="₹<?php echo e(number_format($bill->total_amount, 2)); ?>" readonly style="background: #f5f5f5;">
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Payment Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="discount_amount">Discount Amount</label>
                <input type="number" id="discount_amount" name="discount_amount" class="form-control <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('discount_amount', $bill->discount_amount)); ?>" step="0.01">
                <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="payment_status">Payment Status *</label>
                <select id="payment_status" name="payment_status" class="form-control <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="toggleAmountPaidField()">
                    <option value="">-- Select Status --</option>
                    <option value="paid" <?php echo e(old('payment_status', $bill->payment_status) == 'paid' ? 'selected' : ''); ?>>Paid</option>
                    <option value="partial" <?php echo e(old('payment_status', $bill->payment_status) == 'partial' ? 'selected' : ''); ?>>Partial Payment</option>
                    <option value="pending" <?php echo e(old('payment_status', $bill->payment_status) == 'pending' ? 'selected' : ''); ?>>Pending</option>
                </select>
                <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="payment_method">Payment Method</label>
                <input type="text" id="payment_method" name="payment_method" class="form-control" 
                       value="<?php echo e(old('payment_method', $bill->payment_method)); ?>" placeholder="Cash, Card, etc.">
            </div>
        </div>

        <div id="amount-paid-section" class="form-row" <?php if($bill->payment_status !== 'partial' && $bill->payment_status !== 'pending' && $bill->payment_status !== 'paid'): ?> style="display: none;" <?php endif; ?>>
            <div class="form-group">
                <label for="amount_paid">Amount Paid / <span class="devanagari">दी गई रकम</span></label>
                <input type="number" id="amount_paid" name="amount_paid" class="form-control <?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('amount_paid', $bill->amount_paid)); ?>" step="0.01" onchange="calculateDebt()" oninput="calculateDebt()">
                <small style="color: #666;">Actual amount paid by customer</small>
                <?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="debt_label">Debt Amount / <span class="devanagari">बकाया रकम</span></label>
                <input type="text" id="debt_label" class="form-control" value="₹<?php echo e(number_format($bill->debt_amount ?? 0, 2)); ?>" readonly style="background: #f5f5f5;">
            </div>
        </div>

        <div class="form-group">
            <label for="notes">Notes</label>
            <textarea id="notes" name="notes" class="form-control" rows="3"><?php echo e(old('notes', $bill->notes)); ?></textarea>
        </div>
    </fieldset>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Update Bill</button>
        <a href="<?php echo e(route('admin.bills.show', $bill)); ?>" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
</style>

<script>
const subtotal = <?php echo e($bill->total_amount); ?>;

function calculateDebt() {
    const netAmount = subtotal - (parseFloat(document.getElementById('discount_amount').value) || 0);
    const amountPaid = parseFloat(document.getElementById('amount_paid').value) || 0;
    
    // Debt = Net Amount - Amount Paid
    const debtAmount = Math.max(0, netAmount - amountPaid);
    document.getElementById('debt_label').value = '₹' + debtAmount.toFixed(2);
}

function toggleAmountPaidField() {
    const status = document.getElementById('payment_status').value;
    const amountPaidSection = document.getElementById('amount-paid-section');
    
    if (status === 'partial' || status === 'pending' || status === 'paid') {
        amountPaidSection.style.display = 'grid';
        
        if (status === 'paid') {
            const netAmount = subtotal - (parseFloat(document.getElementById('discount_amount').value) || 0);
            document.getElementById('amount_paid').value = netAmount.toFixed(2);
        }
    } else {
        amountPaidSection.style.display = 'none';
        document.getElementById('amount_paid').value = '0';
    }
    
    calculateDebt();
}

document.getElementById('payment_status').addEventListener('change', toggleAmountPaidField);
document.getElementById('discount_amount').addEventListener('change', calculateDebt);
document.getElementById('discount_amount').addEventListener('input', calculateDebt);

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    
    if (!status) {
        e.preventDefault();
        alert('Please select a payment status');
        return false;
    }
});

// Initialize
toggleAmountPaidField();
calculateDebt();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/bills/edit.blade.php ENDPATH**/ ?>