

<?php $__env->startSection('title', 'Purchase Reports'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Purchase Reports</h1>
    <p>Analyze purchases by period and category</p>

    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-top: 30px;">
        <div class="card">
            <div class="card-header">
                <h3>📅 Daily Report</h3>
            </div>
            <div class="card-body">
                <p>View purchases for a specific date</p>
                <form method="GET" action="<?php echo e(route('admin.purchase-reports.daily')); ?>" style="display: flex; gap: 10px;">
                    <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control">
                    <button type="submit" class="btn btn-primary">View</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>📊 Weekly Report</h3>
            </div>
            <div class="card-body">
                <p>View purchases for a week</p>
                <form method="GET" action="<?php echo e(route('admin.purchase-reports.weekly')); ?>" style="display: flex; gap: 10px;">
                    <input type="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" class="form-control">
                    <button type="submit" class="btn btn-primary">View</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>📈 Monthly Report</h3>
            </div>
            <div class="card-body">
                <p>View purchases for a month</p>
                <form method="GET" action="<?php echo e(route('admin.purchase-reports.monthly')); ?>" style="display: flex; gap: 10px;">
                    <input type="month" name="month" value="<?php echo e(date('Y-m')); ?>" class="form-control">
                    <button type="submit" class="btn btn-primary">View</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>📋 Yearly Report</h3>
            </div>
            <div class="card-body">
                <p>View purchases for a year</p>
                <form method="GET" action="<?php echo e(route('admin.purchase-reports.yearly')); ?>" style="display: flex; gap: 10px;">
                    <input type="number" name="year" min="2000" max="2099" value="<?php echo e(date('Y')); ?>" class="form-control">
                    <button type="submit" class="btn btn-primary">View</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.card { border: 1px solid #ddd; border-radius: 4px; }
.card-header { background: #f5f5f5; padding: 15px; border-bottom: 1px solid #ddd; }
.card-header h3 { margin: 0; font-size: 16px; }
.card-body { padding: 20px; }
.form-control { padding: 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px; flex: 1; }
.btn-primary { padding: 8px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
.btn-primary:hover { background: #0056b3; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchase-reports/index.blade.php ENDPATH**/ ?>