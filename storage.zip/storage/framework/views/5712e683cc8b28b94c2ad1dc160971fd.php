

<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <div>
            <h1><?php echo e($product->name); ?></h1>
            <p><?php echo e($product->category?->name ?? 'Uncategorized'); ?></p>
        </div>
        <div>
            <a href="<?php echo e(route('admin.inventory.products.edit', $product)); ?>" class="btn btn-secondary">Edit</a>
            <form method="POST" action="<?php echo e(route('admin.inventory.products.destroy', $product)); ?>" style="display:inline;">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this product?')">Delete</button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Product Details</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Name:</span>
                <span class="value"><?php echo e($product->name); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Category:</span>
                <span class="value"><?php echo e($product->category?->name ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">SKU:</span>
                <span class="value"><?php echo e($product->sku ?? '-'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Unit:</span>
                <span class="value"><?php echo e($product->unit); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Current Stock:</span>
                <span class="value">
                    <?php echo e(number_format($product->current_stock, 2)); ?> <?php echo e($product->unit); ?>

                    <?php if($product->current_stock <= $product->reorder_level): ?>
                        <span class="badge badge-danger">Low Stock</span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Reorder Level:</span>
                <span class="value"><?php echo e(number_format($product->reorder_level, 2)); ?> <?php echo e($product->unit); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Description:</span>
                <span class="value"><?php echo e($product->description ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Created:</span>
                <span class="value"><?php echo e($product->created_at->format('d M Y H:i')); ?></span>
            </div>
        </div>
    </div>

    <a href="<?php echo e(route('admin.inventory.products.index')); ?>" class="btn btn-secondary" style="margin-top: 20px;">Back to Products</a>
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-left: 10px; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/products/show.blade.php ENDPATH**/ ?>