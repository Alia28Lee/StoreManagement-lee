

<?php $__env->startSection('title', $bill->invoice_number); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1><?php echo e($bill->invoice_number); ?></h1>
        <p><?php echo e($bill->bill_date->format('d F Y')); ?></p>
    </div>
    <div>
        <a href="<?php echo e(route('admin.bills.invoice', $bill)); ?>" class="btn btn-secondary">📄 Generate Invoice</a>
        <a href="<?php echo e(route('admin.bills.edit', $bill)); ?>" class="btn btn-secondary">Edit</a>
        <form method="POST" action="<?php echo e(route('admin.bills.destroy', $bill)); ?>" style="display:inline;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this bill?')">Delete</button>
        </form>
    </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3>Bill Information</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Invoice Number:</span>
                <span class="value"><?php echo e($bill->invoice_number); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Bill Date:</span>
                <span class="value"><?php echo e($bill->bill_date->format('d M Y')); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Last Updated:</span>
                <span class="value"><?php echo e($bill->updated_at->format('d M Y, h:i A')); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Customer:</span>
                <span class="value"><?php echo e($bill->customer?->name ?? 'Walk-in Customer'); ?></span>
            </div>
            <?php if($bill->customer): ?>
                <div class="detail-row">
                    <span class="label">Phone:</span>
                    <span class="value"><?php echo e($bill->customer->phone ?? 'N/A'); ?></span>
                </div>
            <?php endif; ?>
            <div class="detail-row">
                <span class="label">Payment Method:</span>
                <span class="value"><?php echo e($bill->payment_method ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Notes:</span>
                <span class="value"><?php echo e($bill->notes ?? 'N/A'); ?></span>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Bill Summary</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Items Count:</span>
                <span class="value"><?php echo e($bill->billItems->count()); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Sub Total:</span>
                <span class="value" style="font-weight: bold;">₹<?php echo e(number_format($bill->total_amount, 2)); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Discount:</span>
                <span class="value">- ₹<?php echo e(number_format($bill->discount_amount, 2)); ?></span>
            </div>
            <div class="detail-row" style="background: #f5f5f5; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Net Amount:</span>
                <span class="value" style="font-weight: bold;">₹<?php echo e(number_format($bill->net_amount, 2)); ?></span>
            </div>
            <div class="detail-row" style="background: #e8f5e9; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Amount Paid / दी गई रकम:</span>
                <span class="value" style="font-weight: bold; color: #2e7d32;">₹<?php echo e(number_format($bill->amount_paid ?? 0, 2)); ?></span>
            </div>
            <div class="detail-row" style="background: #fff3cd; border-radius: 4px; padding: 12px; margin: 10px 0;">
                <span class="label" style="font-weight: bold;">Debt Amount / बकाया रकम:</span>
                <span class="value" style="font-weight: bold; color: #856404;">₹<?php echo e(number_format($bill->debt_amount ?? 0, 2)); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Payment Status:</span>
                <span class="value">
                    <?php if($bill->payment_status === 'paid'): ?>
                        <span class="badge badge-success">Paid</span>
                    <?php elseif($bill->payment_status === 'partial'): ?>
                        <span class="badge badge-warning">Partial Payment</span>
                    <?php else: ?>
                        <span class="badge badge-danger">Pending (Udhaar)</span>
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 20px;">
    <div class="card-header">
        <h3>Items Sold</h3>
    </div>
    <div class="card-body">
        <?php if($bill->billItems->count() > 0): ?>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Item Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bill->billItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($item->product->name); ?></strong></td>
                                <td><?php echo e(number_format($item->quantity, 2)); ?> <?php echo e($item->product->unit); ?></td>
                                <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                <td>₹<?php echo e(number_format($item->item_total, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr style="background: #f5f5f5; font-weight: bold;">
                            <td colspan="3" style="text-align: right;">Subtotal:</td>
                            <td>₹<?php echo e(number_format($bill->billItems->sum('item_total'), 2)); ?></td>
                        </tr>
                        <?php if($bill->discount_amount > 0): ?>
                            <tr style="background: #f5f5f5;">
                                <td colspan="3" style="text-align: right;">Discount:</td>
                                <td>- ₹<?php echo e(number_format($bill->discount_amount, 2)); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr style="background: #e8f5e9;">
                            <td colspan="3" style="text-align: right; font-weight: bold;">Total:</td>
                            <td style="font-weight: bold;">₹<?php echo e(number_format($bill->net_amount, 2)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>No items in this bill.</p>
        <?php endif; ?>
    </div>
</div>

<a href="<?php echo e(route('admin.bills.index')); ?>" class="btn btn-secondary" style="margin-top: 20px;">Back to Bills</a>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/bills/show.blade.php ENDPATH**/ ?>