

<?php $__env->startSection('title', $purchase->reference_number); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <div>
            <h1><?php echo e($purchase->reference_number); ?></h1>
            <p><?php echo e($purchase->supplier->name ?? 'Anonymous'); ?> • <?php echo e($purchase->purchase_date->format('d M Y')); ?></p>
        </div>
        <div>
            <a href="<?php echo e(route('admin.inventory.purchases.edit', $purchase)); ?>" class="btn btn-secondary">Edit</a>
            <form method="POST" action="<?php echo e(route('admin.inventory.purchases.destroy', $purchase)); ?>" style="display:inline;">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this purchase?')">Delete</button>
            </form>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div class="card">
            <div class="card-header">
                <h3>Purchase Details</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Reference:</span>
                    <span class="value"><?php echo e($purchase->reference_number); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Supplier:</span>
                    <span class="value">
                        <?php if($purchase->supplier): ?>
                            <a href="<?php echo e(route('admin.inventory.suppliers.show', $purchase->supplier)); ?>"><?php echo e($purchase->supplier->name); ?></a>
                        <?php else: ?>
                            Anonymous
                        <?php endif; ?>
                    </span>
                </div>
                <div class="detail-row">
                    <span class="label">Date:</span>
                    <span class="value"><?php echo e($purchase->purchase_date->format('d M Y')); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Payment Method:</span>
                    <span class="value"><?php echo e($purchase->payment_method ?? 'N/A'); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Notes:</span>
                    <span class="value"><?php echo e($purchase->notes ?? 'N/A'); ?></span>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Payment Summary</h3>
            </div>
            <div class="card-body">
                <div class="detail-row">
                    <span class="label">Total Amount:</span>
                    <span class="value" style="font-weight: bold;">₹<?php echo e(number_format($purchase->total_amount, 2)); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Amount Paid:</span>
                    <span class="value" style="color: green;">₹<?php echo e(number_format($purchase->paid_amount, 2)); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Outstanding Debt:</span>
                    <span class="value" style="color: red; font-weight: bold;">₹<?php echo e(number_format($purchase->debt_amount, 2)); ?></span>
                </div>
                <div class="detail-row">
                    <span class="label">Status:</span>
                    <span class="value">
                        <?php if($purchase->payment_status === 'paid'): ?>
                            <span class="badge badge-success">Paid</span>
                        <?php elseif($purchase->payment_status === 'partial'): ?>
                            <span class="badge badge-warning">Partial Payment</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Pending</span>
                        <?php endif; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <div class="card-header">
            <h3>Items Purchased</h3>
        </div>
        <div class="card-body">
            <?php if($purchase->purchaseItems->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Category</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $purchase->purchaseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="<?php echo e(route('admin.inventory.products.show', $item->product)); ?>"><?php echo e($item->product->name); ?></a></td>
                                    <td><?php echo e($item->product->category?->name ?? '-'); ?></td>
                                    <td><?php echo e(number_format($item->quantity, 2)); ?> <?php echo e($item->product->unit); ?></td>
                                    <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($item->total_price, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr style="background: #f5f5f5; font-weight: bold;">
                                <td colspan="4" style="text-align: right;">Total:</td>
                                <td>₹<?php echo e(number_format($purchase->purchaseItems->sum('total_price'), 2)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No items in this purchase.</p>
            <?php endif; ?>
        </div>
    </div>

    <a href="<?php echo e(route('admin.inventory.purchases.index')); ?>" class="btn btn-secondary" style="margin-top: 20px;">Back to Purchases</a>
</div>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/purchases/show.blade.php ENDPATH**/ ?>