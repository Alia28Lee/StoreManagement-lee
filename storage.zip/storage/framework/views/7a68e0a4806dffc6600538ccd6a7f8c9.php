

<?php $__env->startSection('title', 'User Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1><?php echo e($user->profile?->full_name ?? $user->name); ?></h1>
        <p><?php echo e($user->email); ?></p>
    </div>
    <div>
        <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-secondary">Edit Profile</a>
        <a href="<?php echo e(route('admin.users.change-password-form', $user)); ?>" class="btn btn-secondary">🔐 Change Password</a>
        <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>" style="display:inline;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Delete this user?')">Delete</button>
        </form>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
    <div class="card">
        <div class="card-header">
            <h3>Account Information</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Email:</span>
                <span class="value"><?php echo e($user->email); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Role:</span>
                <span class="value">
                    <span class="badge" style="background: #e3f2fd; color: #1976d2; padding: 4px 8px; border-radius: 3px;">
                        <?php echo e(ucfirst($user->profile?->role ?? 'User')); ?>

                    </span>
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Status:</span>
                <span class="value">
                    <?php if($user->profile?->is_active): ?>
                        <span class="badge" style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 3px;">Active</span>
                    <?php else: ?>
                        <span class="badge" style="background: #f8d7da; color: #721c24; padding: 4px 8px; border-radius: 3px;">Inactive</span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="detail-row">
                <span class="label">Created:</span>
                <span class="value"><?php echo e($user->created_at->format('d M Y, h:i A')); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Last Updated:</span>
                <span class="value"><?php echo e($user->updated_at->format('d M Y, h:i A')); ?></span>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3>Shop & Profile Details</h3>
        </div>
        <div class="card-body">
            <div class="detail-row">
                <span class="label">Shop Name:</span>
                <span class="value"><?php echo e($user->profile?->shop_name ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Full Name:</span>
                <span class="value"><?php echo e($user->profile?->full_name ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Phone:</span>
                <span class="value"><?php echo e($user->profile?->phone ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">City:</span>
                <span class="value"><?php echo e($user->profile?->city ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">State:</span>
                <span class="value"><?php echo e($user->profile?->state ?? 'N/A'); ?></span>
            </div>
            <div class="detail-row">
                <span class="label">Address:</span>
                <span class="value"><?php echo e($user->profile?->address ?? 'N/A'); ?></span>
            </div>
        </div>
    </div>
</div>

<a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary" style="margin-top: 20px;">Back to Users</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/users/show.blade.php ENDPATH**/ ?>