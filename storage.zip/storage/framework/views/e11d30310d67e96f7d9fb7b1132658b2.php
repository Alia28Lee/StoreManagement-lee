

<?php $__env->startSection('title', 'Bills'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1>Bills</h1>
        <p>Multi-product sales and invoices</p>
    </div>
    <a href="<?php echo e(route('admin.bills.create')); ?>" class="btn btn-primary">
        + Create New Bill
    </a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<div class="card" style="margin-bottom: 20px;">
    <div class="card-body" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;">
        <div>
            <p style="color: #999; font-size: 14px;">Total Revenue</p>
            <h3 style="margin: 5px 0;">₹<?php echo e(number_format($totalRevenue, 2)); ?></h3>
        </div>
        <div>
            <p style="color: #999; font-size: 14px;">Total Paid</p>
            <h3 style="margin: 5px 0; color: #28a745;">₹<?php echo e(number_format($totalPaid, 2)); ?></h3>
        </div>
        <div>
            <p style="color: #999; font-size: 14px;">Total Debt</p>
            <h3 style="margin: 5px 0; color: #ffc107;">₹<?php echo e(number_format($totalDebt, 2)); ?></h3>
        </div>
        <div>
            <p style="color: #999; font-size: 14px;">Total Bills</p>
            <h3 style="margin: 5px 0;"><?php echo e($bills->total()); ?></h3>
        </div>
    </div>
</div>

<!-- Filter Form -->
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header" style="padding: 15px; border-bottom: 1px solid #e0e0e0;">
        <h5 style="margin: 0; font-size: 16px;">🔍 Filters</h5>
    </div>
    <div class="card-body" style="padding: 15px;">
        <form method="GET" action="<?php echo e(route('admin.bills.index')); ?>" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Invoice Number</label>
                <input type="text" name="search" placeholder="Search invoice..." value="<?php echo e(request('search')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Customer</label>
                <select name="customer_id" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- All Customers --</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php echo e(request('customer_id') == $customer->id ? 'selected' : ''); ?>><?php echo e($customer->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">Payment Status</label>
                <select name="payment_status" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                    <option value="">-- All Status --</option>
                    <option value="paid" <?php echo e(request('payment_status') === 'paid' ? 'selected' : ''); ?>>Paid</option>
                    <option value="partial" <?php echo e(request('payment_status') === 'partial' ? 'selected' : ''); ?>>Partial</option>
                    <option value="pending" <?php echo e(request('payment_status') === 'pending' ? 'selected' : ''); ?>>Pending</option>
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">From Date</label>
                <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div>
                <label style="display: block; margin-bottom: 5px; font-size: 14px; font-weight: 500;">To Date</label>
                <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            <div style="display: flex; gap: 10px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;">Apply Filters</button>
                <a href="<?php echo e(route('admin.bills.index')); ?>" class="btn btn-secondary" style="flex: 1; text-align: center;">Reset</a>
            </div>
        </form>
    </div>
</div>

<?php if($bills->count() > 0): ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Invoice #</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Total Amount</th>
                    <th>Discount</th>
                    <th>Net Amount</th>
                    <th>Amount Paid</th>
                    <th>Debt / बकाया</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?php echo e($bill->invoice_number); ?></strong></td>
                        <td><?php echo e($bill->customer?->name ?? 'Walk-in Customer'); ?></td>
                        <td><?php echo e($bill->bill_date->format('d M Y')); ?></td>
                        <td><?php echo e($bill->billItems->count()); ?></td>
                        <td>₹<?php echo e(number_format($bill->total_amount, 2)); ?></td>
                        <td>₹<?php echo e(number_format($bill->discount_amount, 2)); ?></td>
                        <td><strong>₹<?php echo e(number_format($bill->net_amount, 2)); ?></strong></td>
                        <td style="color: #28a745; font-weight: 500;">₹<?php echo e(number_format($bill->amount_paid ?? 0, 2)); ?></td>
                        <td style="color: #ffc107; font-weight: 500;">₹<?php echo e(number_format($bill->debt_amount ?? 0, 2)); ?></td>
                        <td>
                            <?php if($bill->payment_status === 'paid'): ?>
                                <span class="badge badge-success">Paid</span>
                            <?php elseif($bill->payment_status === 'partial'): ?>
                                <span class="badge badge-warning">Partial</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="action-links">
                            <a href="<?php echo e(route('admin.bills.show', $bill)); ?>" title="View">👁</a>
                            <a href="<?php echo e(route('admin.bills.invoice', $bill)); ?>" title="Invoice">📄</a>
                            <a href="<?php echo e(route('admin.bills.edit', $bill)); ?>" title="Edit">✎</a>
                            <form method="POST" action="<?php echo e(route('admin.bills.destroy', $bill)); ?>" style="display:inline;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" title="Delete" onclick="return confirm('Delete this bill?')">🗑</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="pagination">
        <?php echo e($bills->links()); ?>

    </div>
<?php else: ?>
    <div class="empty-state">
        <p>No bills found. <a href="<?php echo e(route('admin.bills.create')); ?>">Create one now</a></p>
    </div>
<?php endif; ?>

<style>
.badge { padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.badge-success { background: #d4edda; color: #155724; }
.badge-warning { background: #fff3cd; color: #856404; }
.badge-danger { background: #f8d7da; color: #721c24; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/bills/index.blade.php ENDPATH**/ ?>