<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Admin Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
        }

        .login-container {
            background: white;
            padding: clamp(20px, 8vw, 40px);
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .login-container h1 {
            text-align: center;
            color: #333;
            margin-bottom: clamp(20px, 5vw, 30px);
            font-size: clamp(18px, 5vw, 24px);
        }

        .form-group {
            margin-bottom: clamp(15px, 3vw, 20px);
        }

        label {
            display: block;
            margin-bottom: 6px;
            color: #555;
            font-weight: 500;
            font-size: clamp(13px, 3vw, 14px);
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: clamp(10px, 2vw, 12px);
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px; /* Prevents zoom on iOS */
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .error {
            color: #e74c3c;
            font-size: clamp(12px, 2vw, 14px);
            margin-top: 5px;
            padding: 10px;
            background: #f8d7da;
            border-left: 3px solid #e74c3c;
            border-radius: 3px;
        }

        .error ul {
            margin: 0;
            padding-left: 20px;
        }

        .error li {
            margin: 3px 0;
        }

        .alert {
            padding: 10px;
            border-radius: 3px;
            margin-bottom: 20px;
            border-left: 3px solid;
            font-size: clamp(12px, 2vw, 14px);
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border-left-color: #17a2b8;
        }

        .alert ul {
            margin: 0;
            padding-left: 20px;
        }

        .alert li {
            margin: 3px 0;
        }

        button {
            width: 100%;
            padding: clamp(10px, 2.5vw, 12px);
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: clamp(14px, 3vw, 16px);
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.3s;
            margin-top: clamp(10px, 2vw, 10px);
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        button:active {
            transform: translateY(0);
        }

        @media (max-height: 600px) {
            body {
                padding: 10px;
            }

            .login-container {
                padding: 15px;
                margin: 10px 0;
            }

            .login-container h1 {
                margin-bottom: 15px;
                font-size: 18px;
            }

            .form-group {
                margin-bottom: 12px;
            }
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            .login-container {
                padding: 20px;
                border-radius: 6px;
            }

            input[type="email"],
            input[type="password"] {
                padding: 10px;
            }

            button {
                padding: 10px;
            }
        }

        @media (max-width: 400px) {
            .login-container {
                padding: 15px;
            }

            .login-container h1 {
                font-size: 16px;
                margin-bottom: 15px;
            }

            label {
                font-size: 12px;
            }

            input[type="email"],
            input[type="password"] {
                padding: 8px;
                font-size: 15px;
            }

            button {
                padding: 8px;
                font-size: 14px;
            }

            .error {
                font-size: 11px;
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Admin Login</h1>

        <?php if(session('message')): ?>
            <div class="alert alert-info" style="margin-bottom: 20px;">
                ℹ️ <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.login.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="email">Email Address</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?php echo e(old('email')); ?>"
                    required
                    autofocus
                >
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    required
                >
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH G:\Store Account Management\backend\resources\views/admin/login.blade.php ENDPATH**/ ?>