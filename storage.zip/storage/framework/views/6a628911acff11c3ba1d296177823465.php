

<?php $__env->startSection('title', 'Create Bill'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Create New Bill</h1>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.bills.store')); ?>" class="form">
    <?php echo csrf_field(); ?>

    <fieldset>
        <legend>Bill Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="invoice_number">Invoice Number / <span class="devanagari">चालान संख्या</span> *</label>
                <input type="text" id="invoice_number" name="invoice_number" class="form-control <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('invoice_number', $invoiceNumber)); ?>" required readonly>
                <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="bill_date">Bill Date / <span class="devanagari">बिल की तारीख</span> *</label>
                <input type="date" id="bill_date" name="bill_date" class="form-control <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('bill_date', date('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <label for="customer_id">Customer / <span class="devanagari">ग्राहक</span> (Optional)</label>
            <select id="customer_id" name="customer_id" class="form-control">
                <option value="">-- Walk-in Customer --</option>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>" <?php echo e(old('customer_id') == $customer->id ? 'selected' : ''); ?>>
                        <?php echo e($customer->name); ?> (<?php echo e($customer->phone ?? 'N/A'); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </fieldset>

    <fieldset>
        <legend>Products</legend>
        <div class="table-responsive">
            <table class="table" id="items-table">
                <thead>
                    <tr>
                        <th>Product / <span class="devanagari">पण्य</span></th>
                        <th>Quantity / <span class="devanagari">मात्रा</span></th>
                        <th>Unit Price / <span class="devanagari">इकाइ कीमत</span></th>
                        <th>Item Total / <span class="devanagari">कुल कीमत</span></th>
                        <th>Action / <span class="devanagari">कलीक</span></th>
                    </tr>
                </thead>
                <tbody id="items-container">
                    <tr class="item-row">
                        <td>
                            <select name="items[0][product_id]" class="form-control product-select" required onchange="updatePrice(this)">
                                <option value="">-- Select Product --</option>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->selling_price); ?>">
                                        <?php echo e($product->name); ?> (Stock: <?php echo e(number_format($product->current_stock, 2)); ?> <?php echo e($product->unit); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <input type="number" name="items[0][quantity]" class="form-control qty-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
                        </td>
                        <td>
                            <input type="number" name="items[0][unit_price]" class="form-control price-input" step="0.01" min="0.01" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
                        </td>
                        <td>
                            <input type="number" name="items[0][total]" class="form-control total-input" step="0.01" readonly style="background: #f5f5f5;">
                        </td>
                        <td>
                            <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(this)">Remove</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <button type="button" class="btn btn-secondary" onclick="addItem()">+ Add Product</button>
    </fieldset>

    <fieldset>
        <legend>Bill Summary</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="subtotal_label">Sub Total / <span class="devanagari">कुल कीमत</span></label>
                <input type="text" id="subtotal_label" class="form-control" value="₹0.00" readonly style="background: #f5f5f5;">
            </div>
            <div class="form-group">
                <label for="discount_amount">Discount Amount / <span class="devanagari"></span></label>
                <input type="number" id="discount_amount" name="discount_amount" class="form-control <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('discount_amount', 0)); ?>" step="0.01" onchange="calculateFinal()">
                <?php $__errorArgs = ['discount_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="net_label">Net Amount / <span class="devanagari">शुद्ध रकम</span></label>
                <input type="text" id="net_label" class="form-control" value="₹0.00" readonly style="background: #f5f5f5; font-weight: bold;">
            </div>
        </div>
    </fieldset>

    <fieldset>
        <legend>Payment Details</legend>

        <div class="form-row">
            <div class="form-group">
                <label for="payment_status">Payment Status / <span class="devanagari">अदा ल़ितम</span> *</label>
                <select id="payment_status" name="payment_status" class="form-control <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required onchange="toggleAmountPaidField()">
                    <option value="">-- Select Status --</option>
                    <option value="paid" <?php echo e(old('payment_status') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                    <option value="partial" <?php echo e(old('payment_status') == 'partial' ? 'selected' : ''); ?>>Partial Payment</option>
                    <option value="pending" <?php echo e(old('payment_status') == 'pending' ? 'selected' : ''); ?>>Pending (Udhaar)</option>
                </select>
                <?php $__errorArgs = ['payment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="payment_method">Payment Method / <span class="devanagari">भुगतान विधि</span></label>
                <input type="text" id="payment_method" name="payment_method" class="form-control" 
                       value="<?php echo e(old('payment_method')); ?>" placeholder="Cash, Card, Cheque, etc.">
            </div>
        </div>

        <div id="amount-paid-section" class="form-row" style="display: none;">
            <div class="form-group">
                <label for="amount_paid">Amount Paid / <span class="devanagari">दी गई रकम</span> *</label>
                <input type="number" id="amount_paid" name="amount_paid" class="form-control <?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                       value="<?php echo e(old('amount_paid', 0)); ?>" step="0.01" onchange="calculateDebt()" oninput="calculateDebt()">
                <small style="color: #666;">Actual amount paid by customer</small>
                <?php $__errorArgs = ['amount_paid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="debt_label">Debt Amount / <span class="devanagari">बकाया रकम</span></label>
                <input type="text" id="debt_label" class="form-control" value="₹0.00" readonly style="background: #f5f5f5;">
            </div>
        </div>

        <div class="form-group">
            <label for="notes">Notes / <span class="devanagari">सूसपाठें</span></label>
            <textarea id="notes" name="notes" class="form-control" rows="3"><?php echo e(old('notes')); ?></textarea>
        </div>
    </fieldset>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Create Bill</button>
        <a href="<?php echo e(route('admin.bills.index')); ?>" class="btn btn-secondary">Cancel</a>
    </div>
</form>

<style>
fieldset { border: 1px solid #ddd; padding: 15px; margin: 20px 0; border-radius: 4px; }
legend { font-weight: bold; padding: 0 10px; }
.item-row td { padding: 12px; border-bottom: 1px solid #ddd; }
.item-row td input, .item-row td select { width: 100%; }
#items-table { width: 100%; border-collapse: collapse; }
#items-table thead { background: #f8f9fa; }
#items-table th { padding: 12px; text-align: left; border-bottom: 2px solid #ddd; }
</style>

<script>
let itemCount = 1;

function addItem() {
    const container = document.getElementById('items-container');
    const newRow = document.createElement('tr');
    newRow.className = 'item-row';
    newRow.innerHTML = `
        <td>
            <select name="items[${itemCount}][product_id]" class="form-control product-select" required onchange="updatePrice(this)">
                <option value="">-- Select Product --</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->selling_price); ?>">
                        <?php echo e($product->name); ?> (Stock: <?php echo e(number_format($product->current_stock, 2)); ?> <?php echo e($product->unit); ?>)
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </td>
        <td>
            <input type="number" name="items[${itemCount}][quantity]" class="form-control qty-input" step="1" min="1" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
        </td>
        <td>
            <input type="number" name="items[${itemCount}][unit_price]" class="form-control price-input" step="0.50" min="0.00" required onchange="calculateTotal(this)" oninput="calculateTotal(this)">
        </td>
        <td>
            <input type="number" name="items[${itemCount}][total]" class="form-control total-input" step="1" readonly style="background: #f5f5f5;">
        </td>
        <td>
            <button type="button" class="btn btn-sm btn-danger" onclick="removeItem(this)">Remove</button>
        </td>
    `;
    container.appendChild(newRow);
    itemCount++;
}

function removeItem(btn) {
    btn.closest('.item-row').remove();
    calculateFinal();
}

function updatePrice(select) {
    const selectedOption = select.options[select.selectedIndex];
    const price = selectedOption.getAttribute('data-price');
    
    const row = select.closest('.item-row');
    const priceInput = row.querySelector('.price-input');
    
    if (price) {
        priceInput.value = parseFloat(price).toFixed(2);
        calculateTotal(select);
    }
}

function calculateTotal(input) {
    const row = input.closest('.item-row');
    const qty = parseFloat(row.querySelector('.qty-input').value) || 0;
    const price = parseFloat(row.querySelector('.price-input').value) || 0;
    const itemTotal = (qty * price).toFixed(2);
    row.querySelector('.total-input').value = itemTotal;
    calculateFinal();
}

function calculateFinal() {
    let total = 0;
    document.querySelectorAll('.total-input').forEach(input => {
        total += parseFloat(input.value) || 0;
    });
    
    document.getElementById('subtotal_label').value = '₹' + total.toFixed(2);
    
    const discount = parseFloat(document.getElementById('discount_amount').value) || 0;
    const net = total - discount;
    document.getElementById('net_label').value = '₹' + net.toFixed(2);
    
    // Calculate debt based on amount paid
    calculateDebt();
}

function calculateDebt() {
    const status = document.getElementById('payment_status').value;
    const netAmount = parseFloat(document.getElementById('net_label').value.replace('₹', '')) || 0;
    const amountPaid = parseFloat(document.getElementById('amount_paid').value) || 0;
    
    // Debt = Net Amount - Amount Paid
    const debtAmount = Math.max(0, netAmount - amountPaid);
    document.getElementById('debt_label').value = '₹' + debtAmount.toFixed(2);
    
    // For paid status, set amount_paid to net_amount
    if (status === 'paid') {
        document.getElementById('amount_paid').value = netAmount.toFixed(2);
    }
}

function toggleAmountPaidField() {
    const status = document.getElementById('payment_status').value;
    const amountPaidSection = document.getElementById('amount-paid-section');
    
    if (status === 'partial' || status === 'pending') {
        amountPaidSection.style.display = 'grid';
        // For pending: set amount_paid to 0 by default
        if (status === 'pending') {
            document.getElementById('amount_paid').value = '0';
        } else {
            // For partial: auto-calculate based on net amount (user can edit)
            const netAmount = parseFloat(document.getElementById('net_label').value.replace('₹', '')) || 0;
            // Leave empty for partial so user can enter amount
        }
    } else if (status === 'paid') {
        amountPaidSection.style.display = 'grid';
        const netAmount = parseFloat(document.getElementById('net_label').value.replace('₹', '')) || 0;
        document.getElementById('amount_paid').value = netAmount.toFixed(2);
    } else {
        amountPaidSection.style.display = 'none';
        document.getElementById('amount_paid').value = '0';
    }
    
    calculateDebt();
}

// Add event listeners
document.getElementById('discount_amount').addEventListener('input', calculateFinal);

// Form validation on submit
document.querySelector('form').addEventListener('submit', function(e) {
    const status = document.getElementById('payment_status').value;
    
    if (!status) {
        e.preventDefault();
        alert('Please select a payment status');
        return false;
    }
});

// Initialize
calculateFinal();
toggleAmountPaidField();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Store Account Management\backend\resources\views/admin/bills/create.blade.php ENDPATH**/ ?>