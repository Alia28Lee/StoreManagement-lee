<?php

require 'vendor/autoload.php';

use Illuminate\Support\Facades\Hash;

// Test with Laravel's Hash facade
$password = 'admin@123';
$hash = '$2y$12$uFnlmprRFxxg2IK9Xd05Au3u.kNXI1dTKl/oV2SjYELtEKDk2dDvm'; // The hash from database

echo "=== PASSWORD HASH TEST ===\n\n";
echo "Plain Password: " . $password . "\n";
echo "Hashed Password: " . $hash . "\n\n";

// Load Laravel
$app = require __DIR__ . '/bootstrap/app.php';

// Bootstrap Laravel for Hash functionality
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

// Test password verification
$isValid = Hash::check($password, $hash);

echo "Hash Verification Result: " . ($isValid ? "✅ VALID" : "❌ INVALID") . "\n\n";

// Let's also try with the User model
$user = \App\Models\User::where('email', 'admin@storeadmin.com')->first();

if($user) {
    echo "User Found: " . $user->email . "\n";
    echo "User Password Hash: " . substr($user->password, 0, 20) . "...\n";
    
    $checkPassword = Hash::check($password, $user->password);
    echo "Password Check: " . ($checkPassword ? "✅ VALID" : "❌ INVALID") . "\n\n";
    
    // Check profile
    if($user->profile) {
        echo "Profile Found: YES\n";
        echo "  Role: " . $user->profile->role . "\n";
        echo "  Active: " . ($user->profile->is_active ? "Yes" : "No") . "\n";
    } else {
        echo "Profile Found: NO\n";
    }
} else {
    echo "User Not Found\n";
}
