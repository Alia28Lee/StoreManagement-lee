<?php

require 'vendor/autoload.php';

$app = require __DIR__ . '/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

echo "=== DETAILED AUTH DIAGNOSTIC ===\n\n";

// Check 1: Auth Guard Configuration
echo "1. AUTH GUARD CONFIGURATION:\n";
$defaultGuard = config('auth.defaults.guard');
$adminGuard = config('auth.guards.admin');
$usersProvider = config('auth.providers.users');
echo "   Default Guard: " . $defaultGuard . "\n";
echo "   Admin Guard Driver: " . ($adminGuard['driver'] ?? 'NOT SET') . "\n";
echo "   Admin Guard Provider: " . ($adminGuard['provider'] ?? 'NOT SET') . "\n";
echo "   Users Provider Model: " . ($usersProvider['model'] ?? 'NOT SET') . "\n\n";

// Check 2: Session Configuration
echo "2. SESSION CONFIGURATION:\n";
$sessionDriver = config('session.driver');
$sessionLifetime = config('session.lifetime');
echo "   Session Driver: " . $sessionDriver . "\n";
echo "   Session Lifetime: " . $sessionLifetime . " minutes\n";
echo "   Session Connection: " . (config('session.connection') ?? 'default') . "\n\n";

// Check 3: Database Configuration
echo "3. DATABASE CONFIGURATION:\n";
$dbDriver = config('database.default');
$dbFile = config('database.connections.sqlite.database');
echo "   Default Connection: " . $dbDriver . "\n";
echo "   SQLite Database: " . $dbFile . "\n";
echo "   Database File Exists: " . (file_exists($dbFile) ? "✅ Yes" : "❌ No") . "\n\n";

// Check 4: User exists with correct data
echo "4. USER DATA:\n";
$user = User::where('email', 'admin@storeadmin.com')->first();
if($user) {
    echo "   User Found: ✅ Yes\n";
    echo "   User ID: " . $user->id . "\n";
    echo "   User Email: " . $user->email . "\n";
    echo "   User Name: " . $user->name . "\n";
    echo "   Password Hash Exists: " . (!empty($user->password) ? "✅ Yes" : "❌ No") . "\n";
    
    // Test password
    $passwordCheck = Hash::check('admin@123', $user->password);
    echo "   Password Check: " . ($passwordCheck ? "✅ Valid" : "❌ Invalid") . "\n";
    
    // Check profile
    $profile = $user->profile;
    if($profile) {
        echo "   Profile Exists: ✅ Yes\n";
        echo "   Profile Role: " . $profile->role . "\n";
        echo "   Profile Active: " . ($profile->is_active ? "✅ Yes" : "❌ No") . "\n";
    } else {
        echo "   Profile Exists: ❌ No\n";
    }
} else {
    echo "   User Found: ❌ No\n";
}

echo "\n5. AUTHENTICATION ATTEMPT:\n";

// Clear any existing sessions
session()->flush();
Auth::guard('admin')->logout();

// Try attempt
$credentials = ['email' => 'admin@storeadmin.com', 'password' => 'admin@123'];
echo "   Credentials:\n";
echo "     - Email: " . $credentials['email'] . "\n";
echo "     - Password: " . str_repeat('*', strlen($credentials['password'])) . "\n";

$result = Auth::guard('admin')->attempt($credentials);
echo "   Attempt Result: " . ($result ? "✅ SUCCESS" : "❌ FAILED") . "\n";

if(!$result) {
    // Manual authentication check
    echo "\n   Debugging attempt failure:\n";
    
    $user = User::where('email', $credentials['email'])->first();
    if(!$user) {
        echo "     - User query returned null\n";
    } else {
        echo "     - User exists\n";
        
        $passwordValid = Hash::check($credentials['password'], $user->password);
        echo "     - Password valid: " . ($passwordValid ? "✅ Yes" : "❌ No") . "\n";
        
        // Try with remember token
        echo "     - Attempting with remember=false...\n";
        $attemptNoRemember = Auth::guard('admin')->attempt($credentials, false);
        echo "       Result: " . ($attemptNoRemember ? "✅ SUCCESS" : "❌ FAILED") . "\n";
        
        // Try with remember token
        echo "     - Attempting with remember=true...\n";
        $attemptRemember = Auth::guard('admin')->attempt($credentials, true);
        echo "       Result: " . ($attemptRemember ? "✅ SUCCESS" : "❌ FAILED") . "\n";
    }
}

// Logout
Auth::guard('admin')->logout();
