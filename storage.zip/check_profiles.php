<?php

$db = new PDO('sqlite:database/database.sqlite');

echo "=== USER PROFILES TABLE ===\n\n";

$profiles = $db->query("SELECT * FROM user_profiles")->fetchAll(PDO::FETCH_ASSOC);

foreach($profiles as $profile) {
    echo "Profile ID: " . $profile['id'] . "\n";
    echo "  User ID: " . $profile['user_id'] . "\n";
    echo "  Email: " . $profile['email'] . "\n";
    echo "  Role: " . $profile['role'] . "\n";
    echo "  Shop: " . $profile['shop_name'] . "\n";
    echo "  Active: " . ($profile['is_active'] ? 'Yes' : 'No') . "\n";
    echo "\n";
}

echo "=== ALL USERS ===\n\n";

$users = $db->query("SELECT * FROM users")->fetchAll(PDO::FETCH_ASSOC);

foreach($users as $user) {
    echo "User ID: " . $user['id'] . "\n";
    echo "  Email: " . $user['email'] . "\n";
    echo "  Name: " . $user['name'] . "\n";
    echo "\n";
}
