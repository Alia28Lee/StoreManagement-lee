<?php

use App\Models\User;
use App\Models\UserProfile;
use Illuminate\Support\Facades\Hash;

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

try {
    // Delete old user if exists
    User::where('email', 'admin@storeadmin.com')->delete();
    
    // Create new user
    $user = User::create([
        'name' => 'System Administrator',
        'email' => 'admin@storeadmin.com',
        'password' => Hash::make('admin@123'),
    ]);

    // Create profile
    UserProfile::create([
        'user_id' => $user->id,
        'shop_name' => 'Main Store',
        'full_name' => 'System Administrator',
        'phone' => '9876543210',
        'city' => 'Delhi',
        'state' => 'Delhi',
        'address' => 'Admin Office',
        'role' => 'superadmin',
        'is_active' => true,
    ]);

    echo "✅ Admin user created successfully!\n";
    echo "📧 Email: admin@storeadmin.com\n";
    echo "🔐 Password: admin@123\n";
    echo "\n⚠️  Please change the password after first login!\n";
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
